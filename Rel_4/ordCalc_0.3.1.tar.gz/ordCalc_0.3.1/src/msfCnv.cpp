#include <iostream>
#include <fstream>
#include <stdlib.h>

using  namespace std ;
int main(int argc, char ** argv)
{
	istream * inp = NULL ;
	if (argc > 2) {
		cerr << "'" << argv[0] << "' requires 0 or 1 parameters.\n" ; 
		exit(1);
	}
	if (argc == 2) {
		inp = new ifstream(argv[1]);
		if (!inp->good()) {
			cerr << "Cannot open file '" << argv[1] << """.\n" ;
			exit(2);
		}
	}
	else inp = &cin ;

	istream &in = *inp ;
	static const int maxLine = 65536*8 ;
	char buf[maxLine] ;
	while (in.good()) {
		in.getline(buf,maxLine,'\n');
		int rCount = in.gcount();
		if (rCount >= (maxLine-1)) {
			cerr << "Input line has more than " << (maxLine  - 1) <<
				" characters and is too long.\n" ;
			exit(3);
		}
		int ck = rCount - 2 ;
		for (; ck > -1 ; ck--)
			if (buf[ck] < ' ') buf[ck] = '\0' ;
			else break ;
        /*
		if (ck<rCount -2) cerr << "Deleted " << (rCount-2 - ck) << 
			" control charcters\n" ;
		if (!cout.good()) {
			cerr << "Cannot write to standard output.\n" ;
			exit(4);
		}
        */
		if (rCount) cout << buf << "\n" ;
	}
		
}
