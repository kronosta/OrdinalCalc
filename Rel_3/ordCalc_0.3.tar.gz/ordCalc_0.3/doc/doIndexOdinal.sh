mv ordinal.idx bordinal.idx
fgrep -v '\Cpp'  bordinal.idx > ordinal.idx
./indextex -t -d -o ordinal > err 2>&1
