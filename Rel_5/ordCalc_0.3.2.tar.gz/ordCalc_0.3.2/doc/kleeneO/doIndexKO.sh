mv kleeneOpdf.idx bkleeneOpdf.idx
fgrep -v '\Cpp'  bkleeneOpdf.idx > kleeneOpdf.idx
../indextex -t -d -o kleeneOpdf > err 2>&1
