#include "stdafx.h"


#include <fstream>
#include <algorithm>
#include <stdarg.h>
#include "ordTop.h"
#include "validate.h"
#include "validDoc.h"
#include <list>


using namespace ord;
using namespace std;

#define LIM_ELT_TST(code, base) { \
    outStream() << "Test " << #code << "\n" ;\
    (base).listElts(count,doTest); \
    (base).descend(3,8) ;}


#define NM_LIM_ELT_TST(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal))

#define NM_LIM_ELT_TST_skd(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,NULL,Ordinal::zero, \
    LabeledOrdinal::testOnly))


#define NM2_LIM_ELT_TST_skd(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::zero, \
    LabeledOrdinal::testOnly))


#define NM2_LIM_ELT_TST(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname))

#define NM3_LIM_ELT_TST_skd(name,sname,lsname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::zero, \
    LabeledOrdinal::testOnly, #lsname))


#define NM3_LIM_ELT_TST(name,sname,lsname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,&Ordinal::zero,\
    LabeledOrdinal::output, #lsname))
/*
void LabeledOrdinal::finiteFuncLimitElementComExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{

	const Ordinal& fb = psi( Ordinal::five, Ordinal::zero)	;

    NM_LIM_ELT_TST(FB,fb);


	//fb_1 = psi( 12, 0, 0, 0 )
	const Ordinal& fb_1 = finiteFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		Ordinal::zero,
		Ordinal::zero)	;

    NM_LIM_ELT_TST(FB_1,fb_1);

    
	//fb_2 = psi( w + 14, 0, 0 )
	const Ordinal& fb_2 = finiteFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(14))))),
		Ordinal::zero,
		Ordinal::zero)	;

    NM_LIM_ELT_TST(FB_2,fb_2);


	//fd = psi( 4, 12 )
	const Ordinal& fd = psi( Ordinal::four, (*new Ordinal(12)))	;
    NM_LIM_ELT_TST(FD,fd);


	//fd_1 = psi( 3, ( w^2 ) + 2 )
	const Ordinal& fd_1 = psi( Ordinal::three, ( * new Ordinal(expFunctional(Ordinal::two).getImpl()
	.addLoc(Ordinal::two))))	;

    NM_LIM_ELT_TST(FD_1,fd_1);

	//fl = psi( w, 0 )
	const Ordinal& fl = psi( expFunctional(Ordinal::one), Ordinal::zero)	;

    NM_LIM_ELT_TST(FL,fl);


	//fl_1 = gamma( ( w^w ) )
	const Ordinal& fl_1 = finiteFunctional(
		expFunctional(expFunctional(Ordinal::one)),
		Ordinal::zero,
		Ordinal::zero)	;
    NM_LIM_ELT_TST(FL_1,fl_1);


	//fn = psi( w, 5 )
	const Ordinal& fn = psi( expFunctional(Ordinal::one), Ordinal::five)	;
    NM_LIM_ELT_TST(FN,fn);


	//fn_1 = psi( gamma( 5 ), 0, 0, 3 )
	const Ordinal& fn_1 = finiteFunctional(
		finiteFunctional(
		Ordinal::six,
		Ordinal::zero,
		Ordinal::zero),
		Ordinal::zero,
		Ordinal::zero,
		Ordinal::three)	;

    NM_LIM_ELT_TST_skd(FN_1,fn_1);

}
*/


void LabeledOrdinal::admisLimitElementExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    //lead = omega_{ 1}[ 4]
	const Ordinal& lead = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::four
	)	;

    NM2_LIM_ELT_TST(DDCO,LEAD,lead);


	//lead1 = omega_{ 1}[ 1]
	const Ordinal& lead1 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one
	)	;

    NM2_LIM_ELT_TST(DDBO,LEAD_1,lead1);

	//lebc = omega_{ w}
	const Ordinal& lebc = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL
	)	;
    
    NM2_LIM_ELT_TST(LCBL,LEBC,lebc);
    
	//lebc2 = [[3]]omega_{ w}(5)
	const Ordinal& lebc2 = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		createParameters(
			&(Ordinal::five)),
		Ordinal::zero,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;
    NM2_LIM_ELT_TST(LCEL,LEBC_1,lebc2);


	//lebc3 = [[3]]omega_{ 5}(3)
	const Ordinal& lebc3 = admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		createParameters(
			&(Ordinal::three)),
		Ordinal::zero,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;
    NM2_LIM_ELT_TST(LCDP,LEBC_2,lebc3);

        /*
    	//leee1 = [[w]]omega_{ w}
	const Ordinal& leee1 = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(expFunctional(Ordinal::one), Embeddings::paramRestrict))
	)	;

    NM2_LIM_ELT_TST(LCBL,LEBC_3,leee1);
    */

    	//lefm = [[w]]omega_{ w}(12)
	const Ordinal& lefm = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings(expFunctional(Ordinal::one), Embeddings::paramRestrict))
	)	;

    NM2_LIM_ELT_TST(LECL,LEBC_4,lefm);





	//leck = [[5]]omega_{ 5}(3)
	const Ordinal& leck = admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		createParameters(
			&(Ordinal::three)),
		Ordinal::zero,
		(* new Embeddings(Ordinal::five, Embeddings::paramRestrict))
	)	;
    NM_LIM_ELT_TST(LECK,leck);


	//leck1 = [[w + 5]]omega_{ w + 5}(23)
	const Ordinal& leck1 = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::five))),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(23)))),
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::five))), Embeddings::paramRestrict))
	)	;

    NM_LIM_ELT_TST(LECK_1,leck1);

	//ledc = omega_{ 4}
	const Ordinal& ledc = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	)	;

    NM_LIM_ELT_TST(LEDC,ledc);

	//ledc1 = omega_{ w + 12}
	const Ordinal& ledc1 = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))),
		Ordinal::zero,
		NULL
	)	;

    NM_LIM_ELT_TST(LEDC_1,ledc1);

	//leee = [[4]]omega_{ 4}
	const Ordinal& leee = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::four, Embeddings::paramRestrict))
	)	;

    NM_LIM_ELT_TST(LEEE,leee);


	//leee2 = [[5]]omega_{ w}
	const Ordinal& leee2 = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::five, Embeddings::paramRestrict))
	)	;

    NM_LIM_ELT_TST(LEDE,leee2);

    //lede1 = [[w + 1]]omega_{ ( w^w )}
	const Ordinal& lede1 = admisLevelFunctional(
		expFunctional(expFunctional(Ordinal::one)),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))), Embeddings::paramRestrict))
	)	;

    NM_LIM_ELT_TST(LEDE_1,lede1);


}
/*
void LabeledOrdinal::iterFuncLimitElementComExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    //ifc = psi_{ w}(1, 0)
	const Ordinal& ifc = iterativeFunctional(
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::zero)	;

    NM2_LIM_ELT_TST(FB,IF,ifc);


	//if_1 = psi_{ 12}(w, 0)
	const Ordinal& if_1 = iterativeFunctional(
		(*new Ordinal(12)),
		expFunctional(Ordinal::one),
		Ordinal::zero)	;

    NM2_LIM_ELT_TST(FL,IF_1,if_1);

	//ig = psi_{ 1}
	const Ordinal& ig = iterativeFunctional(
		Ordinal::one)	;
    NM_LIM_ELT_TST(IG,ig);


	//ig_1 = psi_{ w + 1}
	const Ordinal& ig_1 = iterativeFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))))	;
    NM_LIM_ELT_TST(IG_1,ig_1);


	//ii = psi_{ w + 1}(1)
	const Ordinal& ii = iterativeFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::one)	;
    NM_LIM_ELT_TST(II,ii);


	//ii_1 = psi_{ 1}(1)
	const Ordinal& ii_1 = iterativeFunctional(
		Ordinal::one,
		Ordinal::one)	;
    NM_LIM_ELT_TST(II_1,ii_1);


	//ij = psi_{ w}
	const Ordinal& ij = iterativeFunctional(
		expFunctional(Ordinal::one))	;
    NM_LIM_ELT_TST(IJ,ij);


	//ik = psi_{ w}(1)
	const Ordinal& ik = iterativeFunctional(
		expFunctional(Ordinal::one),
		Ordinal::one)	;
    NM_LIM_ELT_TST(IK,ik);

}
*/

void LabeledOrdinal::admisdrillDownLimitExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    //ddac = omega_{ 2}[ 1]
	const Ordinal& ddac = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::one
	)	;
    NM2_LIM_ELT_TST(DCDO,DDAC,ddac);
    
	//ddac_1 = omega_{ 2}[ w]
	const Ordinal& ddac_1 = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		expFunctional(Ordinal::one)
	)	;

    NM2_LIM_ELT_TST(DCAL,DDAC,ddac_1);

	//ddac_2 = [[1]]omega_{ 2}[[ w]]
	const Ordinal& ddac_2 = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		expFunctional(Ordinal::one),
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST(DCAL,DDAC,ddac_2);

	//ddac_3 = [[12]]omega_{ w + 1}[[ w + 3]]
	const Ordinal& ddac_3 = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		NULL,
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(3))))),
		(* new Embeddings((*new Ordinal(12)), Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST(DCCS,DDAC,ddac_3);


    //ddbo = omega_{ 1}[ 1]
	const Ordinal& ddbo = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one
	)	;

    NM2_LIM_ELT_TST(DDBO,LEAD,ddbo);

	//ddco = omega_{ 1}[ w + 1]
	const Ordinal& ddco = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)))
	)	;

    NM2_LIM_ELT_TST(DDCO,LEAD,ddco);

	//ddco1 = omega_{ 1}[ 13]
	const Ordinal& ddco1 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		(*new Ordinal(13))
	)	;

    NM2_LIM_ELT_TST(DDCO,LEAD,ddco1);

}

void LabeledOrdinal::admisdrillDownLimitComExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    //dcal = [[5]]omega_{ 6}[ omega_{ 3}]
	const Ordinal& dcal = admisLevelFunctional(
		Ordinal::six,
		Ordinal::zero,
		NULL,
		admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	),
		(* new Embeddings(Ordinal::five, Embeddings::paramRestrict))
	)	;

    NM2_LIM_ELT_TST(DCAL,DDAC,dcal);

	//dcal1 = [[5]]omega_{ 6}[[ omega_{ 3}]]
	const Ordinal& dcal1 = admisLevelFunctional(
		Ordinal::six,
		Ordinal::zero,
		NULL,
		admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	),
		(* new Embeddings(Ordinal::five, Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST(DCAL,DDAC,dcal1);

	//dcal2 = omega_{ 1}[ w]
	const Ordinal& dcal2 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		expFunctional(Ordinal::one)
	)	;

    NM2_LIM_ELT_TST(DCAL,DDAC,dcal2);


    //dcbo = [[4]]omega_{ 4}[[ 1]]
	const Ordinal& dcbo = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::four, Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST(DCBO,DDAC,dcbo);

	//dcbo2 = [[w + 1]]omega_{ ( w*4) + 3}[[ 1]]
	const Ordinal& dcbo2 = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one, 4).getImpl().addLoc(Ordinal::three))),
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))), Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST(DCBO_1,DDAC,dcbo2);

    //dccs = [[3]]omega_{ 3}[[ w + 5]]
	const Ordinal& dccs = admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL,
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::five))),
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST(DCCS,DDAC,dccs);

	//dccs1 = [[w + 3]]omega_{ w + 5}[[ omega_{ w + 2} + 4]]
	const Ordinal& dccs1 = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::five))),
		Ordinal::zero,
		NULL,
		( * new Ordinal(admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two))),
		Ordinal::zero,
		NULL
	).getImpl().addLoc(Ordinal::four))),
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::three))), Embeddings::paramRestrict, true))
	)	;

    NM2_LIM_ELT_TST_skd(DCCS,DDAC,dccs1);


	//dcdo = omega_{ 8}[ 1]
	const Ordinal& dcdo = admisLevelFunctional(
		(*new Ordinal(8)),
		Ordinal::zero,
		NULL,
		Ordinal::one
	)	;

    NM2_LIM_ELT_TST(DCDO,DDAC,dcdo);


	//dcdo1 = [[3]]omega_{ 8}[ 1]
	const Ordinal& dcdo1 = admisLevelFunctional(
		(*new Ordinal(8)),
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;

    NM2_LIM_ELT_TST(DCDO_1,DDAC,dcdo1);


    //dces = [[3]]omega_{ 4}[ 3]
	const Ordinal& dces = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::three,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;

    NM2_LIM_ELT_TST(DCES,DDAC,dces);

	//dces1 = omega_{ 4}[ 3]
	const Ordinal& dces1 = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::three
	)	;

    NM2_LIM_ELT_TST(DCES,DDAC,dces1);

}


void LabeledOrdinal::runTest(int count, ListLabeledOrds createList)
{
    bool doTest = true ;
    // int count = 10 ;
    bool doTest2 = true ;

    list<LabeledOrdinal*> labOrds;
    // LabeledOrdinal::admisLimitEltExitCodeTestNames(labOrds);
    // LabeledOrdinal::admisLimitElementExitCodeTestNames(labOrds);
    createList(labOrds);

    int countVar = 1 ;
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        outStream() << "DOING " << countVar++ << "\n" ;
        // NLIM_ELT_TSTS((*iter)->name,(*iter)->ord);
        outStream() << "Test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " << (*iter)->subName ;
        outStream() << " for " << (*iter)->ord.normalForm() << "\n" ;
        ((*iter)->ord).listElts(count,doTest); 
        if (doTest2) ((*iter)->ord).descend(3,10) ;

    }
    const Ordinal & twelve = * new Ordinal(12);
    const Ordinal& eps0Pw = * new Ordinal((eps0 + omega).getImpl()) ;
    const Ordinal& epsw12 = *new Ordinal((eps0Pw + twelve).getImpl()) ;
    const Ordinal& bg =
        admisLevelFunctional(eps0,omega,createParameters(&Ordinal::one));
    const Ordinal& bgp = bg + epsw12 ;
    const Ordinal * params[] = {
        &Ordinal::omega,
        &eps0,
        &eps0Pw,
        &epsw12,
        &omega1CK,
        &bg,
        &bgp,
        NULL
    };

    countVar = 1;
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        outStream() << "DOING ORD" << countVar++ << "\n" ;
        const Ordinal& ord = (*iter)->ord ;
        if (CantorNormalElement::integerLimitType.compare(ord) >=0) continue ;
        ord.limitOrdTest(params,5);
    }
}

void Validate::finiteFuncLimitElementComExitCodeTest()
{
    LabeledOrdinal::runTest(10,LabeledOrdinal::
        finiteFuncLimitElementComExitCodeTestNames);
}

void Validate::infoLimitTypeExampTest()
{
   // list<LabeledOrdinal*> labOrds;
   // CantorNormalElement::InfoDocLine::getExamples(labOrds);
   LabeledOrdinal::runTest(7,CantorNormalElement::InfoDocLine::getExamples);
}

void Validate::admisDrillDownLimitExitCodeTest()
{
    LabeledOrdinal::runTest(10,LabeledOrdinal::
        admisdrillDownLimitExitCodeTestNames);
}

void Validate::admisDrillDownLimitComExitCodeTest()
{
    LabeledOrdinal::runTest(10,LabeledOrdinal::
        admisdrillDownLimitComExitCodeTestNames);
}


void Validate::admisLimitElementExitCodeTest()
{
    LabeledOrdinal::runTest(10,
        LabeledOrdinal::admisLimitElementExitCodeTestNames);
}





void LabeledOrdinal::admisLimitEltComExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{

    //lcaf = omega_{ 12, 4}(1)
	const Ordinal& lcaf = admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::four,
		createParameters(
			&(Ordinal::one))
	)	;

    NM2_LIM_ELT_TST(II,LCAF,lcaf);

	//lcaf1 = [[3]]omega_{ 12, 4}(1)
	const Ordinal& lcaf1 = admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::four,
		createParameters(
			&(Ordinal::one)),
		Ordinal::zero,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;

    NM2_LIM_ELT_TST(II,LCAF_1,lcaf1);

	//lcbl = omega_{ w}
	const Ordinal& lcbl = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL
	)	;
     NM2_LIM_ELT_TST(LCBL,LEBC,lcbl);
    

	//lcbl1 = omega_{ omega_{ w}}
	const Ordinal& lcbl1 = admisLevelFunctional(
		admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	)	;
     NM2_LIM_ELT_TST(LCBL_1,LEBC,lcbl1);


	//lcci = omega_{ 1}(12)
	const Ordinal& lcci = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12))))
	)	;
    NM2_LIM_ELT_TST(LCCI,LEBC,lcci);

	//lcdp = omega_{ 5}(12)
	const Ordinal& lcdp = admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12))))
	)	;
    NM2_LIM_ELT_TST(LCDP,LEBC,lcdp);


	//lcdp1 = [[2]]omega_{ 5}(12)
	const Ordinal& lcdp1 = admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings(Ordinal::two, Embeddings::paramRestrict))
	)	;
    NM2_LIM_ELT_TST(LCDP_1,LEBC,lcdp1);


	//lcel = omega_{ w}(12)
	const Ordinal& lcel = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12))))
	)	;
    NM2_LIM_ELT_TST(LCEL,LEBC,lcel);


	//lcel1 = [[5]]omega_{ w}(12)
	const Ordinal& lcel1 = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings(Ordinal::five, Embeddings::paramRestrict))
	)	;
    NM2_LIM_ELT_TST(LCEL_1,LEBC,lcel1);
    /*
    //lcel2 = [[epsilon( 2)]]omega_{ gamma( 4 )}(12)
	const Ordinal& lcel2 = admisLevelFunctional(
		finiteFunctional(
		Ordinal::five,
		Ordinal::zero,
		Ordinal::zero),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings(psi( Ordinal::one, Ordinal::two), Embeddings::paramRestrict))
	)	;
    */
    //lcel2 = [[epsilon( 2) + 12]]omega_{ gamma( 4 )}(12)
	const Ordinal& lcel2 = admisLevelFunctional(
		finiteFunctional(
		Ordinal::five,
		Ordinal::zero,
		Ordinal::zero),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(psi( Ordinal::one, Ordinal::two).getImpl().addLoc((*new Ordinal(12))))), Embeddings::paramRestrict))
	)	;


    NM_LIM_ELT_TST_skd(LCEL_2,lcel2);
}

void Validate::admisLimitElementComExitCodeTest()
{
    LabeledOrdinal::runTest(10,
        LabeledOrdinal::admisLimitEltComExitCodeTestNames);

}



void LabeledOrdinal::admisLimitEltExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    const Ordinal& omegaToOmega = * new Ordinal(Ordinal::omega^Ordinal::omega) ;
    const Ordinal& psiOmegaOmega =  * new Ordinal(psi(Ordinal::omega,Ordinal::omega));


    const Ordinal& dda = admisLevelFunctional(Ordinal::three,Ordinal::zero,
        NULL,Ordinal::five);
    NM_LIM_ELT_TST(DDA,dda);

    const Ordinal& la = admisLevelFunctional(Ordinal::three,Ordinal::omega,
        createParameters(&Ordinal::one,&psiOmegaOmega,&Ordinal::zero,&Ordinal::zero));
    NM_LIM_ELT_TST(LA,la);

    const Ordinal& la2 = admisLevelFunctional(Ordinal::three,Ordinal::omega,
        createParameters(&Ordinal::one,&omega1CK,&Ordinal::zero,
            & Ordinal::zero,NULL));
    NM_LIM_ELT_TST(LA_2,la2);

    const Ordinal& lb = admisLevelFunctional(Ordinal::three,
        omegaToOmega);
    NM_LIM_ELT_TST(LB,lb);
    
    const Ordinal& eddc = admisLevelFunctional(omegaToOmega,Ordinal::zero,NULL,
        Ordinal::zero,* new Ordinal(Ordinal::omega+Ordinal::one));
    NM_LIM_ELT_TST(EDDC,eddc);

    const Ordinal& lc = admisLevelFunctional(psi(Ordinal::omega^Ordinal::omega,Ordinal::omega),Ordinal::zero);
    NM_LIM_ELT_TST(LC,lc);

    const Ordinal& psiwtwcwpw = psi(Ordinal::omega^Ordinal::omega,Ordinal::omega)+Ordinal::five;
    const Ordinal& cllm = admisLevelFunctional(psi(Ordinal::omega^Ordinal::omega,Ordinal::omega),Ordinal::zero,
        createParameters(&psiwtwcwpw),Ordinal::zero,psi(Ordinal::omega^Ordinal::omega,Ordinal::omega));
    NM_LIM_ELT_TST(CLLM,cllm);

    const Ordinal& psiwcwp2 = admisLevelFunctional(psi(Ordinal::omega^Ordinal::omega,Ordinal::omega),Ordinal::zero,
        createParameters (&psi(Ordinal::omega^Ordinal::omega,Ordinal::five)),Ordinal::zero,
        * new Ordinal(psi(Ordinal::omega^Ordinal::omega,Ordinal::five)+Ordinal::three)
        ) + psi(Ordinal::omega,Ordinal::omega)+Ordinal::one;
    const Ordinal &dlt = * new Ordinal(psi(Ordinal::omega^(psi(
        Ordinal::omega,Ordinal::omega)+one),Ordinal::omega)) ;
    const Ordinal& cllm2 = admisLevelFunctional(dlt,Ordinal::zero,
        createParameters(&psiwcwp2),Ordinal::zero,dlt) ;
    NM_LIM_ELT_TST(CLLM-1,cllm2);

    const Ordinal & paramDelt = *new Ordinal(10000);
    const Ordinal & param = admisLevelFunctional(paramDelt,Ordinal::zero,NULL,Ordinal::zero,
        paramDelt)+Ordinal::five ;

    const Ordinal& cllm3 = admisLevelFunctional(Ordinal::omega,Ordinal::zero,
        createParameters(&param),Ordinal::zero,Ordinal::omega);
    NM_LIM_ELT_TST(CLLM-2,cllm3);


    const Ordinal& cklm = admisLevelFunctional( * new Ordinal(psi(
        Ordinal::omega^Ordinal::omega,Ordinal::omega)),Ordinal::zero,
        createParameters(&psiwtwcwpw),Ordinal::zero,
        * new Ordinal(psi(Ordinal::omega,Ordinal::omega)+ Ordinal::five));
    NM_LIM_ELT_TST(CKLM,cklm);

    const Ordinal& psiwcwp1 = *new Ordinal(psi(Ordinal::omega,
        Ordinal::omega)+Ordinal::one);
    const Ordinal& cklm1 = admisLevelFunctional(* new Ordinal(psi
        (Ordinal::omega^Ordinal::omega,Ordinal::omega)),Ordinal::zero,
        createParameters(&psiwcwp1),Ordinal::zero,* new Ordinal(psi
            (Ordinal::omega,Ordinal::omega)+Ordinal::one));
    NM_LIM_ELT_TST(CKLM-1,cklm1);
}

void Validate::limitEltExitCodeTest()
{
    bool doTest = true ;
    int count = 10 ;
    bool doTest2 = true ;

    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisLimitEltExitCodeTestNames(labOrds);
    int countVar = 1 ;
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        outStream() << "DOING " << countVar++ << "\n" ;
        // NLIM_ELT_TSTS((*iter)->name,(*iter)->ord);
        outStream() << "Test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " << (*iter)->subName ;
        outStream() << " for " << (*iter)->ord.normalForm() << "\n" ;
        ((*iter)->ord).listElts(count,doTest); 
        if (doTest2) ((*iter)->ord).descend(3,10) ;

    }


}


void Validate::limitEltExitCodeTest1()
{
    bool doTest = true ;
    int count = 10 ;

    const Ordinal cksc = admisLevelFunctional(one,zero,createParameters(&one),zero,
        one);
    LIM_ELT_TST(CKSC,cksc);

    const Ordinal cksc1 = admisLevelFunctional(Ordinal::three,zero,
        createParameters(&one),zero, Ordinal::two);
    LIM_ELT_TST(CKSC-1,cksc1);

    const Ordinal cksc2 = admisLevelFunctional(one,zero,createParameters(&Ordinal::two),
        zero, Ordinal::one);
    LIM_ELT_TST(CKSC-2,cksc2);

    const Ordinal cksc3 = admisLevelFunctional(Ordinal::five,zero,
        createParameters(&one),zero, Ordinal::five);
    LIM_ELT_TST(CKSC,cksc);

    const Ordinal& psiwcwp1 = psi(omega,omega)+Ordinal::one;

    const Ordinal& cklm1 = admisLevelFunctional(psi(omega^omega,omega),zero,
        createParameters(&psiwcwp1),zero,psi(omega,omega)+Ordinal::one);
    const Ordinal& bpm = cklm1+Ordinal::four ;
    const Ordinal& cksc4 = admisLevelFunctional(psi(omega,omega)+one,zero,
        createParameters(&bpm),zero,psi(omega,omega)+Ordinal::one);
    LIM_ELT_TST(CKSC-4,cksc4);
}
void Validate::limitEltExitCodeTest2()
{
    bool doTest = true ;
    int count = 10 ;

    const Ordinal & ka = admisLevelFunctional(one,zero,
        createParameters(&one,&zero, &zero),zero,one);
    LIM_ELT_TST(KA,ka);

    const Ordinal & ka1 = admisLevelFunctional(one,zero,
        createParameters(&omega,&one, &zero),zero,one);
    LIM_ELT_TST(KA-1,ka1);

    const Ordinal & ka2 = admisLevelFunctional(one,Ordinal::three,
        createParameters(&one),zero,one);
    LIM_ELT_TST(KA-2,ka2);

    const Ordinal & ka3 = admisLevelFunctional(one,Ordinal::three,
        createParameters(&Ordinal::five),zero,one);
    LIM_ELT_TST(KA-3,ka2);

    const Ordinal & ka4 = admisLevelFunctional(one,omega,
        createParameters(&Ordinal::five),zero,one);
    LIM_ELT_TST(KA-4,ka4);

    
    const Ordinal & kc = admisLevelFunctional(omega,one);
    LIM_ELT_TST(KA-5,kc)

    const Ordinal & kc1 = admisLevelFunctional(omega,Ordinal::five);
    LIM_ELT_TST(KA-6,kc1)

    const Ordinal & kc2 = admisLevelFunctional(omega,
        psi(omega,omega)+Ordinal::five);
    LIM_ELT_TST(KA-7,kc2)

    const Ordinal& twelve = *  new Ordinal(12);
    const Ordinal&w12p1 = admisLevelFunctional(twelve,omega) + one;
    const Ordinal& ka8 = admisLevelFunctional(omega,w12p1,NULL,zero,omega);

    LIM_ELT_TST(KA-8,ka8);



    const Ordinal& five = Ordinal::five ;

    const Ordinal & keaa = admisLevelFunctional(five,zero,NULL,zero,five);
    LIM_ELT_TST(KEA,keaa);

    const Ordinal & kea1a = admisLevelFunctional(one,zero,NULL,zero,one);
    LIM_ELT_TST(KEA-1,kea1a);

    const Ordinal & kea2a = admisLevelFunctional(five,zero,NULL,zero,one);
    LIM_ELT_TST(KEA-2,kea2a);

    const Ordinal& kea = admisLevelFunctional(one,zero,NULL,zero,one);
    LIM_ELT_TST(KEA-3,kea);
    
    const Ordinal& kea1 = admisLevelFunctional(Ordinal::two,zero,NULL,zero,
        Ordinal::two);
    LIM_ELT_TST(KEA-4,kea1);
    
    const Ordinal& kea2 = admisLevelFunctional(omega+Ordinal::two,zero,NULL,
        zero,Ordinal::two);
    LIM_ELT_TST(KEA-5,kea2);

    const Ordinal& ke = admisLevelFunctional(one,zero);
    LIM_ELT_TST(KE,ke);

    const Ordinal& ke1 = admisLevelFunctional(omega+one,zero);
    LIM_ELT_TST(KE-1,ke1);

    const Ordinal& ke2 = admisLevelFunctional(five,zero);
    LIM_ELT_TST(KE-2,ke2);



}

void Validate::limitEltExitCodeTest3()
{
    bool doTest = true ;
    int count = 10 ;
    const Ordinal& b = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)
	;
    LIM_ELT_TST(XXXX,b);

}


void Validate::drillDownExitCodeTest()
{
    bool doTest = true ;
    int count = 10 ;

    const Ordinal& ddl = admisLevelFunctional(omega+one,zero,NULL,
        omega1CK,omega+Ordinal::one);
    LIM_ELT_TST(DDL,ddl);

    const Ordinal& ddko = admisLevelFunctional(one,zero,NULL,one);
    LIM_ELT_TST(DDKO,ddko);

    const Ordinal& ddko1 = admisLevelFunctional(one,zero,NULL,one.one);
    LIM_ELT_TST(DDKO-1,ddko1);

    const Ordinal& ddo = admisLevelFunctional(omega+Ordinal::three,
        zero,NULL,one,one);
    LIM_ELT_TST(DDO,ddo);

    const Ordinal& ddga = admisLevelFunctional(one,
        zero,NULL,(omega^omega)+one,one);
    LIM_ELT_TST(DDGA,ddga);

    const Ordinal& ddga1 = admisLevelFunctional(one,
        zero,NULL,(omega^omega)+one);
    LIM_ELT_TST(DDGA-1,ddga1);

    assert(ddga==ddga1);

    const Ordinal& ddgb = admisLevelFunctional(Ordinal::four,
        zero,NULL,(omega^omega)+one);
    LIM_ELT_TST(DDGB,ddgb);

    const Ordinal& ddgb1 = admisLevelFunctional(Ordinal::four,
        zero,NULL,(omega^omega)+one,Ordinal::three);
    LIM_ELT_TST(DDGB-1,ddgb1);
    // [[1]]omega_{ 2}[[ 1]]
    const Ordinal& ddkc = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)
	;
    LIM_ELT_TST(DDKC,ddkc);



}



void Validate::embedExitCodeTest()
{
    bool doTest = true ;
    int count = 10 ;

    const Ordinal& twelve = * new Ordinal(12);
    const Ordinal&w12 = admisLevelFunctional(twelve,omega) ;
    const Ordinal&w12p1 = w12 + one;

    const Ordinal&edeq = admisLevelFunctional(omega,zero,NULL,zero,omega);
    LIM_ELT_TST(EDEQ,edeq);

    const Ordinal& edeq1 = admisLevelFunctional(omega1CK,zero,NULL,zero,
        omega1CK);
    LIM_ELT_TST(EDEQ-1,edeq1);

    const Ordinal& edab = admisLevelFunctional(omega1CK,zero,NULL,zero,
        omega+Ordinal::three);
    LIM_ELT_TST(EDAB,edab);

    const Ordinal& edab1 = admisLevelFunctional(w12,zero,NULL,zero,
        omega+Ordinal::one);
    LIM_ELT_TST(EDAB-1,edab1);

    const Ordinal& edab2 = admisLevelFunctional((omega^omega)+omega,zero,
        NULL,zero, omega+Ordinal::one);
    LIM_ELT_TST(EDAB-2,edab2);


    const Ordinal& edab3 = admisLevelFunctional(psi(omega,omega)+omega,zero,
        NULL,zero, psi(omega,omega)+Ordinal::one);
    LIM_ELT_TST(EDAB-3,edab3);

    const Ordinal& edab4 = admisLevelFunctional(w12,zero,
        NULL,zero, psi(omega,omega)+Ordinal::one);
    LIM_ELT_TST(EDAB-4,edab4);

    const Ordinal& edac = admisLevelFunctional(omega+twelve,zero,NULL,zero,
        omega+Ordinal::one);
    LIM_ELT_TST(EDAC,edac);

    const Ordinal& edad = admisLevelFunctional(omega*2,zero,NULL,zero,
        omega+twelve);
    LIM_ELT_TST(EDAD,edad);

    const Ordinal& edeo = admisLevelFunctional(one,zero,NULL,zero,
        one);
    LIM_ELT_TST(EDEO,edeo);

    const Ordinal& edee = admisLevelFunctional(omega+twelve,zero,NULL,zero,
        omega+twelve);
    LIM_ELT_TST(EDEE,edee);

    const Ordinal& edef = admisLevelFunctional(twelve,zero,NULL,zero,
        one);
    LIM_ELT_TST(EDEF,edef);

    const Ordinal& edeg = admisLevelFunctional(twelve,zero,NULL,zero,
        Ordinal::three);
    LIM_ELT_TST(EDEG,edeg);
}


#define OS outStream() <<
#define OSS(nm) outStream() << #nm << " " <<
#define OT .normalForm() << "\n" 

void Validate::fixedPointTest()
{
    OS (omega^psi(1,0)) OT ;
    OS (omega^psi(1,1)) OT ;
    OS (omega^psi(omega1CK,0)) OT ;
    OS (omega^psi(omega1CK,1)) OT ;
    OS psi(psi(2,0),0) OT ;
    OS psi(psi(2,0),7) OT ;
    OS psi(finiteFunctional(1,2,0),0) OT ;
    OS psi(finiteFunctional(1,2,1),0) OT ;
    OS psi(finiteFunctional(1,2,0),1000) OT ;
    OS psi(finiteFunctional(1,2,1),99) OT ;
    OS finiteFunctional(finiteFunctional(1,2,1),0,0,0) OT ;
    OS finiteFunctional(finiteFunctional(1,2,1),0,3,0) OT ;
    OS psi(12,omega1CK) OT ;
    OS psi(12,psi(1,3)) OT ;
    OS psi(12,psi(12,0)) OT ;
    OS psi(12,psi(12,1)) OT ;
    OS iterativeFunctional(iterativeFunctional(omega,1,2,1),0,0,0) OT ;
    OS iterativeFunctional(5,iterativeFunctional(omega)) OT ;
    OS iterativeFunctional(5,iterativeFunctional(omega),0) OT ;
    OS iterativeFunctional(5,iterativeFunctional(omega),0,0,0) OT ;
    OS iterativeFunctional(5,iterativeFunctional(omega+1),0,0,0) OT ;
    OS iterativeFunctional(5,iterativeFunctional(omega+1)+1,0,0,0) OT ;

    const Ordinal& emb12=admisLevelFunctional(11,zero,NULL,zero,11);
    // OS admisLevelFunctional(12,zero,NULL,emb12,11) OT;
    //
    const Embeddings& emb = * new Embeddings(Ordinal::two,
        Embeddings::paramRestrict);

    const Ordinal& big = admisLevelFunctional(* new Ordinal(12),
        Ordinal::zero,NULL);
    const Ordinal& bg3 = big * 3 ;

    OSS(A) admisLevelFunctional(Ordinal::four,big.limPlus_1()) OT ;
    OSS(B) admisLevelFunctional(Ordinal::four,bg3) OT ;
    OSS(D) admisLevelFunctional(Ordinal::four,big) OT ;
    OSS(E) admisLevelFunctional(Ordinal::four,big,NULL,Ordinal::zero,emb) OT ;
    OSS(G) admisLevelFunctional(Ordinal::four,Ordinal::zero,createParameters(
        &Ordinal::one, &Ordinal::three, &big, NULL),Ordinal::zero,emb) OT;
    OSS(H) admisLevelFunctional(Ordinal::four,Ordinal::zero,createParameters(
        &Ordinal::one, &Ordinal::three, &(big.limPlus_1()), NULL),
        Ordinal::zero,emb) OT;
    OSS(I) admisLevelFunctional(Ordinal::four,Ordinal::zero,createParameters(
        &Ordinal::one, &Ordinal::three, &big, &Ordinal::five, NULL),
        Ordinal::zero,emb) OT;

    //emb2_3 = [[2, 3]]
	static const IndexedLevel * const emb2_3[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		NULL
	};

    //emb2_3w = [[2, 3/omega]]
	static const IndexedLevel * const emb2_3w[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::omega),
		NULL
	};
    //emb2_3w1 = [[2, 3/omega+1]]
	static const IndexedLevel * const emb2_3w1[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,
            * new Ordinal(OrdinalImpl::omega.addLoc(Ordinal::one))),
		NULL
	};

    const Ordinal& twelve = * new Ordinal(12);

    const Ordinal& bige =
        * new NestedEmbedOrdinal(twelve, Ordinal::zero,
        * new NestedEmbeddings(emb2_3w));
    
    // outStream() << "bige = " << bige.normalForm() << " bigEnd\n" ;

    const Ordinal& bige1 =
        * new NestedEmbedOrdinal(twelve, Ordinal::zero,
            * new NestedEmbeddings(emb2_3w1),NULL,Ordinal::one);

    const Ordinal& bige1e =
        * new NestedEmbedOrdinal(twelve, Ordinal::zero,
            * new NestedEmbeddings(emb2_3w1,true),NULL,Ordinal::one);
    
    const Ordinal& test = nestedEmbedFunctional(twelve,bige,
        * new NestedEmbeddings(emb2_3));
    outStream() << test.normalForm() << "\n" ;

    OSS(J) nestedEmbedFunctional(Ordinal::five,Ordinal::four,
        * new NestedEmbeddings(emb2_3), createParameters(&big,NULL)) OT;
    OSS(K) nestedEmbedFunctional(Ordinal::five,Ordinal::four,
        * new NestedEmbeddings(emb2_3),
        createParameters(&big,&Ordinal::one, NULL)) OT;
    OSS(L) nestedEmbedFunctional(Ordinal::five,big,
        * new NestedEmbeddings(emb2_3)) OT;
    OSS(M) nestedEmbedFunctional(Ordinal::five,big,
        * new NestedEmbeddings(emb2_3),
        createParameters(&Ordinal::one, NULL)) OT;
    OSS(N) nestedEmbedFunctional(Ordinal::five,big,
        * new NestedEmbeddings(emb2_3)) OT;
    // OrdinalImpl::debugControl.setCtrOrd(true);
    OSS(O) nestedEmbedFunctional(twelve,bige,
        * new NestedEmbeddings(emb2_3)) OT;
    OSS(P) nestedEmbedFunctional(twelve,bige1,
        * new NestedEmbeddings(emb2_3)) OT;
    OSS(Q) nestedEmbedFunctional(twelve,bige1e,
        * new NestedEmbeddings(emb2_3)) OT;
}

class NestEmbTest {
    static const int maxOrds = 62;
    const Ordinal ** toTest ;
    int nxtOrd ;
    void newOrd(const Ordinal& ord);

    public:
    NestEmbTest() {
        toTest = new const Ordinal * [maxOrds+2];
        nxtOrd = 0 ;
    }
    ~NestEmbTest() {
        if (toTest) delete toTest ;
        toTest = NULL ;
    }
    void nestedEmbedTest();
    void results(ostream&outStream);
};

void NestEmbTest::newOrd(const Ordinal& ord)
{
     const CantorNormalElement * fst = ord.getImpl().getFirstTerm();
     if (fst && fst->codeLevel == NestedEmbeddings::nestedEmbedLevel) { 
        const NestedEmbedNormalElement& nelt = (const NestedEmbedNormalElement&) *fst ;
        assert(nelt.embeddings.embedLevel == NestedEmbeddings::nestedEmbedLevel) ;
    }
    assert(nxtOrd < maxOrds) ;
    toTest[nxtOrd++] = &ord ;
    toTest[nxtOrd]=NULL ;
}


void Validate::nestedEmbedTest()
{
    NestEmbTest net ;
    net.nestedEmbedTest();
    net.results(outStream());
}

static string ordName(int n)
{
    static const int maxChar = 6 ;
    static const int base = 16 ;
    static const int shift = 4 ;
    char buf[maxChar+1] ;
    buf[maxChar]  = '\0' ;
    int pos = maxChar-1 ;
    int remain = n ;
    bool first = true ;
    while (first || remain) {
        first = false ;
        assert(pos > -1) ;
        buf[pos--] = 'a' + (remain % base) ;
        remain >>= shift ;
    }
    return buf + pos + 1 ;
}


void NestEmbTest::results(ostream&outStream)
{
   for (int i = 0 ; i < nxtOrd; i++) outStream << ordName(i) << 
        " = " << toTest[i]->normalForm() << "\n" ;
    outStream << "Comparison order: < > == \n" ;
   for (int i = 0 ; i < nxtOrd; i++) 
        for (int j=i+1; j < nxtOrd; j++)  {
#define R(a,b,c) << (a b c) << ":" 
#define RTEST(a,b) outStream << ordName(i) << "::" << ordName(j) << "-" \
    R(a,<,b) R(a,>,b) R(a,==,b)  \
    << "rv:" R(b,<,a) R(b,>,a) R(b,==,a) << "\n" 
            RTEST(*(toTest[i]),*(toTest[j])) ;
            //RTEST(*(toTest[j]),*(toTest[i])) ;

        }
}

const IndexedLevel ** makeIndexedLevels(const Ordinal * ord1,
    const Ordinal * ord2,...)
{
    static const int ordLimit=255 ;
    const IndexedLevel * levs[ordLimit+1] ;
    int count = 0 ;
    assert(ord1);
    assert(ord2);
    const IndexedLevel * lev= new IndexedLevel(*ord1,*ord2);
    int ordIx = 0 ;
    levs[ordIx++] = lev ;

    va_list marker ;
    va_start(marker,ord2);
    while (true) {
        ord1 = va_arg( marker,const Ordinal *);
        if (!ord1) break ;
        ord2 = va_arg( marker,const Ordinal *);
        assert(ord2);
        const IndexedLevel * lev= new IndexedLevel(*ord1,*ord2);
        assert(ordIx<ordLimit) ;
        levs[ordIx++] = lev ;
        levs[ordIx]=NULL ;
    }
    va_end(marker);
    const IndexedLevel ** retLev = new const IndexedLevel * [ordIx+1] ;
    for (int i = 0 ; i < ordIx+1; i++) retLev[i]=levs[i] ;
    return retLev ;

}

void NestEmbTest::nestedEmbedTest()
{

    {
	    const IndexedLevel ** a0IndexedLevel= makeIndexedLevels(
            &(Ordinal::two) ,&(expFunctional(Ordinal::one)),
		    &(Ordinal::three) ,new Ordinal(99),
		    &(Ordinal::four) ,new Ordinal(88),
		    new Ordinal(7) ,&(Ordinal::zero),
		    NULL);

          const Ordinal& a = nestedEmbedFunctional(
		    (*new Ordinal(8)),
		    Ordinal::zero,
		    (* new NestedEmbeddings( a0IndexedLevel, false)), 
		    NULL,
		    Ordinal::one);
        newOrd(a);
    }
    {
	    const IndexedLevel ** const b1IndexedLevel= makeIndexedLevels(
		    &Ordinal::two ,&(expFunctional(Ordinal::one)),
		    &Ordinal::three ,new Ordinal(99),
		    &Ordinal::four ,new Ordinal(88),
		    new Ordinal(7) ,&Ordinal::zero,
		    NULL
        );
	    const Ordinal& b = nestedEmbedFunctional(
		    (*new Ordinal(8)),
		    Ordinal::zero,
		    (* new NestedEmbeddings( b1IndexedLevel,
                false)),
		    NULL, Ordinal::two) ;
        newOrd(b);
    }
    {
	    const IndexedLevel ** const c2IndexedLevel= makeIndexedLevels(
		    &Ordinal::two ,&(expFunctional(Ordinal::one)),
		    &Ordinal::three ,new Ordinal(99),
		    &Ordinal::four ,new Ordinal(88),
		    new Ordinal(7) ,&Ordinal::one,
		    NULL
        );
	    const Ordinal& c = nestedEmbedFunctional(
		    (*new Ordinal(7)),
		    Ordinal::zero,
		    (* new NestedEmbeddings( c2IndexedLevel,
                false)),
		    NULL,
		    Ordinal::two) ;
        newOrd(c);
    }
    {
	    const IndexedLevel ** const c2IndexedLevel= makeIndexedLevels(
		    &Ordinal::two ,&(expFunctional(Ordinal::one)),
		    &Ordinal::five ,new Ordinal(99),
		    &Ordinal::six ,new Ordinal(88),
		    // new Ordinal(7) ,&Ordinal::one,
		    NULL
        );
	    const Ordinal& c = nestedEmbedFunctional(
		    (*new Ordinal(7)),
		    Ordinal::zero,
		    (* new NestedEmbeddings( c2IndexedLevel,
                false)),
		    NULL,
		    Ordinal::two) ;
        newOrd(c);
    }
	const IndexedLevel * const d6IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,expFunctional(Ordinal::one)),
		new IndexedLevel(Ordinal::three ,(*new Ordinal(99))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(88))),
		new IndexedLevel((*new Ordinal(7)) ,Ordinal::three),
		NULL
	};
	const IndexedLevel * const d5IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,expFunctional(Ordinal::one)),
		new IndexedLevel(Ordinal::three ,(*new Ordinal(99))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(88))),
		new IndexedLevel((*new Ordinal(7)) ,Ordinal::two),
		NULL
	};
	const IndexedLevel * const d4IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,expFunctional(Ordinal::one)),
		new IndexedLevel(Ordinal::three ,(*new Ordinal(99))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(88))),
		new IndexedLevel((*new Ordinal(7)) ,Ordinal::one),
		NULL
	};

	const IndexedLevel * const d3IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,nestedEmbedFunctional(
		(*new Ordinal(8)),
		Ordinal::zero,
		(* new NestedEmbeddings( d4IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
),
		new IndexedLevel(Ordinal::one ,nestedEmbedFunctional(
		(*new Ordinal(8)),
		Ordinal::zero,
		(* new NestedEmbeddings( d5IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
),
		new IndexedLevel(Ordinal::one ,nestedEmbedFunctional(
		(*new Ordinal(8)),
		Ordinal::zero,
		(* new NestedEmbeddings( d6IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
),
		NULL
	};
	const Ordinal& d = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( d3IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

	outStream() << "d = " << d.normalForm() << "\n" ;

    bool doTest = true ;
    int count = 10 ;

    LIM_ELT_TST(generic,d);

}

