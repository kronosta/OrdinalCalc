#include "admisOrd.h"
using namespace std ;
#include "indexedLevel.h"
	
namespace ord {

    class NestedEmbeddings: public Embeddings {
        string makeEmbName() const ;
        static int countLevels( const IndexedLevel * const * levels) ;
        const Embeddings& embedOnly;
    public:
        static const int nestedEmbedLevel = baseEmbedLevel + 1 ;
        virtual const Embeddings& embedClass() const {return embedOnly;}
        const Ordinal& maxIndex ;
        static const Ordinal& getMaxIndex(const IndexedLevel * const * inds);
        const IndexedLevel * const * nestedIndicies ;
        const int levelCount ;
        const Ordinal& lastLevel ;
        const Ordinal& lastIndex ;
        virtual const IndexedLevel * const * getIndicies() const {
            return nestedIndicies;}
        // virtual const Ordinal& getEffIndex() const {
        //    return nestedIndicies[0]->level;}
        static const Ordinal& paramRestrictLevel(
            const IndexedLevel * const * indicies);
        const enum PrevDiff {equal, equalMo, less, onlyOne} prevLevDiff ;
        const enum PrevDiff prevInxDiff ;
private:
        static PrevDiff getPrevLevDiff(const IndexedLevel * const * inds);
        PrevDiff getPrevInxDiff(const IndexedLevel * const * inds);
public:
        const enum HowCreated {unspecified, indexDecr, indexDecrTwo, levelDecr,
            levelDecrIndexSet, deleteLeast} howCreated ;

        NestedEmbeddings(const IndexedLevel * const * inds,
            bool ddEmb=false, int lev=nestedEmbedLevel,
            HowCreated how = unspecified);

        NestedEmbeddings(const Ordinal& level, const Ordinal& index,
            bool ddEmb = false, int lev=nestedEmbedLevel,
            HowCreated how = unspecified);
                
       static bool validNestedEmbeddings(const IndexedLevel * const * inds,
            bool ddEmb=false, int lev=nestedEmbedLevel);

        virtual Embeddings& createVirtualEmbedding(const Ordinal& ddIx,
            Type typ, bool ddEmb) const 
        {   assert(typ == paramRestrict);
            assert(ddIx.compare(nestedIndicies[0]->level)==0);
            return * new NestedEmbeddings(nestedIndicies,ddEmb);}
        virtual string normalForm() const ;

        virtual string& cppNormalForm(const string& nameBase, string& ret)const;
        string normalFormString ; // must be last
        virtual int compare(const Embeddings& embed) const ;

        enum DdEmbOpt {unchangedDdEmb,setDdEmb,clearDdEmb} ;
        virtual const NestedEmbeddings& changeLeastIndex(
            const Ordinal& newIndex, DdEmbOpt ddOpt=unchangedDdEmb,
             HowCreated how = unspecified) const;
        virtual const NestedEmbeddings& deleteLeastIndex(
            DdEmbOpt ddOpt=unchangedDdEmb) const;

        virtual const NestedEmbeddings& deleteLeastIndexedLevel(
            DdEmbOpt ddOpt=unchangedDdEmb) const;
        virtual const Embeddings& deleteLeastIndexedLevelAll(
            DdEmbOpt ddOpt=unchangedDdEmb) const;

        virtual const NestedEmbeddings& changeLeastLevel(
            const Ordinal& newLevel, DdEmbOpt ddOpt=unchangedDdEmb,
            HowCreated = unspecified) const;

        virtual const NestedEmbeddings& appendIndexedLevel(
            const IndexedLevel& ixl) const ;
        virtual const NestedEmbeddings& decrementIndexAppend(
            const IndexedLevel& ixl) const ;
        virtual const NestedEmbeddings& decrementLevelAppend(
            const IndexedLevel& ixl) const ;
        virtual const NestedEmbeddings& appendLevel(const Ordinal& lev) const ;

        virtual const NestedEmbeddings& replaceLeastIndexedLevel( const
            IndexedLevel& newIndexedLevel, DdEmbOpt ddOpt=unchangedDdEmb,
            HowCreated how = unspecified) const;

        virtual const NestedEmbeddings& replaceTwoLeastLevels(
            const Ordinal& pLev,
            const Ordinal& pIx, const Ordinal& lLev, const Ordinal& lIx,
            DdEmbOpt ddOpt=unchangedDdEmb,HowCreated how = unspecified) const;

        virtual const NestedEmbeddings& deleteLeastLevel(
            DdEmbOpt ddOpt=unchangedDdEmb) const;
        bool newDdEmb(DdEmbOpt ddOpt) const ;


        virtual const NestedEmbeddings& truncate(int n,
            const IndexedLevel * toAppend = NULL,
            DdEmbOpt ddOpt=unchangedDdEmb) const ;
        virtual const NestedEmbeddings& truncateAddLevel(int n,
            const Ordinal& lLev, DdEmbOpt ddOpt=unchangedDdEmb) const ;
        virtual const NestedEmbeddings& truncateChangeIndex(int n,
            const Ordinal& lix, DdEmbOpt ddOpt=unchangedDdEmb) const ;
;


        virtual const NestedEmbeddings& ddEmbCopy() const ;
        virtual const NestedEmbeddings& ddEmbFalseCopy() const ;
        virtual const NestedEmbeddings * getNested() const {return this;}
        virtual int compareEmbed(const OrdinalImpl & ord) const;
        virtual int compareEmbed(const Ordinal& ord) const
            {return compareEmbed(ord.getImpl());}

        const enum LeastValue {indexSuccDecr, indexSuccDel,
            levelSuccDecr, levelSuccDel,
            indexLimit, levelLimit} leastValue ;
        const Ordinal& least ;


        bool isLeastLimit() const {
            if ((leastValue == indexLimit) ||
                (leastValue == levelLimit)) return true;
                return false ;
        }

private:
        LeastValue setLeastValue() const;
        const Ordinal& setLeast() const ;
public:

        virtual const Embeddings &nextLeast() const;
        virtual bool leastLevelEq(const Ordinal&ix) const ;


        const IndexedLevel& lastLevelPair() const
            {return *(nestedIndicies[levelCount-1]);}
        const Ordinal * getLevel(int n) const {
            if ((n<0) || n >= levelCount) return NULL;
            return &(nestedIndicies[n]->level) ;
        }
        const Ordinal * getIndex(int n) const {
            if ((n<0) || n >= levelCount) return NULL;
            return &(nestedIndicies[n]->index) ;
        }

    };

    
    class NestedEmbedNormalElement : public AdmisNormalElement {
    public:
        static const int nestedEmbedCodeLevel = admisCodeLevel + 1 ;
    protected:        
        class NestedEmbedParameters : public AdmisLevParameters {
        public:
            const NestedEmbeddings& nestedEmbeddings ;
            NestedEmbedParameters(
                const Ordinal& ixCK, const Ordinal& iter,
                const NestedEmbeddings & embed,
				const Ordinal * const * const params=NULL,
				const Ordinal& dd = Ordinal::zero,
				int level = nestedEmbedCodeLevel);
			virtual ~NestedEmbedParameters(){}
        };

        bool validNestedEmbedNormalElement() const ;
    public:
        virtual const char * className() const {return "NestedEmbedNormalElement";}
        const NestedEmbeddings& nestedEmbeddings;
        static bool validAdmisNormalElement(const Ordinal& deltaIx,
            const Ordinal& inx,
            const Ordinal& iter, const Ordinal * const * const params,
            const Ordinal& dd, const Embeddings& embed=Embeddings::embedNone);



        NestedEmbedNormalElement(
                const Ordinal& ixCK, const Ordinal& iter,
                const NestedEmbeddings & embed,
				const Ordinal * const * const params=NULL,
				const Ordinal& dd = Ordinal::zero,
				Int fac = 1);

         NestedEmbedNormalElement(const NestedEmbedParameters params,
            Int fac=1);

        virtual ~NestedEmbedNormalElement() {}

        bool validNestedEmbedNormalElementInt() const ;

        static bool validNestedEmbedNormalElement(const Ordinal& inx,
            const Ordinal& iter, const NestedEmbeddings& embed, 
            const Ordinal * const * const params,
            const Ordinal& dd);


        // virtual const OrdinalImpl& limitType() const ;
		// virtual const OrdinalImpl& maxLimitType() const ;


        virtual const Ordinal & leUse(const OrdinalImpl& le) const;


        virtual void normalFormName(string& base) const ;
		virtual void texNormalForm(string& str) const ;

        virtual const string cppClassName()
            const {return "nestedEmbedFunctional" ;}
        virtual string& cppNormalForm(const string& nameBase, string& ret)const;

        virtual const CantorNormalElement& getCopy(const Int fac=1) const;

        const OrdinalImpl* limitInfoCommon(
            CantorNormalElement::LimitTypeInfo& info) const ;
       	virtual const OrdinalImpl& limitInfo(
            CantorNormalElement::LimitTypeInfo& info) const ;



        struct LimitState {

           int lastMatch ;
            int indexUse ;
            enum MatchState {levelLimit, indexLimit,
                noMatchLevel, noMatchIndex, unknown} matchState ;

            LimitState():lastMatch(-1),indexUse(-1),matchState(unknown){}

        };


        void drillDownGetLimitInfo(LimitState&limitState) const ;
        const OrdinalImpl& drillDownLimitElementEq(Int n) const;
        // const OrdinalImpl& drillDownLimitElement(Int n) const;
        virtual const OrdinalImpl& limitElement(Int n) const;
        virtual const OrdinalImpl& embedLimitElement(Int n) const ;
        virtual const OrdinalImpl& paramLimitElement(Int n) const ;

        const OrdinalImpl& limitForIndexCKlimitParamEmbed(
            const OrdinalImpl& indexCKle) const ;
        const OrdinalImpl& limitForLeastIndexLimitParam(
            const OrdinalImpl& le) const ;
        const OrdinalImpl& limitForLeastLevelLimitParam(
            const OrdinalImpl& le) const ;

        virtual const OrdinalImpl& limitOrd(const OrdinalImpl & ord) const ;
        virtual const CantorNormalElement & addFactors(
			const CantorNormalElement& toAdd) const ;


        virtual int compare(const Embeddings& embed,
            const Embeddings& termEmbed,
            const CantorNormalElement& trm, bool ignoreFactor = false) const ;

private:

        virtual const OrdinalImpl & createVirtualOrdImpl(const Ordinal & ix,
			const Ordinal & lev, const Ordinal * const * const params,
			const Ordinal& drillDownParams,
            const Embeddings& embed) const ;
		virtual const Ordinal & createVirtualOrd(const Ordinal & ix,
            const Ordinal & lev, const Ordinal * const * const params,
			const Ordinal& drillDownParams,
            const Embeddings& embed) const ;

        virtual const OrdinalImpl & createVirtualOrdImpl(const Ordinal & ix,
			const Ordinal & lev, const Ordinal * const * const params,
			const Ordinal& drillDownParams) const ;
		virtual const Ordinal & createVirtualOrd(const Ordinal & ix,
            const Ordinal & lev, const Ordinal * const * const params,
			const Ordinal& drillDownParams) const ;

        virtual const OrdinalImpl & createVirtualOrdImpl(const Ordinal & lev,
			const Ordinal * const * const params=NULL) const ;
		virtual const Ordinal & createVirtualOrd(const Ordinal & lev,
			const Ordinal * const * const params=NULL) const ;



		virtual const OrdinalImpl & createVirtualOrdImpl(
			const Ordinal * const * const params) const ;

		virtual const Ordinal & createVirtualOrd(
			const Ordinal * const * const params) const ;
    

    
    };

    class NestedEmbedOrdinalImpl: public AdmisLevOrdinalImpl {

    public:
        static const NormalFormTerm& createTerms(const Ordinal& indexCK,
			const Ordinal& iter, const Ordinal* const * const params,
            const NestedEmbeddings& embed,
			const Ordinal& drillDown, Int fac=1);
        

		static string makeName(const Ordinal& ixCK, const Ordinal& iter,
			const Ordinal* const * const params,
			const Ordinal& drillDown,
            const NestedEmbeddings& embed);

		static string makeTexName(const Ordinal& ixCK, const Ordinal& iter,
			const Ordinal* const * const params,
			const Ordinal& drillDown,
            const NestedEmbeddings& embed);


        NestedEmbedOrdinalImpl(
            const Ordinal& ixCK, const Ordinal& iter,
            const NestedEmbeddings & embed,
	        const Ordinal * const * const params=NULL,
			const Ordinal& dd = Ordinal::zero, Int factor=1):
            AdmisLevOrdinalImpl(makeName(ixCK,iter,params,dd,
                embed),createTerms(ixCK,iter,params,
                embed,dd,factor)){}

        NestedEmbedOrdinalImpl(const NestedEmbedNormalElement& elt):
			AdmisLevOrdinalImpl(elt){}

		NestedEmbedOrdinalImpl(const string& name,const NormalFormTerm&  trms):
			AdmisLevOrdinalImpl(name,trms){}


        virtual ~NestedEmbedOrdinalImpl(){}

    };

   

    class NestedEmbedOrdinal: public AdmisLevOrdinal {
    public:

        NestedEmbedOrdinal (
            const Ordinal& levCK, const Ordinal& iter,
            const NestedEmbeddings & embed,
	        const Ordinal * const * const params=NULL,
			const Ordinal& dd = Ordinal::zero,Int factor=1):AdmisLevOrdinal(
                *new NestedEmbedOrdinalImpl(*new NestedEmbedNormalElement(
                    levCK,iter,embed,params,dd,factor))){}
	
		virtual ~NestedEmbedOrdinal(){}

        static bool fixedPoint(const OrdinalImpl& levCK, const Ordinal& iter,
            int ix, const Ordinal* const * const params,
            const NestedEmbeddings& e, const Ordinal *& ret);
        static void texDocument();

    };



}
