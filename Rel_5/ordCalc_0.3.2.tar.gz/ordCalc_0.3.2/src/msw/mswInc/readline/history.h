// interface to Windows console 
