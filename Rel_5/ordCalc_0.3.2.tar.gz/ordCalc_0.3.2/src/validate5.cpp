#include "stdafx.h"


#include "validate.h"
#include "ordTop.h"
#include "validDoc.h"
#include <list>

using namespace std;
using namespace ord ;


#define LIM_ELT_TST(code, base) { \
        const char * lc = LastReturnCode::lastLimitCode.getExitCode(base); \
 /*if(strcmp(#code, lc))outStream()<<"This test should be "<<lc<<".\n";*/ \
    outStream() << "Test " << #code << " for " << base.normalForm() << "\n" ;\
    (base).listElts(count,doTest); \
    if (doTest2) (base).descend(3,7) ;}





void static nestedDdLimitEltExitCodeTest();
void static nestedDdLimitEltEqExitCodeTest();
void static nestedDdLimitEltComExitCodeTest();
void static nestedEmbedLimitEltExitCodeTest();
void static typeTransitionTest();

void Validate::nestedLimitEltExitCodeTest()
{
    /*
    const Ordinal& a = Ordinal::omega + Ordinal::one ;
    outStream() << a.isOne() << "\n" ;
    outStream() << Ordinal::one.isOne() << "\n" ;
    assert(0);
    */
    typeTransitionTest();

    // DDA
    nestedDdLimitEltExitCodeTest();

    // EDDC
    nestedEmbedLimitEltExitCodeTest();

    // NEA
    // calls AdmisNormalElement::limitElementCom
}

// #define NM_LIM_ELT_TST(name,ordinal) LIM_ELT_TST(name,ordinal)

#define NM_LIM_ELT_TST(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal))

#define NM_LIM_ELT_TST_skd(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,NULL,Ordinal::zero, \
    LabeledOrdinal::testOnly))


#define NM2_LIM_ELT_TST_skd(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::zero, \
    LabeledOrdinal::testOnly))


#define NM2_LIM_ELT_TST(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname))


void LabeledOrdinal::nestedLimitEltExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    
    //nla = [[3/4, 5]]omega_{ 6}(omega_{ 3})
	static const IndexedLevel * const nla0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::four),
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		NULL
	};
	const Ordinal& nla = nestedEmbedFunctional(
		Ordinal::six,
		Ordinal::zero,
		(* new NestedEmbeddings( nla0IndexedLevel, false)),
		createParameters(
			&(admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	))),
		Ordinal::zero
	)
	;
     NM2_LIM_ELT_TST(FL,NLA,nla);

    //nla_1 = [[4, 12]]omega_{ 12, omega_{ 3}}(5)
	static const IndexedLevel * const nla_10IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nla_1 = nestedEmbedFunctional(
		(*new Ordinal(12)),
		admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	),
		(* new NestedEmbeddings( nla_10IndexedLevel, false)),
		createParameters(
			&(Ordinal::five)),
		Ordinal::zero
	)
	;
     NM2_LIM_ELT_TST(IK,NLA_1,nla_1);

     //nla_2 = [[3/12]]omega_{ omega_{ 4}}(11)
	static const IndexedLevel * const nla_20IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,(*new Ordinal(12))),
		NULL
	};
	const Ordinal& nla_2 = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( nla_20IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(11)))),
		Ordinal::zero
	)
	;

     NM2_LIM_ELT_TST(LCEL,NLA_2,nla_2);



    //ddio = [[3, 4/1]]omega_{ 4}[ 1]
	static const IndexedLevel * const ddio0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& ddio = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( ddio0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
     NM2_LIM_ELT_TST(DQB,NLB,ddio);


	//ddio_1 = [[3, 4, 4/1]]omega_{ 4}[ 4]
	static const IndexedLevel * const ddio_11IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& ddio_1 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( ddio_11IndexedLevel, false)),
		NULL,
		Ordinal::four
	)
	;

     NM2_LIM_ELT_TST(DQE,NLB_1,ddio_1);



    //[[1/1]]omega_{ 2}[[ 1]]
    static const IndexedLevel * const nddf_20IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& nddf_2 = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( nddf_20IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;

    NM2_LIM_ELT_TST(DCBO,NLC,nddf_2);


     //[[1,3]]w_{3}[[1]]
    	static const IndexedLevel * const a0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		NULL
	};
	const Ordinal& nddf_3 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( a0IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;
    NM2_LIM_ELT_TST(DCBO,NLC_1,nddf_3);


    // nddf_4 = [[3, 4/6]]omega_{ 7}[[ 1]]
    
	static const IndexedLevel * const nddf_41IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		NULL
	};
	const Ordinal& nddf_4 = nestedEmbedFunctional(
		(*new Ordinal(7)),
		Ordinal::zero,
		(* new NestedEmbeddings( nddf_41IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;
    NM2_LIM_ELT_TST(DCBO,NLC_2,nddf_4);




    //nddf = [[2, 12]]omega_{ w + 1}[ w]
	static const IndexedLevel * const nddf0IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nddf = nestedEmbedFunctional(
		// expFunctional(Ordinal::one) + Ordinal::one,
		* new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(OrdinalImpl::one)),
		Ordinal::zero,
		(* new NestedEmbeddings( nddf0IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;


	//nddf_1 = [[3, 12]]omega_{ w + 1}[[ omega_{ 1}]]
	static const IndexedLevel * const nddf_11IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nddf_1 = nestedEmbedFunctional(
		* new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)),
		Ordinal::zero,
		(* new NestedEmbeddings( nddf_11IndexedLevel, true)),
		NULL,
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)
	)
	;
    NM2_LIM_ELT_TST(DCAL,NLC_3,nddf);
    NM2_LIM_ELT_TST(DCAL,NLC_4,nddf_1);


    
    //nddf6 = [[10/5]]omega_{ 12}[ [[1, 2, 2/1]]omega_{ 2}[ 1]]
	static const IndexedLevel * const nddf61IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::one),
		NULL
	};
	static const IndexedLevel * const nddf60IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::five),
		NULL
	};
	const Ordinal& nddf6 = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( nddf60IndexedLevel, false)),
		NULL,
		nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( nddf61IndexedLevel, false)),
		NULL,
		Ordinal::one
	)

	)
	;
     NM2_LIM_ELT_TST(DCAL,NLC_5,nddf6);

     //NM nestedLimitEltExitCodeTestNames
    //nddf_5 = [[3/5]]omega_{ 3}[[ 7]]
	static const IndexedLevel * const nddf_50IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::five),
		NULL
	};
	const Ordinal& nddf_5 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( nddf_50IndexedLevel, true)),
		NULL,
		(*new Ordinal(7))
	)
	;

    NM2_LIM_ELT_TST(DCCS,NLC_6,nddf_5);

    //nle = [[3/12]]omega_{ omega_{ 4}}
	static const IndexedLevel * const nle1IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,(*new Ordinal(12))),
		NULL
	};
	const Ordinal& nle = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( nle1IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(LEEE,NLA,nle);

    //nle_1 = [[4, 5/w]]omega_{ 5}
	static const IndexedLevel * const nle_12IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& nle_1 = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( nle_12IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


    NM2_LIM_ELT_TST(NEF,NLE_1,nle_1);

    //nlp = [[3/2, 3/3]]omega_{ 3}(8)
	static const IndexedLevel * const nlp0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::two),
		new IndexedLevel(Ordinal::three ,Ordinal::three),
		NULL
	};
	const Ordinal& nlp = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( nlp0IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(8)))),
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(PLEC,NLP,nlp);

    //nlp_1 = [[3/2, 5/3]]omega_{ 5}(8)
	static const IndexedLevel * const nlp_12IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::two),
		new IndexedLevel(Ordinal::five ,Ordinal::three),
		NULL
	};
	const Ordinal& nlp_1 = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( nlp_12IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(8)))),
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(PLED,NLP_1,nlp_1);

    //nlp_2 = [[5, omega_{ 3} + 4]]omega_{ omega_{ 3} + 4}(9)
	static const IndexedLevel * const nlp_211IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::four))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nlp_2 = nestedEmbedFunctional(
		( * new Ordinal(admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::four))),
		Ordinal::zero,
		(* new NestedEmbeddings( nlp_211IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(9)))),
		Ordinal::zero
	)
	;


    NM2_LIM_ELT_TST(PLEE,NLP_2,nlp_2);
     

}

#define NLIM_ELT_TSTS(code, base) { \
        const char * lc = LastReturnCode::lastLimitCode.getExitCode(base); \
/* if(strcmp(code, lc))outStream()<<"This test should be " <<lc<<".\n";*/ \
    outStream() << "Test " << code << " for " << base.normalForm() << "\n" ;\
    (base).listElts(count,doTest); \
    if (doTest2) (base).descend(3,5) ;}



static void nestedDdLimitEltExitCodeTest()
{

    bool doTest = true ;
    bool doTest2 = true ;
    int count = 7 ;
    
    // NDDKD
    nestedDdLimitEltEqExitCodeTest();


    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedLimitEltExitCodeTestNames(labOrds);
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        // NLIM_ELT_TSTS((*iter)->name,(*iter)->ord);
        outStream() << "Test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " << (*iter)->subName ;
        outStream() << " for " << (*iter)->ord.normalForm() << "\n" ;
        ((*iter)->ord).listElts(count,doTest); 
        if (doTest2) ((*iter)->ord).descend(3,10) ;

    }
}

static void obsolete();


void LabeledOrdinal::nestedDdLimitEltEqExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 5 ;

    //NM estedDdLimitEltEqExitCodeTestNames
    //

    //ddic1 = [[5, 5/1]]omega_{ 5}[ 4]
	static const IndexedLevel * const ddic10IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,Ordinal::one),
		NULL
	};
	const Ordinal& ddic1 = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( ddic10IndexedLevel, false)),
		NULL,
		Ordinal::four
	)
	;
    NM_LIM_ELT_TST(DQA,ddic1);

    //ndb = [[1, 1/1]]omega_{ 1}[ 1]
	static const IndexedLevel * const ndb0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& ndb = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( ndb0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST(DQA_1,ndb);

     // b = [[5, 5/1]]omega_{ 5}[ 1]

    static const IndexedLevel * const a3IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,Ordinal::one),
		NULL
	};
	const Ordinal& ndb1 = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( a3IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST(DQA_2,ndb1);


	
    //ndbh = [[12/1]]omega_{ 12}[ 1]
	static const IndexedLevel * const ndbh0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::one),
		NULL
	};
	const Ordinal& ndbh = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndbh0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST(DQA_3,ndbh);

    //ndbi = [[12/1]]omega_{ 12}[ 100]
	static const IndexedLevel * const ndbi0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::one),
		NULL
	};
	const Ordinal& ndbi = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndbi0IndexedLevel, false)),
		NULL,
		(*new Ordinal(100))
	)
	;
     NM_LIM_ELT_TST(DQA_4,ndbi);

    



    
   
	//dqb_skd = [[w + 1, w + 33/w + 1]]omega_{ w + 33}[ ( w^w ) + 46]
	static const IndexedLevel * const dqb_skd0IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(33))))) ,( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& dqb_skd = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(33))))),
		Ordinal::zero,
		(* new NestedEmbeddings( dqb_skd0IndexedLevel, false)),
		NULL,
		( * new Ordinal(expFunctional(expFunctional(Ordinal::one)).getImpl()
	.addLoc((*new Ordinal(46)))))
	)
	;

    NM_LIM_ELT_TST_skd(DQB_skd,dqb_skd);


    //ndbg = [[3, 4/1]]omega_{ 4}[ 1]
	static const IndexedLevel * const ndbg0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& ndbg = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( ndbg0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST_skd(DQB_skd1,ndbg);


    //ddiv2 = [[3/w + 1]]omega_{ 3}[ 12]
	static const IndexedLevel * const ddiv20IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& ddiv2 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ddiv20IndexedLevel, false)),
		NULL,
		(*new Ordinal(12))
	)
	;
     NM_LIM_ELT_TST_skd(DQB_skd2,ddiv2);


     //ddiv3 = [[3/w + 2]]omega_{ 3}[ 12]
	static const IndexedLevel * const ddiv31IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two)))),
		NULL
	};
	const Ordinal& ddiv3 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ddiv31IndexedLevel, false)),
		NULL,
		(*new Ordinal(12))
	)
	;
     NM_LIM_ELT_TST_skd(DQB_skd3,ddiv3);



      //ndxa_1 = [[12, 15/1]]omega_{ 15}[ 12]
	static const IndexedLevel * const ndx_11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::one),
		NULL
	};
	const Ordinal& ndxa_1 = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndx_11IndexedLevel, false)),
		NULL,
		(*new Ordinal(12))
	)
	;

    NM_LIM_ELT_TST(DQB,ndxa_1);






    //ndmi1 = [[1, w + 1/w + 1]]omega_{ w + 1}[ 1]
	static const IndexedLevel * const ndmi11IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& ndmi1 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi11IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST(DQB_1,ndmi1);


    //ndx = [[12, 15/2]]omega_{ 15}[ 1]
	static const IndexedLevel * const ndx0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::two),
		NULL
	};
	const Ordinal& ndx = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndx0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;


    NM_LIM_ELT_TST(DQB_2,ndx);


    //ndbj = [[12/7]]omega_{ 12}[ 100]
	static const IndexedLevel * const ndbj0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(7))),
		NULL
	};
	const Ordinal& ndbj = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndbj0IndexedLevel, false)),
		NULL,
		(*new Ordinal(100))
	)
	;
     NM_LIM_ELT_TST(DQB_3,ndbj);

     //ddiv1 = [[3/w + 1]]omega_{ 3}[ 1]
	static const IndexedLevel * const ddiv10IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& ddiv1 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ddiv10IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

     NM_LIM_ELT_TST(DQB_4,ddiv1);


     

    
	




      //ddif = [[12, w, ( w*2) + 1]]omega_{ ( w*2) + 1}[ 5]
	static const IndexedLevel * const ddif0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one, 2).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddif = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one, 2).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ddif0IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;
    NM_LIM_ELT_TST(DQC,ddif);


    //nddc2 = [[5, w + 1]]omega_{ w + 1}[ 1]
	static const IndexedLevel * const nddc20IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nddc2 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( nddc20IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    NM_LIM_ELT_TST(DQC_1,nddc2);
    	    
    
    //ddio1 = [[12, w, ( w*2) + 1]]omega_{ ( w*2) + 1}[ 1]
	static const IndexedLevel * const ddio11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one, 2).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddio1 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one, 2).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ddio11IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    NM_LIM_ELT_TST(DQC_2,ddio1);


    //dqdn = [[w + 2/12, w + 4]]omega_{ w + 4}[ w + 5]
	static const IndexedLevel * const dqdn0IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::two))) ,(*new Ordinal(12))),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::four))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& dqdn = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::four))),
		Ordinal::zero,
		(* new NestedEmbeddings( dqdn0IndexedLevel, false)),
		NULL,
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::five)))
	)
	;
    NM_LIM_ELT_TST_skd(DQD_skd,dqdn);


    //ddim3 = [[w + 12, omega_{ 4}, omega_{ 4} + 12]]omega_{ omega_{ 4} + 12}[ 1]
	static const IndexedLevel * const ddim30IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddim3 = nestedEmbedFunctional(
		( * new Ordinal(admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	).getImpl().addLoc((*new Ordinal(12))))),
		Ordinal::zero,
		(* new NestedEmbeddings( ddim30IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;


    NM_LIM_ELT_TST_skd(DQD_skd1,ddim3);



    
        
        
    //ddid = [[12, 13]]omega_{ 13}[ 10]
	static const IndexedLevel * const ddid0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(13)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddid = nestedEmbedFunctional(
		(*new Ordinal(13)),
		Ordinal::zero,
		(* new NestedEmbeddings( ddid0IndexedLevel, false)),
		NULL,
		(*new Ordinal(10))
	)
	;
    NM_LIM_ELT_TST(DQD,ddid);


    
	//ddie1 = [[1, 3/9, 4]]omega_{ 4}[ 5]
	static const IndexedLevel * const ddie11IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,(*new Ordinal(9))),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddie1 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( ddie11IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;
    NM_LIM_ELT_TST(DQD_1,ddie1);


   
   

    //ddjf = [[2/12, 4]]omega_{ 4}[ 5]
	static const IndexedLevel * const ddjf0IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,(*new Ordinal(12))),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddjf = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( ddjf0IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;
    NM_LIM_ELT_TST(DQD_2,ddjf);


      
    //ndde = [[12, 13]]omega_{ 13}[ 1]
	static const IndexedLevel * const ndde0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(13)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ndde = nestedEmbedFunctional(
		(*new Ordinal(13)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndde0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    NM_LIM_ELT_TST(DQD_3,ndde);

    //ddim = [[3, 5]]omega_{ 5}[ 1]
	static const IndexedLevel * const ddim1IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddim = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( ddim1IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    NM_LIM_ELT_TST(DQD_4,ddim);

    
    //ddih = [[5/6, 5/7]]omega_{ 5}[ 1]
	static const IndexedLevel * const ddih0IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::six),
		new IndexedLevel(Ordinal::five ,(*new Ordinal(7))),
		NULL
	};
	const Ordinal& ddij1 = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( ddih0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST_skd(DQE_skd,ddij1);



    //ddib2 = [[1, 3, 3/1]]omega_{ 3}[ 7]
	static const IndexedLevel * const ddib21IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::one),
		NULL
	};
	const Ordinal& ddib2 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ddib21IndexedLevel, false)),
		NULL,
		(*new Ordinal(7))
	)
	;

    NM_LIM_ELT_TST_skd(DQE_skd1,ddib2);


    
    //ddil = [[1, 2, 3, w, w + 1]]omega_{ w + 1}[ 1]
	static const IndexedLevel * const ddil3IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddil = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ddil3IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST_skd(DQE_skd2,ddil);






    // e = [[1, 2, 2/1]]omega_{ 2}[ 1]

    static const IndexedLevel * const ee1IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::one),
		NULL
	};
	const Ordinal& ndbea = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( ee1IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    NM_LIM_ELT_TST(DQE,ndbea);


    //ddij = [[12/w, 12/w + 1]]omega_{ 12}[ 1]
	static const IndexedLevel * const ddij1IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,expFunctional(Ordinal::one)),
		new IndexedLevel((*new Ordinal(12)) ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& ddij = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( ddij1IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;


    NM_LIM_ELT_TST(DQE_1,ddij);

    
    


    //ddib = [[1, 3/3, 3/4]]omega_{ 3}[ 2]
	static const IndexedLevel * const ddib0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::three),
		new IndexedLevel(Ordinal::three ,Ordinal::four),
		NULL
	};
	const Ordinal& ddib = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ddib0IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
	;
    NM_LIM_ELT_TST(DQE_2,ddib);


		//ddib3 = [[3/3, 3/4]]omega_{ 3}[ 2]
	static const IndexedLevel * const ddib32IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::three),
		new IndexedLevel(Ordinal::three ,Ordinal::four),
		NULL
	};
	const Ordinal& ddib3 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ddib32IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
	;

    NM_LIM_ELT_TST(DQE_3,ddib3);

    //ddje = [[1, 2, 3, w, w + 1]]omega_{ w + 1}[ 4]
	static const IndexedLevel * const ddje1IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ddje = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ddje1IndexedLevel, false)),
		NULL,
		Ordinal::four
	)
	;

    NM_LIM_ELT_TST(DQE_4,ddje);


  	//nddc = [[5, w, w + 1]]omega_{ w + 1}[ 1]
	static const IndexedLevel * const nddc0IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nddc = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( nddc0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    NM_LIM_ELT_TST(DQE_5,nddc);


}

static void extra()
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 10 ;

    
	//a = [[w + 12, w + 13/50]]omega_{ w + 13}[[ 1]]
	static const IndexedLevel * const a0IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,(*new Ordinal(50))),
		NULL
	};
	const Ordinal& a = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		Ordinal::zero,
		(* new NestedEmbeddings( a0IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;

    LIM_ELT_TST(DDKC,a);

	//a2 = [[3, 4]]omega_{ 4}[[ 1]]
	static const IndexedLevel * const a21IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& a2 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( a21IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(DDKC,a2);


	//aa = [[2]]omega_{ 4}[[ 1]]
	const Ordinal& aa = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::two, Embeddings::paramRestrict, true))
	)	;

    LIM_ELT_TST(DDKC,aa);

    	//bug = [[w + 12, w + 13/50]]omega_{ w + 13}[[ 1]]
	static const IndexedLevel * const bug10IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,(*new Ordinal(50))),
		NULL
	};
	const Ordinal& bug = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		Ordinal::zero,
		(* new NestedEmbeddings( bug10IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(DDKC,bug);

    //bug2 = [[3, 4]]omega_{ 4}[[ 1]]
	static const IndexedLevel * const bug211IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& bug2 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( bug211IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(DDKC,bug2);


    	//f2 = [[3, 4]]omega_{ 4}[[ 1]]
	static const IndexedLevel * const f221IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& f2 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( f221IndexedLevel, true)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(DDKC,f2);


	//b = [[w + 12, w + 13/50]]omega_{ w + 13}[ [[w + 12, w + 13/49]]omega_{ w + 13, [[w + 12, w + 13/49]]omega_{ w + 13, [[w + 12, w + 13/50]]omega_{ w + 13}[ 2] + 1} + 1}]
	static const IndexedLevel * const b5IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,(*new Ordinal(49))),
		NULL
	};
	static const IndexedLevel * const b4IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,(*new Ordinal(49))),
		NULL
	};
	static const IndexedLevel * const b3IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,(*new Ordinal(50))),
		NULL
	};
	static const IndexedLevel * const b2IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,(*new Ordinal(50))),
		NULL
	};
	const Ordinal& b = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		Ordinal::zero,
		(* new NestedEmbeddings( b2IndexedLevel, false)),
		NULL,
		nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		( * new Ordinal(nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		( * new Ordinal(nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		Ordinal::zero,
		(* new NestedEmbeddings( b3IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
.getImpl().addLoc(Ordinal::one))),
		(* new NestedEmbeddings( b4IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
.getImpl().addLoc(Ordinal::one))),
		(* new NestedEmbeddings( b5IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)

	)
	;
    LIM_ELT_TST(DDL,b);


	//b2 = [[3, 4]]omega_{ 4}[ [[3, 3/[[3, 3/[[3, 4]]omega_{ 4}[ 2] + 1]]omega_{ 4} + 1]]omega_{ 4}]
	static const IndexedLevel * const b29IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	static const IndexedLevel * const b28IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,( * new Ordinal(nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( b29IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
.getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	static const IndexedLevel * const b27IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,( * new Ordinal(nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( b28IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
.getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	static const IndexedLevel * const b26IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& b2 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( b26IndexedLevel, false)),
		NULL,
		nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( b27IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)

	)
	;

    LIM_ELT_TST(DDL,b2);

	//bb = [[2]]omega_{ 4}[[[2]] omega_{ 4}[ 1]]
	const Ordinal& bb = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::one,
        (* new Embeddings(Ordinal::two, Embeddings::paramRestrict))
	),
		(* new Embeddings(Ordinal::two, Embeddings::paramRestrict))
	)	;
    LIM_ELT_TST(DDL,bb);




	

	//cur = [[3, 4]]omega_{ 4}[ [[3, 4]]omega_{ 4}[ 3]]
	static const IndexedLevel * const cur13IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	static const IndexedLevel * const cur12IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& cur = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( cur12IndexedLevel, false)),
		NULL,
		nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( cur13IndexedLevel, false)),
		NULL,
		Ordinal::three
	)

	)
	;
    LIM_ELT_TST(DDL,cur);


	//d2 = [[3, 4]]omega_{ 4}[ [[3, 3/[[3, 3/[[3, 4]]omega_{ 4}[ 2] + 1]]omega_{ 4} + 1]]omega_{ 4}]
	static const IndexedLevel * const d217IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	static const IndexedLevel * const d216IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,( * new Ordinal(nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( d217IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
.getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	static const IndexedLevel * const d215IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,( * new Ordinal(nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( d216IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
.getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	static const IndexedLevel * const d214IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& d2 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( d214IndexedLevel, false)),
		NULL,
		nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( d215IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)

	)
	;
    LIM_ELT_TST(DDL,d2);


	//e2 = [[3, 3/[[3, 3/[[3, 4]]omega_{ 4}[ 2] + 1]]omega_{ 4} + 1]]omega_{ 4}
	static const IndexedLevel * const e220IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	static const IndexedLevel * const e219IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,( * new Ordinal(nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( e220IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
.getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	static const IndexedLevel * const e218IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,( * new Ordinal(nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( e219IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
.getImpl().addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& e2 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( e218IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    LIM_ELT_TST(NDA,e2);




}

static void nestedDdLimitEltEqExitCodeTest()
{

    bool doTest = true ;
    bool doTest2 = true ;
    int count = 7 ;
    


    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedDdLimitEltEqExitCodeTestNames(labOrds);
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        // if (!strncmp("ND_",(*iter)->name,4)) count = 10 ;
        NLIM_ELT_TSTS((*iter)->name,(*iter)->ord);
        // count = 10 ;
    }

    extra();
    obsolete();
}



static void obsolete()
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 7 ;



    //ndbh = [[1/w]]omega_{ 1}
	const IndexedLevel * const ndbh0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& ndbh = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( ndbh0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    LIM_ELT_TST(NDEB,ndbh);



    
    // ndx=[[1/1]]w_{1}[1]
    const IndexedLevel * const ndxa0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& ndx = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( ndxa0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    LIM_ELT_TST(NDBH,ndx);


    
    

    
    // [[2, 2/1]]omega_{ 2}[ 1]

    const IndexedLevel * const dd0IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::one),
		NULL
	};
	const Ordinal& ndcc = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( dd0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(NDB,ndcc);


    const IndexedLevel * const d3IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::one),
		NULL
	};
	const Ordinal& ndb_1 = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( d3IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(NDBH,ndb_1);


	const IndexedLevel * const c5IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::one),
		NULL
	};
	const Ordinal& admisDdo = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( c5IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(admisDDO,admisDdo);

    	const IndexedLevel * const n13IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		NULL
	};
	const Ordinal& n = nestedEmbedFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		(* new NestedEmbeddings( n13IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    LIM_ELT_TST(NDD,n);


    const IndexedLevel * const p15IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& p = nestedEmbedFunctional(
		(*new Ordinal(13)),
		Ordinal::zero,
		(* new NestedEmbeddings( p15IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    LIM_ELT_TST(NDA,p);


    
	static const IndexedLevel * const q16IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& q = nestedEmbedFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		(* new NestedEmbeddings( q16IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    LIM_ELT_TST(NDF,q);

	static const IndexedLevel * const r17IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::four),
		new IndexedLevel(Ordinal::one ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& r = nestedEmbedFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		(* new NestedEmbeddings( r17IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    LIM_ELT_TST(NDF,r);

    //[[1,2/2]]w_{2}[1]
    const IndexedLevel * const aa0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::two),
		NULL
	};
	const Ordinal& aa = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( aa0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(NDMI,aa);


    // [[1, 2/w]]omega_{ 2}
    	const IndexedLevel * const x0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& x = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( x0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    LIM_ELT_TST(NDEB,x);


     //b = [[1, 2]]omega_{ 2}[ 1]
    
    const IndexedLevel * const b1IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		NULL
	};
	const Ordinal& b1 = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( b1IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    LIM_ELT_TST(NDDE,b1);



    const IndexedLevel * const ax0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::one),
		NULL
	};
	const Ordinal& ax = nestedEmbedFunctional(
		Ordinal::three,
		Ordinal::zero,
		(* new NestedEmbeddings( ax0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(DDO,ax);

   

    //******************
    //ad = [[3, 4/6]]omega_{ 7}[ 1]
    	const IndexedLevel * const ad0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		NULL
	};
	const Ordinal& ad = nestedEmbedFunctional(
		(*new Ordinal(7)),
		Ordinal::zero,
		(* new NestedEmbeddings( ad0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(DOO_2,ad);



    


    // af = [[3, 4/6]]omega_{ 6}[ 2]

	const IndexedLevel * const af2IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		NULL
	};
	const Ordinal& af = nestedEmbedFunctional(
		Ordinal::six,
		Ordinal::zero,
		(* new NestedEmbeddings( af2IndexedLevel, false)),
		NULL,
		Ordinal::two
	)
	;
    LIM_ELT_TST(DDGB_3,af);


    // ag = [[3, 4/6]]omega_{ 6}[ w]

	const IndexedLevel * const ag3IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		NULL
	};
	const Ordinal& ag = nestedEmbedFunctional(
		Ordinal::six,
		Ordinal::zero,
		(* new NestedEmbeddings( ag3IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;
    LIM_ELT_TST(DDL_4,ag);

}



void static nestedDdLimitEltComExitCodeTest()
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 10 ;


}

void LabeledOrdinal::nestedEmbedLimitEltExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds) 
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 10 ;

    //NM nestedEmbedLimitEltExitCodeTestNames

    //nda = [[5, 12/44, 19/omega_{ 3}]]omega_{ 25}
	static const IndexedLevel * const nda0IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(44))),
		new IndexedLevel((*new Ordinal(19)) ,admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& nda = nestedEmbedFunctional(
		(*new Ordinal(25)),
		Ordinal::zero,
		(* new NestedEmbeddings( nda0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(LEDE,NLE,nda);

    

	//nda_1 = [[12, 15/1]]omega_{ 15}
	static const IndexedLevel * const nda_11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::one),
		NULL
	};
	const Ordinal& nda_1 = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( nda_11IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(LEDE_1,NLE,nda_1);

    //nda_2 = [[12, 15/1]]omega_{ 16}
	static const IndexedLevel * const nda_20IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::one),
		NULL
	};
	const Ordinal& nda_2 = nestedEmbedFunctional(
		(*new Ordinal(16)),
		Ordinal::zero,
		(* new NestedEmbeddings( nda_20IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(LEDE_2,NLE,nda_2);

    //nda_3 = [[10, 15/w]]omega_{ 20}
	static const IndexedLevel * const nda_30IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& nda_3 = nestedEmbedFunctional(
		(*new Ordinal(20)),
		Ordinal::zero,
		(* new NestedEmbeddings( nda_30IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(LEDE_3,NLE,nda_3);

    //nda_4 = [[12, 15]]omega_{ 15}
	static const IndexedLevel * const nda_41IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nda_4 = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( nda_41IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(LEDE_4,NLE,nda_4);


    //neb = [[12/4, 15/omega_{ 3}]]omega_{ 15}(12)
	static const IndexedLevel * const neb0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::four),
		new IndexedLevel((*new Ordinal(15)) ,admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& neb = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( neb0IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero
	)
	;
    NM_LIM_ELT_TST(NEB,neb);


	//neb_1 = [[12/4, 15/omega_{ 3}]]omega_{ 15}(w + 1)
	static const IndexedLevel * const neb_11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::four),
		new IndexedLevel((*new Ordinal(15)) ,admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& neb_1 = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( neb_11IndexedLevel, false)),
		createParameters(
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))))),
		Ordinal::zero
	)
	;

    NM_LIM_ELT_TST(NEB_1,neb_1);

	//nec = [[12/4, omega_{ 3}]]omega_{ omega_{ 3}}(w + 1)
	static const IndexedLevel * const nec2IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::four),
		new IndexedLevel(admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nec = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( nec2IndexedLevel, false)),
		createParameters(
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))))),
		Ordinal::zero
	)
	;

    NM_LIM_ELT_TST(NEC,nec);


      //ndf = [[1, 2/w]]omega_{ w}
	static const IndexedLevel * const ndf0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& ndf = nestedEmbedFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		(* new NestedEmbeddings( ndf0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(LEEE,NLA,ndf);

    //ndf_1 = [[2, 5/omega_{ 1}]]omega_{ omega_{ 12}}
	static const IndexedLevel * const ndf_10IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& ndf_1 = nestedEmbedFunctional(
		admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( ndf_10IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(LEEE_1,NLA,ndf_1);





    //ndea = [[1/1000, 1/w]]omega_{ 1}
	static const IndexedLevel * const b3IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,(*new Ordinal(1000))),
		new IndexedLevel(Ordinal::one ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& ndea = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( b3IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM_LIM_ELT_TST(NEF,ndea);

    //ndeb = [[1/w]]omega_{ 1}
	static const IndexedLevel * const nde_12IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& ndeb = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( nde_12IndexedLevel, false)),
		NULL,Ordinal::zero
	)
	;
    NM_LIM_ELT_TST(NEF_1,ndeb);

    //ndeb_1 = [[5, 12/44, 19/omega_{ 3}]]omega_{ 19}
	static const IndexedLevel * const ndeb_11IndexedLevel[]= {
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(44))),
		new IndexedLevel((*new Ordinal(19)) ,admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& ndeb_1 = nestedEmbedFunctional(
		(*new Ordinal(19)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndeb_11IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM_LIM_ELT_TST(NEF_2,ndeb_1);

    //ndd = [[2, w]]omega_{ w}
	static const IndexedLevel * const ndd0IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ndd = nestedEmbedFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		(* new NestedEmbeddings( ndd0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM_LIM_ELT_TST(NEG,ndd);

    //neh = [[12/4, omega_{ 3}]]omega_{ omega_{ 4}}(w + 1)
	static const IndexedLevel * const neh3IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::four),
		new IndexedLevel(admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	) ,Ordinal::zero),
		NULL
	};
	const Ordinal& neh = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( neh3IndexedLevel, false)),
		createParameters(
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))))),
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(LCEL,NLA,neh);


}

static void nestedEmbedLimitEltExitCodeTest()
{

    bool doTest = true ;
    bool doTest2 = true ;
    int count = 10 ;
    
    // NDDKD


    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedEmbedLimitEltExitCodeTestNames(labOrds);

    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        // NLIM_ELT_TSTS((*iter)->name,(*iter)->ord);
        outStream() << "Test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " <<
            (*iter)->subName ;
        outStream() << " for " << (*iter)->ord.normalForm() << "\n" ;
        ((*iter)->ord).listElts(count,doTest); 
        if (doTest2) ((*iter)->ord).descend(3,10) ;

    }
}




/*
#define LIM_ORD_TST(code, base, arg) { \
    outStream() << "Test " << #code << "\n" ;\
    const Ordinal& le = (base).limitOrdCheck(arg) ; \
    outStream() << le.normalForm() << "\n" ;\
    assert((base).compare(le)>0); \
    const Ordinal& le999=(base).limitElement(999) ;\
    outStream() << le999.normalForm() << "\n" ;\
    }
*/

#define NM_LIM_ORD_TST(name,ordinal,pordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,NULL,pordinal))

#define NM2_LIM_ORD_TST(name,sname,ordinal,pordinal) \
    labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,pordinal))

void LabeledOrdinal:: nestedEmbedLimitOrdExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds)
{
    // bool doTest = true ;
    // bool ftst = doTest ;
    // int count = 8 ;

    //NM nestedEmbedLimitOrdExitCodeTestNames

    const Ordinal & twelve = * new Ordinal(12);
    const Ordinal& eps0Pw = * new Ordinal((eps0 + omega).getImpl()) ;
    const Ordinal& eps012 = *new Ordinal((eps0Pw + twelve).getImpl()) ;
    const Ordinal& bg =
        admisLevelFunctional(eps0,omega,
            createParameters(&Ordinal::one));

    const Ordinal& omega1 = admisLevelFunctional(Ordinal::one,Ordinal::zero);
    const Ordinal& omega1Pw = * new Ordinal((omega1+omega).getImpl()) ;
    const Ordinal& omega1PwP12 =
        * new Ordinal((omega1Pw + twelve).getImpl()) ;



    //nlvm1 = [[2/5, omega_{ 4}]]omega_{ omega_{ 5}}
	static const IndexedLevel * const nlvm11IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::five),
		new IndexedLevel(admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nlvm1 = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( nlvm11IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM2_LIM_ORD_TST(LOD,NOG,nlvm1,Ordinal::omega);
/*
    	//bb = [[omega_{ omega_{ 12}}, omega_{ omega_{ 15}}]]omega_{ omega_{ omega_{ w + 1}}}
	static const IndexedLevel * const bb0IndexedLevel[]= {
		new IndexedLevel(admisLevelFunctional(
		admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	)
,
		Ordinal::zero,
		NULL
	)
 ,Ordinal::zero),
		new IndexedLevel(admisLevelFunctional(
		admisLevelFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		NULL
	)
,
		Ordinal::zero,
		NULL
	)
 ,Ordinal::zero),
		NULL
	};
	const Ordinal& bb = nestedEmbedFunctional(
		admisLevelFunctional(
		admisLevelFunctional(
		* new Ordinal((expFunctional(Ordinal::one) + Ordinal::one)
            .getImpl()),
		Ordinal::zero,
		NULL
	)
,
		Ordinal::zero,
		NULL
	)
,
		Ordinal::zero,
		(* new NestedEmbeddings( bb0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    */

    //bb = [[omega_{ omega_{ 12}} + 1, omega_{ omega_{ 15}}]]omega_{ omega_{ omega_{ w + 1}}}
	static const IndexedLevel * const bb0IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(admisLevelFunctional(
		admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		new IndexedLevel(admisLevelFunctional(
		admisLevelFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	) ,Ordinal::zero),
		NULL
	};
	const Ordinal& bb = nestedEmbedFunctional(
		admisLevelFunctional(
		admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( bb0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;




    NM2_LIM_ORD_TST(LOD_1,NOG,bb,omega1);
    NM2_LIM_ORD_TST(LOD_2,NOG,bb,omega1Pw);
    NM2_LIM_ORD_TST(LOD_3,NOG,bb,omega1PwP12);

    //nx_10 = [[2, 5/omega_{ 1}]]omega_{ omega_{ 12}}
	static const IndexedLevel * const nx_100IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& nx_10 = nestedEmbedFunctional(
		admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( nx_100IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    
    NM2_LIM_ORD_TST(LOD_4,NOG,nx_10,Ordinal::omega);

    //nx11 = [[2/5, omega_{ 4}]]omega_{ omega_{ 5}}
	static const IndexedLevel * const nx111IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::five),
		new IndexedLevel(admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nx11 = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( nx111IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM2_LIM_ORD_TST(LOD_5,NOG,nx11,Ordinal::omega);

    //nilm = [[3, 4/omega_{ 1}]]omega_{ 4}
	static const IndexedLevel * const nilm0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& nilm = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( nilm0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    NM_LIM_ORD_TST(NOB,nilm,omega);


     
    //anli = [[3/56, 5/7, 8/omega_{ 3}]]omega_{ 8}
	static const IndexedLevel * const anli0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,(*new Ordinal(56))),
		new IndexedLevel(Ordinal::five ,(*new Ordinal(7))),
		new IndexedLevel((*new Ordinal(8)) ,admisLevelFunctional(
		Ordinal::three,
		Ordinal::zero,
		NULL
	)
),
		NULL
	};
	const Ordinal& anli = nestedEmbedFunctional(
		(*new Ordinal(8)),
		Ordinal::zero,
		(* new NestedEmbeddings( anli0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM_LIM_ORD_TST(NOB_1,anli,omega1);
    NM_LIM_ORD_TST(NOB_2,anli,omega1Pw);
    NM_LIM_ORD_TST(NOB_3,anli,omega1PwP12);


	//nilm1 = [[4, 4/omega_{ 1}]]omega_{ 4}
	static const IndexedLevel * const nilm11IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& nilm1 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( nilm11IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM_LIM_ORD_TST(NOB,nilm1,omega);

    //njlm = [[12/5, 12/omega_{ 2}]]omega_{ 12}
	static const IndexedLevel * const njlm0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::five),
		new IndexedLevel((*new Ordinal(12)) ,admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL
	)),
		NULL
	};
	const Ordinal& njlm = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( njlm0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM_LIM_ORD_TST(NOB_1,njlm,omega1);
    NM_LIM_ORD_TST(NOB_2,njlm,omega1Pw);
    NM_LIM_ORD_TST(NOB_3,njlm,omega1PwP12);




     //LIMITORD

    //  a=[[3,w_{2}]]w_{w_{2}}
    static const IndexedLevel * const a0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL
	)
 ,Ordinal::zero),
		NULL
	};
	const Ordinal& a = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL
	)
,
		Ordinal::zero,
		(* new NestedEmbeddings( a0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    NM_LIM_ORD_TST(NOC,a,twelve);

    NM_LIM_ORD_TST(NOC_1,a,omega);

    NM_LIM_ORD_TST(NOC_2,a,omega1);
    NM_LIM_ORD_TST(NOC_3,a,omega1Pw);
    NM_LIM_ORD_TST(NOC_4,a,omega1PwP12);



    
   
    

    
   	//LOIa = [[3/1, 5]]omega_{ 5}
	static const IndexedLevel * const LOIa0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::one),
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		NULL
	};
	const Ordinal& LOIa = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( LOIa0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


    
    NM2_LIM_ORD_TST(LOF_1,NOG,LOIa,omega1);
    NM2_LIM_ORD_TST(LOF_2,NOG,LOIa,omega1Pw);
    NM2_LIM_ORD_TST(LOF_3,NOG,LOIa,omega1PwP12);



    //loeh = [[3]]omega_{ omega_{ 2}}
	const Ordinal& loeh = admisLevelFunctional(
		admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;


	//loi = [[4]]omega_{ 6}
	const Ordinal& loi = admisLevelFunctional(
		Ordinal::six,
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::four, Embeddings::paramRestrict))
	)	;

    // NM2_LIM_ORD_TST(LOEH_1,LOB,loeh,omega1);
   	// NM2_LIM_ORD_TST(LOEH_2,LOB,loeh,omega1Pw);
    // NM2_LIM_ORD_TST(LOEH_3,LOB,loeh,omega1PwP12);

    NM_LIM_ORD_TST(LOD_1,loeh,omega1);
    NM_LIM_ORD_TST(LOD_2,loeh,omega1Pw);
    NM_LIM_ORD_TST(LOD_3,loeh,omega1PwP12);

    NM_LIM_ORD_TST(LOF_4,loi,omega1);
    NM_LIM_ORD_TST(LOF_5,loi,omega1Pw);
    NM_LIM_ORD_TST(LOF_6,loi,omega1PwP12);

    const Ordinal & lod = loi.limitOrd(loeh);

    NM_LIM_ORD_TST(LOA_4,lod,omega1);
    NM_LIM_ORD_TST(LOA_5,lod,omega1Pw);
    NM_LIM_ORD_TST(LOA_6,lod,omega1PwP12);

  	//xb = [[4/1, 5]]omega_{ 5}(omega_{ 4})
	static const IndexedLevel * const xb1IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		NULL
	};
	const Ordinal& xb = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( xb1IndexedLevel, false)),
		createParameters(
			&(admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL
	))),
		Ordinal::zero
	)
	;

    
     // NM2_LIM_ORD_TST(FPB_7,ILOC,xb,omega1);
     // NM2_LIM_ORD_TST(FPB_8,ILOC,xb,omega1Pw);
     // NM2_LIM_ORD_TST(FPB_0,ILOC,xb,omega1PwP12);

     NM2_LIM_ORD_TST(OFB_7,NOG,xb,omega1);
     NM2_LIM_ORD_TST(OFB_8,NOG,xb,omega1Pw);
     NM2_LIM_ORD_TST(OFB_0,NOG,xb,omega1PwP12);

    
    
    
}
/*
#define LIM_ORD_TST(code, base, arg) { \
    outStream() << "Test " << #code << "\n" ;\
    const Ordinal& le = (base).limitOrdCheck(arg) ; \
    assert((base).compare(le)>0); \
    assert(le.compare((base).limitElement(999)<0)); \
    le.listElts(count,doTest);\
    le.descend(3,4); \
    for (int i = 0 ; const Ordinal *ord = params[i]; i++) {\
        if (base.limitType().compare(ord->maxLimitType())>0) { \
            const Ordinal &le = base.limitOrdCheck(*ord);\
            le.listElts(5,doTest);\
            le.descend(3,4); \
        }\
    }\
}
*/

void Validate::nestedLimitOrdExitCodeTest()
{
    bool doTest = true ;
    bool ftst = doTest ;
    int count = 8 ;

    const Ordinal & twelve = * new Ordinal(12);
    const Ordinal& eps0Pw = * new Ordinal((eps0 + omega).getImpl()) ;
    const Ordinal& eps012 = *new Ordinal((eps0Pw + twelve).getImpl()) ;
    const Ordinal& bg =
        admisLevelFunctional(eps0,omega,createParameters(&Ordinal::one));
    const Ordinal& bgp = bg + eps012 ;
    const Ordinal * params[] = {
        &Ordinal::omega,
        &eps0,
        &eps012,
        &eps0Pw,
        &omega1CK,
        &bg,
        &bgp,
        NULL
    };

    
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedEmbedLimitOrdExitCodeTestNames(labOrds) ;

     for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        outStream() << "Test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " <<
            (*iter)->subName ;
        outStream() << "\n" ;
        const Ordinal& base = (*iter)->ord ;
        const Ordinal& arg = (*iter)->ordp ;
        const Ordinal& le = (base).limitOrdCheck(arg) ; 
        int df = base.compare(le) ;
        assert(df>0);
        if (!arg.isFinite()) {
            outStream() << "base = " << base.normalForm() << "\n" ;
            outStream() << "arg = " << arg.normalForm() << "\n" ;
            outStream() <<"le = " << le.normalForm() << "\n" ;
            const Ordinal& le999 = base.limitElement(999);
            int df = le.compare(le999);
            outStream() <<"le999 = " << le999.normalForm() << 
                ", df = "<<df<<"\n";
            assert(df > 0);
        }
       // assert(le.compare((base).limitElement(999)<0));
       le.listElts(count,doTest);
       le.descend(3,4);
       for (int i = 0 ; const Ordinal *ord = params[i]; i++) {
           // if (base.limitType().compare(ord->maxLimitType())>0) { 
               if (base.isValidLimitOrdParam(*ord)) {
               const Ordinal &le = base.limitOrdCheck(*ord);
               le.listElts(5,doTest);
               le.descend(3,4); 
            }
        }
    }
}


static void ckRel(const Ordinal& a, const Ordinal& b)
{
        bool alb = a<b ; 
        bool agb = a>b ;
        bool aeb = a==b ;
        bool bla = b < a ;
        bool bga = b > a ;
        bool bea = b == a ;
        outStream() << a.normalForm() << " < " << b.normalForm() << " = " << alb << "\n";
        outStream() << a.normalForm() << " > " << b.normalForm() << " = " << agb << "\n";
        outStream() << a.normalForm() << " == " << b.normalForm() << " = " << aeb << "\n";
        if (alb) assert(!agb && !aeb && !bla && bga && !bea);
        else if (agb) assert(!alb && !aeb && bla && !bga && !bea);
        else assert(!alb && !agb && aeb && !bla && !bga && bea);

}

#define CMP_TEST(code, a, b) \
    outStream() << "Cmp test "  << #code <<  " for " << a.normalForm() \
        << ", " << b.normalForm() << "\n" ; ckRel(a,b);

void Validate::nestedCmpExitCodeTest()
{
    bool saveCmpTest = Validate::validationCmpTest ;
    Validate::validationCmpTest = true ;


    //ea = [[3, 5/2]]omega_{ 5}
	static const IndexedLevel * const ea0IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,Ordinal::two),
		NULL
	};
	const Ordinal& ea = nestedEmbedFunctional(
		Ordinal::five,
		Ordinal::zero,
		(* new NestedEmbeddings( ea0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//eb = [[3, 5/1]]omega_{ omega_{ 1}}
	static const IndexedLevel * const eb1IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,Ordinal::one),
		NULL
	};
	const Ordinal& eb = nestedEmbedFunctional(
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		(* new NestedEmbeddings( eb1IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


    CMP_TEST(NEA2_X,ea,eb);

    //a = [[w + 1, w + 1/1]]omega_{ w + 1, omega_{ ( w^w )}}
	static const IndexedLevel * const a0IndexedLevel[]= {
		new IndexedLevel(expFunctional(Ordinal::one) + Ordinal::one ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) + Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& a = nestedEmbedFunctional(
		expFunctional(Ordinal::one) + Ordinal::one,
		admisLevelFunctional(
		expFunctional(expFunctional(Ordinal::one)),
		Ordinal::zero,
		NULL
	),
		(* new NestedEmbeddings( a0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//b = [[w + 1, w + 1/1]]omega_{ w + 1}
	static const IndexedLevel * const b1IndexedLevel[]= {
		new IndexedLevel(expFunctional(Ordinal::one) + Ordinal::one ,Ordinal::zero),
		new IndexedLevel(expFunctional(Ordinal::one) + Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& b = nestedEmbedFunctional(
		expFunctional(Ordinal::one) + Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( b1IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    CMP_TEST(NEA1_X,a,b);


    //nea1_a = [[12, 19]]omega_{ 12, omega_{ 13} + 1}
	static const IndexedLevel * const nea1_a0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(19)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nea1_a = nestedEmbedFunctional(
		(*new Ordinal(19)),
		admisLevelFunctional(
		(*new Ordinal(13)),
		Ordinal::zero,
		NULL
	) + Ordinal::one,
		(* new NestedEmbeddings( nea1_a0IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//nea1_b = [[12, 19]]omega_{ 12, omega_{ 11} + 1}
	static const IndexedLevel * const nea1_b1IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(19)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& nea1_b = nestedEmbedFunctional(
		(*new Ordinal(19)),
		admisLevelFunctional(
		(*new Ordinal(11)),
		Ordinal::zero,
		NULL
	) + Ordinal::one,
		(* new NestedEmbeddings( nea1_b1IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    CMP_TEST(NEA1,nea1_a,nea1_b);


	//nea2_a = [[12/35, 12/37]]omega_{ 12}
	static const IndexedLevel * const nea2_a2IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(35))),
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(37))),
		NULL
	};
	const Ordinal& nea2_a = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( nea2_a2IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//nea2_b = [[12/35, 12/36]]omega_{ 12}
	static const IndexedLevel * const nea2_b3IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(35))),
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(36))),
		NULL
	};
	const Ordinal& nea2_b = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( nea2_b3IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//nea2_c = [[12/13]]omega_{ ( w^w )}
	static const IndexedLevel * const nea2_c4IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(13))),
		NULL
	};
	const Ordinal& nea2_c = nestedEmbedFunctional(
		expFunctional(expFunctional(Ordinal::one)),
		Ordinal::zero,
		(* new NestedEmbeddings( nea2_c4IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//nea2_d = [[12/14]]omega_{ 12}
	static const IndexedLevel * const nea2_d5IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(14))),
		NULL
	};
	const Ordinal& nea2_d = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( nea2_d5IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;
    CMP_TEST(NEA2_1,nea2_a,nea2_b);
    CMP_TEST(NEA2_2,nea2_c,nea2_d);
    CMP_TEST(NEA2_3,nea2_c,nea2_a);
    CMP_TEST(NEA2_4,nea2_c,nea2_b);
    CMP_TEST(NEA2_5,nea2_d,nea2_a);
    CMP_TEST(NEA2_6,nea2_d,nea2_b);


	//nea3_a = [[1/12]]omega_{ 1}
	static const IndexedLevel * const nea3_a6IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,(*new Ordinal(12))),
		NULL
	};
	const Ordinal& nea3_a = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( nea3_a6IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//nea3_b = psi_{ ( w^w )}(w, w, w)
	const Ordinal& nea3_b = iterativeFunctional(
		expFunctional(expFunctional(Ordinal::one)),
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one))	;

    CMP_TEST(NEA3,nea3_a,nea3_b);

	//neca_a = [[1/1]]omega_{ 1}
	static const IndexedLevel * const neca_a7IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& neca_a = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( neca_a7IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//neca_b = omega_{ 1}
	const Ordinal& neca_b = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)	;


	//neca_c = [[2/1]]omega_{ 2}
	static const IndexedLevel * const neca_c8IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::one),
		NULL
	};
	const Ordinal& neca_c = nestedEmbedFunctional(
		Ordinal::two,
		Ordinal::zero,
		(* new NestedEmbeddings( neca_c8IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;

    CMP_TEST(NECA_1,neca_a,neca_b);
    CMP_TEST(NEA2_7,neca_a,neca_c);
    CMP_TEST(NECA_3,neca_b,neca_c);

    //necz_a = [[3, 4/w]]omega_{ 12, w}(w, ( w^w ), 7)
	static const IndexedLevel * const necz_a2IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& necz_a = nestedEmbedFunctional(
		(*new Ordinal(12)),
		expFunctional(Ordinal::one),
		(* new NestedEmbeddings( necz_a2IndexedLevel, false)),
		createParameters(
			&(expFunctional(Ordinal::one)),
			&(expFunctional(expFunctional(Ordinal::one))),
			&((*new Ordinal(7)))),
		Ordinal::zero
	)
	;

	//necz_b = [[3, 4/w]]omega_{ 12, w}(w, ( w^w ), 6)
	static const IndexedLevel * const necz_b3IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,expFunctional(Ordinal::one)),
		NULL
	};
	const Ordinal& necz_b = nestedEmbedFunctional(
		(*new Ordinal(12)),
		expFunctional(Ordinal::one),
		(* new NestedEmbeddings( necz_b3IndexedLevel, false)),
		createParameters(
			&(expFunctional(Ordinal::one)),
			&(expFunctional(expFunctional(Ordinal::one))),
			&(Ordinal::six)),
		Ordinal::zero
	)
	;


    CMP_TEST(NECZ,necz_a,necz_b);


    Validate::validationCmpTest = saveCmpTest ;
}

#define MACRO(name) labOrds.push_back \
    (new LabeledOrdinal(#name,name,NULL,Ordinal::zero, \
    (Act) (setNames|output)))
// #define MACRO(nm) NM_LIM_ELT_TST(nm,nm)

void LabeledOrdinal::transitionTestNames(
    list<LabeledOrdinal*>& labOrds)
{

    // NM transitionTestNames
    
	//a = omega_{ 1}[ 1]
	const Ordinal& a = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one
	)	;

	MACRO(a);


	//a5 = omega_{ 1}[ 5]
	const Ordinal& a5 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::five
	)	;

	MACRO(a5);


	//aw = omega_{ 1}[ w]
	const Ordinal& aw = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		expFunctional(Ordinal::one)
	)	;

	MACRO(aw);


	//b = [[1]]omega_{ 1}[[ 1]]
	const Ordinal& b = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)	;

	MACRO(b);


	//b5 = [[1]]omega_{ 1}[[ 5]]
	const Ordinal& b5 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::five,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)	;

	MACRO(b5);


	//bw = [[1]]omega_{ 1}[[ 1]]
	const Ordinal& bw = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)	;

	MACRO(bw);


	//c = [[1/1]]omega_{ 1}[ 1]
	static const IndexedLevel * const c0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& c = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( c0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

	MACRO(c);


	//c5 = [[1/1]]omega_{ 1}[ 5]
	static const IndexedLevel * const c51IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& c5 = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( c51IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;

	MACRO(c5);


	//cw = [[1, 1/1]]omega_{ 1}[ w]
	static const IndexedLevel * const cw2IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& cw = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( cw2IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;

	MACRO(cw);


	//d = [[1, 1/1]]omega_{ 1}[ 1]
	static const IndexedLevel * const d3IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& d = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( d3IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

	MACRO(d);


	//d5 = [[1, 1/1]]omega_{ 1}[ 5]
	static const IndexedLevel * const d54IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& d5 = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( d54IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;

	MACRO(d5);


	//dw = [[1, 1/1]]omega_{ 1}[ w]
	static const IndexedLevel * const dw5IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::one ,Ordinal::one),
		NULL
	};
	const Ordinal& dw = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( dw5IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;

	MACRO(dw);


	//e = [[4, 4/1]]omega_{ 4}[ 1]
	static const IndexedLevel * const e6IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& e = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( e6IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

	MACRO(e);


	//e5 = [[4, 4/1]]omega_{ 4}[ 5]
	static const IndexedLevel * const e57IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& e5 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( e57IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;

	MACRO(e5);


	//ew = [[4, 4/1]]omega_{ 4}[ w]
	static const IndexedLevel * const ew8IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& ew = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( ew8IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;

	MACRO(ew);


	//f = [[3, 4, 4/1]]omega_{ 4}[ 1]
	static const IndexedLevel * const f9IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& f = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( f9IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

	MACRO(f);

	//f5 = [[3, 4, 4/1]]omega_{ 4}[ 5]
	static const IndexedLevel * const f510IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& f5 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( f510IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;

	MACRO(f5);

	//fw = [[3, 4, 4/1]]omega_{ 4}[ w]
	static const IndexedLevel * const fw11IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& fw = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( fw11IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;

	MACRO(fw);


	//g = [[3, 4/7, 4/8]]omega_{ 4}[ 1]
	static const IndexedLevel * const g12IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(7))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(8))),
		NULL
	};
	const Ordinal& g = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( g12IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

	MACRO(g);


	//g5 = [[3, 4/7, 4/8]]omega_{ 4}[ 5]
	static const IndexedLevel * const g513IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(7))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(8))),
		NULL
	};
	const Ordinal& g5 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( g513IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;

	MACRO(g5);


	//gw = [[3, 4/7, 4/8]]omega_{ 4}[ w]
	static const IndexedLevel * const gw14IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(7))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(8))),
		NULL
	};
	const Ordinal& gw = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( gw14IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;

	MACRO(gw);


	//h = [[4/6, 4/7, 4/8]]omega_{ 4}[ 1]
	static const IndexedLevel * const h15IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(7))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(8))),
		NULL
	};
	const Ordinal& h = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( h15IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

	MACRO(h);


	//h5 = [[4/6, 4/7, 4/8]]omega_{ 4}[ 5]
	static const IndexedLevel * const h516IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(7))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(8))),
		NULL
	};
	const Ordinal& h5 = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( h516IndexedLevel, false)),
		NULL,
		Ordinal::five
	)
	;

	MACRO(h5);


	//hw = [[4/6, 4/7, 4/8]]omega_{ 4}[ w]
	static const IndexedLevel * const hw17IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::six),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(7))),
		new IndexedLevel(Ordinal::four ,(*new Ordinal(8))),
		NULL
	};
	const Ordinal& hw = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( hw17IndexedLevel, false)),
		NULL,
		expFunctional(Ordinal::one)
	)
	;

	MACRO(hw);

    //ndwd = [[1, 2, 3, 4, w + 1]]omega_{ w + 1}[ 1]
	static const IndexedLevel * const ndwd0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& ndwd = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ndwd0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    MACRO(ndwd);
}

void  LabeledOrdinal::admisLimitOrdExampleNames(
    list<LabeledOrdinal*>& labOrds)
{
/*
a = omega_{ 1}
b = omega_{ 2}
c = (omega_{ 1}*4)
d = ( w^(omega_{ 1}*2) )
e = omega_{ omega_{ omega_{ 1} + 1}}(omega_{ omega_{ 1} + 1})
f = omega_{ omega_{ 1} + 1}
g = omega_{ 1, omega_{ 1}}
h = omega_{ 100}
i = omega_{ 1, 1}(omega_{ 1})
j = omega_{ 1, 3}(omega_{ 1})
k = omega_{ epsilon( 0)}(omega_{ 1})
l = omega_{ epsilon( 0) + 1}(1)
m = omega_{ epsilon( 0), w} + ( w^( omega_{ 1} + 1 ) )
%Total 13 variables listed.
*/

	//a = omega_{ 1}
	const Ordinal& a = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)	;
    
    MACRO(a);

	//b = omega_{ 2}
	const Ordinal& b = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL
	)	;

    MACRO(b);

	//c = (omega_{ 1}*4)
	const Ordinal& c = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)	;

    MACRO(c);

	//d = ( w^(omega_{ 1}*2) )
	const Ordinal& d = expFunctional(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	))	;

    MACRO(d);

	//e = omega_{ omega_{ omega_{ 1} + 1}}(omega_{ omega_{ 1} + 1})
	const Ordinal& e = admisLevelFunctional(
		admisLevelFunctional(
		( * new Ordinal(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		createParameters(
			&(admisLevelFunctional(
		( * new Ordinal(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::zero,
		NULL
	)))
	)	;
    MACRO(e);


	//f = omega_{ omega_{ 1} + 1}
	const Ordinal& f = admisLevelFunctional(
		( * new Ordinal(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::zero,
		NULL
	)	;
    MACRO(f);


	//g = omega_{ 1, omega_{ 1}}
	const Ordinal& g = admisLevelFunctional(
		Ordinal::one,
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	),
		NULL
	)	;

    MACRO(g);

	//h = omega_{ 100}
	const Ordinal& h = admisLevelFunctional(
		(*new Ordinal(100)),
		Ordinal::zero,
		NULL
	)	;

    MACRO(h);

	//i = omega_{ 1, 1}(omega_{ 1})
	const Ordinal& i = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)))
	)	;
    MACRO(i);


	//j = omega_{ 1, 3}(omega_{ 1})
	const Ordinal& j = admisLevelFunctional(
		Ordinal::one,
		Ordinal::three,
		createParameters(
			&(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)))
	)	;
    MACRO(j);


	//k = omega_{ epsilon( 0)}(omega_{ 1})
	const Ordinal& k = admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		Ordinal::zero,
		createParameters(
			&(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)))
	)	;

    MACRO(k);

	//l = omega_{ epsilon( 0) + 1}(1)
	const Ordinal& l = admisLevelFunctional(
		( * new Ordinal(psi( Ordinal::one, Ordinal::zero).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::zero,
		createParameters(
			&(Ordinal::one))
	)	;
    MACRO(l);


	//m = omega_{ epsilon( 0), w} + ( w^( omega_{ 1} + 1 ) )
	const Ordinal& m = ( * new Ordinal(admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		expFunctional(Ordinal::one),
		NULL
	).getImpl()
	.addLoc(expFunctional(( * new Ordinal(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::one)))))))	;
    MACRO(m);

    //n = [[12]]omega_{ 15, omega_{ 10}}
	const Ordinal& n = admisLevelFunctional(
		(*new Ordinal(15)),
		admisLevelFunctional(
		(*new Ordinal(10)),
		Ordinal::zero,
		NULL
	),
		NULL,
		Ordinal::zero,
		(* new Embeddings((*new Ordinal(12)), Embeddings::paramRestrict))
	)	;

    MACRO(n);

    {
        //a = [[2, 3]]omega_{ 4}[ 1]
	static const IndexedLevel * const a0IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		NULL
	};
	const Ordinal& a = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( a0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;


	//b = [[3]]omega_{ 4}[ 1]
	const Ordinal& b = admisLevelFunctional(
		Ordinal::four,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;


	//c = [[2, 4]]omega_{ 4}[ 1]
	static const IndexedLevel * const c1IndexedLevel[]= {
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& c = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( c1IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;


	//d = [[4, 4/1]]omega_{ 4}[ 1]
	static const IndexedLevel * const d2IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& d = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( d2IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    //e = [[4, 4/1]]omega_{ 4}
	static const IndexedLevel * const e6IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		NULL
	};
	const Ordinal& e = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( e6IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//f = [[4/1, 4/2]]omega_{ 4}[ 1]
	static const IndexedLevel * const f7IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::one),
		new IndexedLevel(Ordinal::four ,Ordinal::two),
		NULL
	};
	const Ordinal& f = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( f7IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    /*
    
	static const IndexedLevel * const g18IndexedLevel[]= {
		new IndexedLevel(Ordinal::four ,Ordinal::two),
		NULL
	};
	const Ordinal& g = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( g18IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    */


    MACRO(a);
    MACRO(b);
    MACRO(c);
    MACRO(d);
    MACRO(e);
    MACRO(f);
    // MACRO(g);  // takes about 40 seconds

    }


}

void typeTransitionTest()
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 7 ;


    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::transitionTestNames(labOrds) ;
    
    
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {

        outStream() << "Transition test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " << (*iter)->subName ;
        outStream() << " for " << (*iter)->ord.normalForm() << "\n" ;
        ((*iter)->ord).listElts(count,doTest); 
        if (doTest2) ((*iter)->ord).descend(3,10) ;

    }

}
