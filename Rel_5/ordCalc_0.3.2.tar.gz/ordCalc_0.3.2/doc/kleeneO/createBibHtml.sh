    latex $1.tex
	bibtex $1
	latex $1.tex
    rm $1.pdf
	tth -i $1.tex
    mv $1.html htdocs/axioms
    perl htdocs/useHeaders.pl htdocs/axioms/$1.html
    perl htdocs/useHeaders.pl htdocs/axioms/$1.html
    perl htdocs/useHeaders.pl htdocs/axioms/$1.html

