char * readline(const char * prompt);

void using_history();
void add_history(char * buf);
