
	//a = psi( w, w )
	const Ordinal& a = psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))	;


	//b = psi( w, w, 1, 2, 12 )
	const Ordinal& b = finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))	;


	//c = psi( w, w, 1, 2, 12, ( w^w ), 14, 7 )
	const Ordinal& c = finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))	;


	//d = psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 )
	const Ordinal * const d0Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& d = finiteFunctional( d0Params)	;


	//e = psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) )
	const Ordinal * const e1Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& e = finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( e1Params),
		expFunctional(expFunctional(Ordinal::one)))	;


	//f = psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) )
	const Ordinal * const f2Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& f = finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( f2Params),
		expFunctional(expFunctional(Ordinal::one)))	;


	//g = psi( w, w )
	const Ordinal& g = psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))	;


	//g1 = psi( w, w, 1, 2, 12 )
	const Ordinal& g1 = finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))	;


	//g2 = psi( w, w, 1, 2, 12, ( w^w ), 14, 7 )
	const Ordinal& g2 = finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))	;


	//g3 = psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 )
	const Ordinal * const g33Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& g3 = finiteFunctional( g33Params)	;


	//h = psi_{ w}(3, 2)
	const Ordinal& h = iterativeFunctional(
		expFunctional(Ordinal::one),
		Ordinal::three,
		Ordinal::two)	;


	//i = psi_{ psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) )}(psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), psi_{ w}(3, 2), ( w^w ), 45, 56)
	const Ordinal * const i7Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const i6Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const i5Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const i4Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& i = iterativeFunctional(
		finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( i4Params),
		expFunctional(expFunctional(Ordinal::one))),
		createParameters(
			&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
			&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
			&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
			&(finiteFunctional( i5Params)),
			&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( i6Params),
		expFunctional(expFunctional(Ordinal::one)))),
			&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( i7Params),
		expFunctional(expFunctional(Ordinal::one)))),
			&(iterativeFunctional(
		expFunctional(Ordinal::one),
		Ordinal::three,
		Ordinal::two)),
			&(expFunctional(expFunctional(Ordinal::one))),
			&((*new Ordinal(45))),
			&((*new Ordinal(56))),
			NULL)
		)	;


	//j = psi_{ psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) )}(1, 2, 3, 4, 5, psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ))
	const Ordinal * const j10Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const j9Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const j8Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& j = iterativeFunctional(
		finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( j8Params),
		expFunctional(expFunctional(Ordinal::one))),
		createParameters(
			&(Ordinal::one),
			&(Ordinal::two),
			&(Ordinal::three),
			&(Ordinal::four),
			&(Ordinal::five),
			&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
			&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
			&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
			&(finiteFunctional( j9Params)),
			&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( j10Params),
		expFunctional(expFunctional(Ordinal::one)))),
			NULL)
		)	;


	//k = omega_{ 12}
	const Ordinal& k = admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	)	;


	//l = omega_{ 12, 1}(psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), 1, 2, 3, 4, 5)
	const Ordinal * const l12Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const l11Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& l = admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::one,
		createParameters(
			&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
			&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
			&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
			&(finiteFunctional( l11Params)),
			&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( l12Params),
		expFunctional(expFunctional(Ordinal::one)))),
			&(Ordinal::one),
			&(Ordinal::two),
			&(Ordinal::three),
			&(Ordinal::four),
			&(Ordinal::five))
	)	;


	//m = omega_{ psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) )}(omega_{ 12}, omega_{ 12, 1}(psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), 1, 2, 3, 4, 5), psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), 1, 2, 3, 4, 5)
	const Ordinal * const m19Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const m18Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const m17Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const m16Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const m15Params[] = {
		&(admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	)),
		&(admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::one,
		createParameters(
			&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
			&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
			&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
			&(finiteFunctional( m16Params)),
			&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( m17Params),
		expFunctional(expFunctional(Ordinal::one)))),
			&(Ordinal::one),
			&(Ordinal::two),
			&(Ordinal::three),
			&(Ordinal::four),
			&(Ordinal::five))
	)),
		&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
		&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
		&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
		&(finiteFunctional( m18Params)),
		&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( m19Params),
		expFunctional(expFunctional(Ordinal::one)))),
		&(Ordinal::one),
		&(Ordinal::two),
		&(Ordinal::three),
		&(Ordinal::four),
		&(Ordinal::five),
		NULL
	};
	const Ordinal * const m14Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const m13Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& m = admisLevelFunctional(
		finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( m13Params),
		expFunctional(expFunctional(Ordinal::one))),
		finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( m14Params),
		expFunctional(expFunctional(Ordinal::one))),
		m15Params
	)	;


	//n = omega_{ 12}[ 4]
	const Ordinal& n = admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL,
		Ordinal::four
	)	;


	//o = [[psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ) + 1]]omega_{ psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ) + 1, psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) )}(omega_{ 12}, omega_{ 12, 1}(psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), 1, 2, 3, 4, 5), psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( psi( w, w ), psi( w, w, 1, 2, 12 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7 ), psi( w, w, 1, 2, 12, ( w^w ), 14, 7, w, w, 1, 2, 12, ( w^w ), 14, 7 ), ( w^w ) ), 1, 2, 3, 4, 5)
	const Ordinal * const o27Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const o26Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const o25Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const o24Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const o23Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const o22Params[] = {
		&(admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	)),
		&(admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::one,
		createParameters(
			&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
			&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
			&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
			&(finiteFunctional( o23Params)),
			&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( o24Params),
		expFunctional(expFunctional(Ordinal::one)))),
			&(Ordinal::one),
			&(Ordinal::two),
			&(Ordinal::three),
			&(Ordinal::four),
			&(Ordinal::five))
	)),
		&(psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one))),
		&(finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12)))),
		&(finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL))),
		&(finiteFunctional( o25Params)),
		&(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( o26Params),
		expFunctional(expFunctional(Ordinal::one)))),
		&(Ordinal::one),
		&(Ordinal::two),
		&(Ordinal::three),
		&(Ordinal::four),
		&(Ordinal::five),
		NULL
	};
	const Ordinal * const o21Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal * const o20Params[] = {
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		&(expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))),
		NULL
	};
	const Ordinal& o = admisLevelFunctional(
		( * new Ordinal(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( o20Params),
		expFunctional(expFunctional(Ordinal::one))).getImpl()
	.addLoc(Ordinal::one))),
		finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( o21Params),
		expFunctional(expFunctional(Ordinal::one))),
		o22Params,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(finiteFunctional(
		psi( expFunctional(Ordinal::one), expFunctional(Ordinal::one)),
		finiteFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::two,
		(*new Ordinal(12))),
		finiteFunctional(createParameters( &(
		expFunctional(Ordinal::one)),
		&(expFunctional(Ordinal::one)),
		&(Ordinal::one),
		&(Ordinal::two),
		&((*new Ordinal(12))),
		&(expFunctional(expFunctional(Ordinal::one))),
		&((*new Ordinal(14))),
		&((*new Ordinal(7))), NULL)),
		finiteFunctional( o27Params),
		expFunctional(expFunctional(Ordinal::one))).getImpl()
	.addLoc(Ordinal::one))), Embeddings::paramRestrict))
	)	;


	//p = [[1/12, 2/11, 3/1, 4]]omega_{ 4}
	static const IndexedLevel * const p28IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,(*new Ordinal(12))),
		new IndexedLevel(Ordinal::two ,(*new Ordinal(11))),
		new IndexedLevel(Ordinal::three ,Ordinal::one),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		NULL
	};
	const Ordinal& p = nestedEmbedFunctional(
		Ordinal::four,
		Ordinal::zero,
		(* new NestedEmbeddings( p28IndexedLevel, false)),
		NULL,
		Ordinal::zero
	)
	;


	//q = (( w^5 )*3 )
	const Ordinal& q = expFunctional(Ordinal::five, 3)	;


	//r = (psi( 3, w, 13, 5 )*105)
	const Ordinal& r = finiteFunctional(createParameters( &(
		Ordinal::three),
		&(expFunctional(Ordinal::one)),
		&((*new Ordinal(13))),
		&(Ordinal::five), NULL), 105)	;


	//s = (psi( 3, 5 )*15)
	const Ordinal& s = finiteFunctional(createParameters( &(
		Ordinal::three),
		&(Ordinal::five), NULL), 15)	;


	//t = (psi_{ w + 5}(12, 13, w + 1)*54)
	const Ordinal& t = iterativeFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::five))),
		createParameters(
			&((*new Ordinal(12))),
			&((*new Ordinal(13))),
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one)))),
			NULL), 54
		)	;


	//u = (omega_{ w, 14}(3, 4, 12)*9)
	const Ordinal& u = admisLevelFunctional(
		expFunctional(Ordinal::one),
		(*new Ordinal(14)),
		createParameters(
			&(Ordinal::three),
			&(Ordinal::four),
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings(Ordinal::zero, Embeddings::none)), 9
	)	;


	//v = ([[12]]omega_{ w + 5, w + 3}(w, w, w)*99)
	const Ordinal& v = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::five))),
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::three))),
		createParameters(
			&(expFunctional(Ordinal::one)),
			&(expFunctional(Ordinal::one)),
			&(expFunctional(Ordinal::one))),
		Ordinal::zero,
		(* new Embeddings((*new Ordinal(12)), Embeddings::paramRestrict)), 99
	)	;


	//x = ([[12]]omega_{ 55}[[ 45]]*1000)
	const Ordinal& x = admisLevelFunctional(
		(*new Ordinal(55)),
		Ordinal::zero,
		NULL,
		(*new Ordinal(45)),
		(* new Embeddings((*new Ordinal(12)), Embeddings::paramRestrict, true)), 1000
	)	;


	//y = ([[12/w + 1]]omega_{ 45, 5}(1, 2, 3)*12)
	static const IndexedLevel * const y29IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one)))),
		NULL
	};
	const Ordinal& y = nestedEmbedFunctional(
		(*new Ordinal(45)),
		Ordinal::five,
		(* new NestedEmbeddings( y29IndexedLevel, false)),
		createParameters(
			&(Ordinal::one),
			&(Ordinal::two),
			&(Ordinal::three)),
		Ordinal::zero, 12
	)
	;

	outStream() << "$$ a = " << a.texNormalForm() << " $$\n" ; 
	outStream() << "$$ b = " << b.texNormalForm() << " $$\n" ; 
	outStream() << "$$ c = " << c.texNormalForm() << " $$\n" ; 
	outStream() << "$$ d = " << d.texNormalForm() << " $$\n" ; 
	outStream() << "$$ e = " << e.texNormalForm() << " $$\n" ; 
	outStream() << "$$ f = " << f.texNormalForm() << " $$\n" ; 
	outStream() << "$$ g = " << g.texNormalForm() << " $$\n" ; 
	outStream() << "$$ g1 = " << g1.texNormalForm() << " $$\n" ; 
	outStream() << "$$ g2 = " << g2.texNormalForm() << " $$\n" ; 
	outStream() << "$$ g3 = " << g3.texNormalForm() << " $$\n" ; 
	outStream() << "$$ h = " << h.texNormalForm() << " $$\n" ; 
	outStream() << "$$ i = " << i.texNormalForm() << " $$\n" ; 
	outStream() << "$$ j = " << j.texNormalForm() << " $$\n" ; 
	outStream() << "$$ k = " << k.texNormalForm() << " $$\n" ; 
	outStream() << "$$ l = " << l.texNormalForm() << " $$\n" ; 
	outStream() << "$$ m = " << m.texNormalForm() << " $$\n" ; 
	outStream() << "$$ n = " << n.texNormalForm() << " $$\n" ; 
	outStream() << "$$ o = " << o.texNormalForm() << " $$\n" ; 
	outStream() << "$$ p = " << p.texNormalForm() << " $$\n" ; 
	outStream() << "$$ q = " << q.texNormalForm() << " $$\n" ; 
	outStream() << "$$ r = " << r.texNormalForm() << " $$\n" ; 
	outStream() << "$$ s = " << s.texNormalForm() << " $$\n" ; 
	outStream() << "$$ t = " << t.texNormalForm() << " $$\n" ; 
	outStream() << "$$ u = " << u.texNormalForm() << " $$\n" ; 
	outStream() << "$$ v = " << v.texNormalForm() << " $$\n" ; 
	outStream() << "$$ x = " << x.texNormalForm() << " $$\n" ; 
	outStream() << "$$ y = " << y.texNormalForm() << " $$\n" ; 
