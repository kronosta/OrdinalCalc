
if make msfCnv.exe ;then bash srkTest.sh 
else echo make failed ;fi

