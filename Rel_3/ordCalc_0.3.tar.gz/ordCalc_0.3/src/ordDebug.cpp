#include "stdafx.h"


#include <string>
#include <stdlib.h>

#include "ordDebug.h"

void ord::checkMemory(const char * where)
{
    ord::outDbgStream() << "checkMemory(" << where << ") enter\n" ;
    static const int randLim = 0xff;
    static const int size = 100 ;

    char chars[randLim+1] ;
    chars[randLim]=0;

    int sizes[size] ;
    char * arys[size] ;
    string * strings[size] ;

    for (int i = 0 ; i < randLim ; i++) {
        chars[i] = rand()&63 ;
    }

    for (int i = 0 ; i < size; i++) {
        int n = sizes[i] = (rand() && 255) | 3;
        arys[i] = new char[n] ;
        strings[i] = new string ;
        strings[i]->append(chars,n);
    }
    for (int i = size -1; i > -1; i--) {
        for (int j = 0 ; j <sizes[i]; j++) arys[i][j]=chars[randLim -1 -j];
    }

    for (int i = 0 ; i < size; i++) {
        delete strings[i] ;
        delete arys[i] ;
    }
    ord::outDbgStream() << "checkMemory(" << where << ") exit\n" ;
}
