mv ordCalc.idx bordCalc.idx
fgrep -v '\Cpp'  bordCalc.idx > ordCalc.idx
./indextex -t -d -o ordCalc > err 2>&1
