#ifndef INDEXED_LEVEL_H
#define INDEXED_LEVEL_H

using namespace std ;
	
namespace ord {

    class Ordinal;

    struct IndexedLevel {
        const Ordinal& level ;
        const Ordinal& index ;
        IndexedLevel(const Ordinal&lev, const Ordinal&ind):
            level(lev),index(ind){}
        IndexedLevel(const Ordinal&lev);
        const int compare(const IndexedLevel& ixl) const {
            int diff = level.compare(ixl.level) ;
            if (diff) return diff ;
            return index.compare(ixl.index) ;
        }

        static const IndexedLevel * const * ary(const Ordinal&lev,
            const Ordinal&ind)
        {
            const IndexedLevel ** ret = new  const IndexedLevel * [2];
            ret[0] = new IndexedLevel(lev,ind);
            ret[1] = NULL;
            return ret ;

        }
        virtual string normalForm() const ;
    };
}

#endif
