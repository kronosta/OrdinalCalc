using namespace std;
extern void  mn_program(int argc, char  ** argv);

main(int argc, char  ** argv)
{
    mn_program(argc,argv);
}
