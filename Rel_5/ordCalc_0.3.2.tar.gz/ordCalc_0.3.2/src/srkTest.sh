
doDiff() { echo  -n "Test $1 "  
        if [ "$OSTYPE" == "cygwin" ] 
        then mv $1.tst "temp_file" ; ./msfCnv.exe temp_file > $1.tst
        rm temp_file ;fi
        if ( ( diff $1.tst tst) > $1diff )
        then echo PASSED. 
        if [ "$opt1" !=  "save" ] ;then rm $1.tst $1diff ; fi; let passCount+=1
    else echo  "************FAILED*******************" 
        let errCount+=1
        echo -n "Diff file line count and file name: " ; wc -l $1diff
        echo "******************************************************" ;fi }
export opt1="$1"
echo $opt1
errCount=0 
passCount=0
abortCount=0
if test -n "${WINDIR}" ;then ORDX=ord.exe ;else ORDX=ord ;fi
    export ctests="cmdIntfc psiOpts validCk"
    for i in $ctests ;do 
	if ./${ORDX} cmd ${i}Test.sord > ${i}Test.tst 2>&1 ;then
        doDiff ${i}Test
        doDiff ${i}Log
	else echo Test $i \
                    "************FAILED WITH ABORT*************" \
                    ; let abortCount+=1
    echo "*****************************************************" 
    let errCount+=1;fi
    done

    export cpp=cppTest
    export tc=testCpp
	if ./${ORDX} cmdTex ${tc}.sord > ${tc}TestTex.tst 2>&1
        then doDiff ${tc}TestTex
        else echo "Test cmdTex ${tc} ***********FAILED WITH ABORT**************"
        let abortCount+=1
        echo "*****************************************************" 
        let errCount+=1;fi

	if ./${ORDX} cmd ${tc}.sord > ${tc}Test.tst 2>&1 ;then
        doDiff ${tc}Test
        if ./${ORDX} $cpp  > $cpp.tst 2>&1 ;then doDiff $cpp
        else echo Test $cpp "************FAILED WITH ABORT**************" 
        let abortCount+=1
         echo "*****************************************************" 
	    let errCount+=1;fi
    else echo Test ${tc}Test "************FAILED WITH ABORT*************" 
    let abortCount+=1
    echo "*****************************************************" 
    let errCount+=1;fi
    

	#if ./${ORDX} cmdTex ${tc}.sord ;then 
    export tests="nestedEmbedPaperTables \
		nestedEmbedPaperTables2 \
		nestedEmbedPaperTables3 \
		gamma admisDrillDownLimitComExitCode \
        admisDrillDownLimitExitCode infoLimitTypeExamp \
        admisExamples admisLimitElementExitCode \
        admisLimitElementComExitCode \
        psi play nestedEmbedNextLeast \
        nestedCmpExitCode nestedLimitOrdExitCode \
        nestedLimitEltExitCode \
        nestedLimitEltExitCode2 \
        nestedBaseLimitEltExitCode \
        nestedEmbed fixedPoint \
        embedExitCode drillDownExitCode cmpExitCode \
        limitEltExitCode  limitEltExitCode1 limitEltExitCode2 \
        limitOrdExitCode limitOrdExitCode1 limitOrdExitCode2\
        limitOrdExitCode3 transition exitCode2 exitCode \
        iter base try admis admis2 collapse \
        nested nested2 nested3 descend"
    #export tests="$ne fixedPoint"
     for i in $tests ;do if ./${ORDX} $i  > $i.tst 2>&1 ;then doDiff $i
     else echo Test $i "************FAILED WITH ABORT**************" \
     ; let abortCount+=1
    echo "*****************************************************" 
	 let errCount+=1;fi ;done

     echo "The following tests TeX output using LaTeX"
     echo "It generates trivial differences for different TeX releases."
     if ./${ORDX} cppTestTeX  > cppTestOut.tex 
        then
        if pdflatex -halt-on-error testTex  > testTempOut 2>&1
            then fgrep -v "This is pdfTeX" testTex.log  > testTexLog.tst
            doDiff testTexLog
            else echo pdflatex testTex "************FAILED WITH ABORT********"
            cat testTempOut
            let abortCount+=1
            echo "*****************************************************" 
            let errCount+=1;fi
        rm -f testTempOut cppTestOut.tex
        else echo test cppTestTeX "************FAILED WITH ABORT*************"
        let abortCount+=1
        echo "*****************************************************" 
        let errCount+=1;fi





    echo -n "Tests are complete. $passCount passed, $errCount" ;
    if [ $abortCount -eq 0 ] ;then echo " failed."
    else echo " failed including $abortCount that aborted." ;fi

