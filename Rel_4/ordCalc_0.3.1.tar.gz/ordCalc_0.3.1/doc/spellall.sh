for i in *.tex ; do printf '\033]2;%s\007' "$i" ; ispell $i ; done
