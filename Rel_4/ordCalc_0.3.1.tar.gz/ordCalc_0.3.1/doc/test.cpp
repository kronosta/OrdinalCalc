#include <mpir.h>
using namespace std;

main()
{

}
