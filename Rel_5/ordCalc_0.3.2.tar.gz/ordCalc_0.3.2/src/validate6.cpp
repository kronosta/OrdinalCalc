#include "stdafx.h"


#include "validate.h"
#include "ordTop.h"
#include "validDoc.h"
#include <list>

using namespace std;
using namespace ord ;


#define LIM_ELT_TST(code, base) { \
    outStream() << "Test " << #code << " for " << base.normalForm() << "\n" ;\
    (base).listElts(count,doTest); \
    if (doTest2) (base).descend(3,7) ;}


void Validate::nestedLimitEltExitCodeTest2()
{
    bool doTest = true ;
    bool doTest2 = true ;
    int count = 7 ;

    


    //ndmi = [[10, 10/1, 12/1, 12/2]]omega_{ 12}[ 1]
	static const IndexedLevel * const ndmi0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::one),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::one),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::two),
		NULL
	};
	const Ordinal& ndmi = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi0IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;

    LIM_ELT_TST(NDMI,ndmi);

    //ndmi_1 = [[10, 10/1, 10/2, 11, 12/1, 12/2]]omega_{ 12}[ 1]
	static const IndexedLevel * const ndmi_11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::one),
		new IndexedLevel((*new Ordinal(10)) ,Ordinal::two),
		new IndexedLevel((*new Ordinal(11)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::one),
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::two),
		NULL
	};
	const Ordinal& ndmi_1 = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi_11IndexedLevel, false)),
		NULL,
		Ordinal::one
        )
        ;
    LIM_ELT_TST(NDMI_1,ndmi_1);

    //ndmi_2 = [[1/w, 1/w + 1, 1/w + 2]]omega_{ 1}[ 1]
	static const IndexedLevel * const ndmi_22IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,expFunctional(Ordinal::one)),
		new IndexedLevel(Ordinal::one ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one)))),
		new IndexedLevel(Ordinal::one ,( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two)))),
		NULL
	};
	const Ordinal& ndmi_2 = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi_22IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(NDMI_2,ndmi_2);


	//ndmi_3 = [[1/5, 1/6, 1/7]]omega_{ 1}[ 1]
	static const IndexedLevel * const ndmi_33IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::five),
		new IndexedLevel(Ordinal::one ,Ordinal::six),
		new IndexedLevel(Ordinal::one ,(*new Ordinal(7))),
		NULL
	};
	const Ordinal& ndmi_3 = nestedEmbedFunctional(
		Ordinal::one,
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi_33IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    LIM_ELT_TST(NDMI_3,ndmi_3);
    /*
	//ndmi_4 = [[w, w + 1, w + 1/1, w + 1/2]]omega_{ w + 1}[ 1]
	static const IndexedLevel * const ndmi_44IndexedLevel[]= {
		new IndexedLevel(expFunctional(Ordinal::one) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::one),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::two),
		NULL
	};
	const Ordinal& ndmi_4 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))),
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi_44IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;
    */
    //ndmi_4 = [[w + 1, w + 2, w + 2/1, w + 2/2]]omega_{ w + 2}[ 1]
	static const IndexedLevel * const ndmi_40IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::one))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two))) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two))) ,Ordinal::one),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two))) ,Ordinal::two),
		NULL
	};
	const Ordinal& ndmi_4 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(Ordinal::two))),
		Ordinal::zero,
		(* new NestedEmbeddings( ndmi_40IndexedLevel, false)),
		NULL,
		Ordinal::one
	)
	;


     LIM_ELT_TST(NDMI_4,ndmi_4);


}

#define NM_LIM_ELT_TST(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal))

#define NM_LIM_ELT_TST_skd(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,NULL,Ordinal::zero, \
    LabeledOrdinal::testOnly))


#define NM2_LIM_ELT_TST_skd(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::zero, \
    LabeledOrdinal::testOnly))


#define NM2_LIM_ELT_TST(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname))

void LabeledOrdinal::nestedParamLimitEltExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    
    //pleb = [[12/1]]omega_{ 12}(3)
	static const IndexedLevel * const pleb0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::one),
		NULL
	};
	const Ordinal& pleb = nestedEmbedFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		(* new NestedEmbeddings( pleb0IndexedLevel, false)),
		createParameters(
			&(Ordinal::three)),
		Ordinal::zero
	)
	;

    NM2_LIM_ELT_TST(PLEB,NLP,pleb);

    //plec = [[12, 15/4]]omega_{ 15}(7)
	static const IndexedLevel * const plec0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::four),
		NULL
	};
	const Ordinal& plec = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( plec0IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(7)))),
		Ordinal::zero
	)
	;


	//plec1 = [[12, 15/1]]omega_{ 15}(7)
	static const IndexedLevel * const plec11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::one),
		NULL
	};
	const Ordinal& plec1 = nestedEmbedFunctional(
		(*new Ordinal(15)),
		Ordinal::zero,
		(* new NestedEmbeddings( plec11IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(7)))),
		Ordinal::zero
	)
	;


	//plec2 = [[w + 12/5, w + 12/6]]omega_{ w + 12}(77)
	static const IndexedLevel * const plec22IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::five),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::six),
		NULL
	};
	const Ordinal& plec2 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))),
		Ordinal::zero,
		(* new NestedEmbeddings( plec22IndexedLevel, false)),
		createParameters(
			&((*new Ordinal(77)))),
		Ordinal::zero
	)
	;


	//plec3 = [[w + 12/4, w + 13]]omega_{ w + 13}(w + 12)
	static const IndexedLevel * const plec33IndexedLevel[]= {
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::four),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))) ,Ordinal::zero),
		NULL
	};
	const Ordinal& plec3 = nestedEmbedFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(13))))),
		Ordinal::zero,
		(* new NestedEmbeddings( plec33IndexedLevel, false)),
		createParameters(
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))))),
		Ordinal::zero
	)
	;


    NM2_LIM_ELT_TST(PLEC_2,NLP,plec2);
    NM2_LIM_ELT_TST(PLED,NLP,plec);
    NM2_LIM_ELT_TST(PLED_1,NLP,plec1);
    NM2_LIM_ELT_TST(PLEE_1,NLP,plec3);

    //cksb = [[12, 15]]omega_{ 20}(1)
	static const IndexedLevel * const cksb0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& cksb = nestedEmbedFunctional(
		(*new Ordinal(20)),
		Ordinal::zero,
		(* new NestedEmbeddings( cksb0IndexedLevel, false)),
		createParameters(
			&(Ordinal::one)),
		Ordinal::zero
	)
	;


	//cksb_1 = [[12, 15]]omega_{ 20}(w + 9)
	static const IndexedLevel * const cksb_11IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(15)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& cksb_1 = nestedEmbedFunctional(
		(*new Ordinal(20)),
		Ordinal::zero,
		(* new NestedEmbeddings( cksb_11IndexedLevel, false)),
		createParameters(
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(9))))))),
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(LCDP_2,NLA,cksb);
    NM2_LIM_ELT_TST(LCDP_3,NLA,cksb_1);



}

void LabeledOrdinal::nestedBaseimitEltExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{


    //cj = [[12, 13]]omega_{ 13}(omega_{ 12}, 5)
	static const IndexedLevel * const cj3IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(13)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& cj = nestedEmbedFunctional(
		(*new Ordinal(13)),
		Ordinal::zero,
		(* new NestedEmbeddings( cj3IndexedLevel, false)),
		createParameters(
			&(admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	)),
			&(Ordinal::five)),
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(FN,NLA,cj);


    //aj = [[12, 13]]omega_{ 13}(omega_{ 12})
	static const IndexedLevel * const aj0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,Ordinal::zero),
		new IndexedLevel((*new Ordinal(13)) ,Ordinal::zero),
		NULL
	};
	const Ordinal& aj = nestedEmbedFunctional(
		(*new Ordinal(13)),
		Ordinal::zero,
		(* new NestedEmbeddings( aj0IndexedLevel, false)),
		createParameters(
			&(admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL
	))),
		Ordinal::zero
	)
	;
    NM2_LIM_ELT_TST(FL,NLA,aj);
}


#define ONM_LIM_ELT_TST(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,NULL,Ordinal::omega))

#define ONM_LIM_ELT_TST_skd(name,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,NULL,Ordinal::omega, \
    LabeledOrdinal::testOnly))


#define ONM2_LIM_ELT_TST_skd(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::omega, \
    LabeledOrdinal::testOnly))


#define ONM2_LIM_ELT_TST(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::omega))


void LabeledOrdinal::admisLimitOrdExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
{
    //loa = omega_{ 12}[ omega_{ 11}]
	const Ordinal& loa = admisLevelFunctional(
		(*new Ordinal(12)),
		Ordinal::zero,
		NULL,
		admisLevelFunctional(
		(*new Ordinal(11)),
		Ordinal::zero,
		NULL
	)
	)	;

    ONM_LIM_ELT_TST(LOA,loa);

	//lob = [[w + 3]]omega_{ ( w*2) + 2}(omega_{ 11})
	const Ordinal& lob = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one, 2).getImpl()
	.addLoc(Ordinal::two))),
		Ordinal::zero,
		createParameters(
			&(admisLevelFunctional(
		(*new Ordinal(11)),
		Ordinal::zero,
		NULL
	))),
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::three))), Embeddings::paramRestrict))
	)	;

    ONM2_LIM_ELT_TST(OFB,LOB,lob);

	//lob1 = omega_{ 9}(omega_{ 11}, 1)
	const Ordinal& lob1 = admisLevelFunctional(
		(*new Ordinal(9)),
		Ordinal::zero,
		createParameters(
			&(admisLevelFunctional(
		(*new Ordinal(11)),
		Ordinal::zero,
		NULL
	)),
			&(Ordinal::one))
	)	;

    ONM2_LIM_ELT_TST(OFA,LOB,lob1);

	//lob2 = [[5]]omega_{ 8, omega_{ 7}}
	const Ordinal& lob2 = admisLevelFunctional(
		(*new Ordinal(8)),
		admisLevelFunctional(
		(*new Ordinal(7)),
		Ordinal::zero,
		NULL
	),
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::five, Embeddings::paramRestrict))
	)	;

    ONM2_LIM_ELT_TST(FOB,LOB,lob2);

	//lob3 = omega_{ 12, omega_{ 11}}(w + 1)
	const Ordinal& lob3 = admisLevelFunctional(
		(*new Ordinal(12)),
		admisLevelFunctional(
		(*new Ordinal(11)),
		Ordinal::zero,
		NULL
	),
		createParameters(
			&(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one)))))
	)	;

    ONM2_LIM_ELT_TST(FOC,LOB,lob3);

    //loc = omega_{ omega_{ w + 12}}
	const Ordinal& loc = admisLevelFunctional(
		admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(12))))),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	)	;
    ONM_LIM_ELT_TST(LOC,loc);


	//lod = [[w + 3]]omega_{ omega_{ w + 12}}
	const Ordinal& lod = admisLevelFunctional(
		admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(12))))),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::three))), Embeddings::paramRestrict))
	)	;

    ONM_LIM_ELT_TST(LOD,lod);

	//loe = omega_{ omega_{ omega_{ 19}}}(12)
	const Ordinal& loe = admisLevelFunctional(
		admisLevelFunctional(
		admisLevelFunctional(
		(*new Ordinal(19)),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12))))
	)	;

    ONM_LIM_ELT_TST(LOE,loe);

	//loe1 = [[19]]omega_{ omega_{ omega_{ 19}}}(12)
	const Ordinal& loe1 = admisLevelFunctional(
		admisLevelFunctional(
		admisLevelFunctional(
		(*new Ordinal(19)),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		createParameters(
			&((*new Ordinal(12)))),
		Ordinal::zero,
		(* new Embeddings((*new Ordinal(19)), Embeddings::paramRestrict))
	)	;

    ONM_LIM_ELT_TST(LOE,loe1);


	//lof = [[w + 15]]omega_{ w + 20}
	const Ordinal& lof = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(20))))),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(15))))), Embeddings::paramRestrict))
	)	;
    ONM_LIM_ELT_TST(LOF,lof);


	//lof1 = omega_{ w + 20}
	const Ordinal& lof1 = admisLevelFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc((*new Ordinal(20))))),
		Ordinal::zero,
		NULL
	)	;

    ONM_LIM_ELT_TST(LOF,lof1);



}

static void labeledOrdsTest(list<LabeledOrdinal*> labOrds)
{

    bool doTest = true ;
    bool doTest2 = true ;
    int count = 7 ;

    // list<LabeledOrdinal*> labOrds;
    // LabeledOrdinal::nestedBaseimitEltExitCodeTestNames (labOrds);
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        // NLIM_ELT_TSTS((*iter)->name,(*iter)->ord);
        outStream() << "Test " << (*iter)->name ;
        if ((*iter)->subName)  outStream() << " - " << (*iter)->subName ;
        outStream() << " for " << (*iter)->ord.normalForm() << "\n" ;
        ((*iter)->ord).listElts(count,doTest); 
        if (doTest2) ((*iter)->ord).descend(3,10) ;

    }


}



void Validate::nestedBaseClassLimitEltExitCodeTest()
{
    list<LabeledOrdinal*> labOrds1;
    LabeledOrdinal::nestedBaseimitEltExitCodeTestNames (labOrds1);
    labeledOrdsTest(labOrds1) ;

    list<LabeledOrdinal*> labOrds2;
    LabeledOrdinal::nestedParamLimitEltExitCodeTestNames(labOrds2);
    labeledOrdsTest(labOrds2) ;

}


static void nestedEmbedNextTest(const NestedEmbeddings& ne)
{
    static const int lim = 10 ;
    outStream() << "Next least Embed test for: " << ne.normalForm() << "\n" ;

    const NestedEmbeddings * cur = &ne ;
    for (int i = 0 ; i < 10; i++) {
        if (cur->isLeastLimit()) break ;
        const Embeddings& nxt = cur->nextLeast();
        outStream() << i << ": " << nxt.normalForm() << "\n" ;
        if (nxt.embedLevel == Embeddings::baseEmbedLevel) return ;
        cur = &((const NestedEmbeddings &) nxt);
    }
}

void Validate::nestedEmbedNextLeastTest()
{

    static const IndexedLevel * const a1IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::five),
		new IndexedLevel((*new Ordinal(40)) ,Ordinal::zero),
		new IndexedLevel(( * new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc((*new Ordinal(12))))) ,Ordinal::one),
		NULL
	};

    static const IndexedLevel * const b2IndexedLevel[]= {
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(* new Ordinal(expFunctional(Ordinal::one).getImpl().addLoc(6)) ,Ordinal::zero),
		NULL
	};
    // [12/15, 12/16]]
    static const IndexedLevel * const aa0IndexedLevel[]= {
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(15))),
		new IndexedLevel((*new Ordinal(12)) ,(*new Ordinal(16))),
		NULL
	};

    //ax = [[1, 2, 3, 4, 5, 6]]
    static const IndexedLevel * const ax0IndexedLevel[]= {
		new IndexedLevel(Ordinal::one ,Ordinal::zero),
		new IndexedLevel(Ordinal::two ,Ordinal::zero),
		new IndexedLevel(Ordinal::three ,Ordinal::zero),
		new IndexedLevel(Ordinal::four ,Ordinal::zero),
		new IndexedLevel(Ordinal::five ,Ordinal::zero),
		new IndexedLevel(Ordinal::six ,Ordinal::zero),
		NULL
	};



    const NestedEmbeddings * toTest[] = {
        new NestedEmbeddings( a1IndexedLevel, false),
        new NestedEmbeddings( b2IndexedLevel, false),
        new NestedEmbeddings( aa0IndexedLevel, false),
        new NestedEmbeddings( ax0IndexedLevel, false),

        NULL
    };


        
    for (const NestedEmbeddings ** testing = toTest;
            *testing; testing++) nestedEmbedNextTest(**testing);


}

void Validate::testOrdinalAry(const Ordinal * ords[],int count)
{
    bool doTest = true ;
    // int count = 10 ;
    bool doTest2 = true ;


    int countVar = 1 ;
    for (const Ordinal ** ord = ords; *ord; ord++) {
		// cerr << (*ord)->normalForm() << "\n" ;
        outStream() << "DOING " << countVar++ << " test for " 
            << (*ord)->normalForm() << "\n" ;
        (**ord).listElts(count,doTest); 
        if (doTest2) (**ord).descend(3,10) ;

    }

}

void Validate::admisExampTests()
{
    admisLimitEle(true);
    admisLimitEle2(true);
    admisLimitEle3(true);

    LabeledOrdinal::runTest(10,
        LabeledOrdinal::admisLimitOrdExitCodeTestNames);

    LabeledOrdinal::runTest(10,
        LabeledOrdinal::admisLimitOrdExampleNames);


}
