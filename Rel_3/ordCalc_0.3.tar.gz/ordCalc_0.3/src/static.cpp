#include "stdafx.h"


#include "ordTop.h"
#include "intfc.h"


using namespace ord ;
using namespace std ;





OutStream OutStream::streamManager ;



const DebugControlParam& DebugControlStack::defaultControl =
	(new DebugControlParam)->clearAll();

DebugControl ord::debugControl ;
DebugControl& OrdinalImpl::debugControl = ::debugControl;


list<OrdinalImpl *> OrdinalImpl::urefImp ;


int OrdinalImpl::idCount = 0;

int CantorNormalElement::count = 0 ;
#ifndef WIN32
const int  CantorNormalElement::cantorCodeLevel ;
const int FiniteFuncNormalElement::finiteFuncCodeLevel ;
const int AdmisNormalElement::admisCodeLevel ;
#endif

int OrdinalImpl::cppUniqueInt = 0 ;


const Int  OrdinalImpl::zeroInt = 0 ;

const OrdinalImpl& OrdinalImpl::zero = *new OrdinalImpl(0);


const OrdinalImpl& OrdinalImpl::one = *new OrdinalImpl(1,1);



const OrdinalImpl& OrdinalImpl::two = *new OrdinalImpl(2);


const OrdinalImpl& OrdinalImpl::three = *new OrdinalImpl(3);
const OrdinalImpl& OrdinalImpl::four = *new OrdinalImpl(4);
const OrdinalImpl& OrdinalImpl::five = *new OrdinalImpl(5);
const OrdinalImpl& OrdinalImpl::six = *new OrdinalImpl(6);
NormalFormTerm& omegaTerm = *NormalFormTerm::create(OrdinalImpl::one,1);
const OrdinalImpl& OrdinalImpl::omega = * new OrdinalImpl("w",omegaTerm);

const Ordinal Ordinal::zero(OrdinalImpl::zero);
const Ordinal Ordinal::one(OrdinalImpl::one);
const Ordinal Ordinal::two(OrdinalImpl::two);
const Ordinal Ordinal::three(OrdinalImpl::three);
const Ordinal Ordinal::four(OrdinalImpl::four);
const Ordinal Ordinal::five(OrdinalImpl::five);
const Ordinal Ordinal::six(OrdinalImpl::six);
const Ordinal Ordinal::omega(OrdinalImpl::omega);


const Embeddings Embeddings::embedNone(Ordinal::zero,Embeddings::none);
const Embeddings& Ordinal::noEmbeddings = Embeddings::embedNone ;

const OrdinalImpl& CantorNormalElement::nullLimitType = OrdinalImpl::zero ;
const OrdinalImpl& CantorNormalElement::integerLimitType = OrdinalImpl::one ;
const OrdinalImpl& CantorNormalElement::recOrdLimitType = OrdinalImpl::two ;

const OrdinalImpl& CantorNormalElement::zero(OrdinalImpl::zero);
const OrdinalImpl& CantorNormalElement::one(OrdinalImpl::one);
const OrdinalImpl& CantorNormalElement::two(OrdinalImpl::two);
const OrdinalImpl& CantorNormalElement::three(OrdinalImpl::three);
const OrdinalImpl& CantorNormalElement::four(OrdinalImpl::four);
const OrdinalImpl& CantorNormalElement::five(OrdinalImpl::five);
const OrdinalImpl& CantorNormalElement::six(OrdinalImpl::six);
const OrdinalImpl& CantorNormalElement::omega(OrdinalImpl::omega);



const Ordinal& ord::eps0 = psi(one,zero); 
const Ordinal& ord::gamma0 = FiniteFuncOrdinal(one,zero,zero);

const Ordinal * ParseSemantics::omega = &(Ordinal::omega) ;


const Ordinal& ord::omega1CK = * new AdmisLevOrdinal(one,zero,NULL);

const Ordinal& IterFuncNormalElement::theIterClassLimit =
    *new AdmisLevOrdinal(one,zero,NULL,one,zero);

const Ordinal& AdmisNormalElement::theAdmisClassLimit=Ordinal::zero ;

const Ordinal& AdmisNormalElement::drillDownLimitValue =
    * new AdmisLevOrdinal(one,zero,NULL,zero,one);

const CantorNormalElement::CodeLevelAndSections
    CantorNormalElement::codeLevelCodes[] = {
    {"undefined",NULL},
    {"cantorCodeLevel","SecOrdinal",1},
    {"finiteFuncCodeLevel","SecFinFuncOrd",2},
    {"iterFuncCodeLevel","SecIterFuncOrd",3},
    {"admisCodeLevel","SecAdmisLevOrd",4},
    {"nestedEmbedCodeLevel","SecNestedEmbed",5},
    {NULL,NULL}
};


ParseSemantics::InitPair ParseSemantics::initMapPairs[] = {
    {"omega", &Ordinal::omega},
    {"w", &Ordinal::omega},
    {"omega1CK", &ord::omega1CK},
    {"w1", &ord::omega1CK},
    {"w1CK", &ord::omega1CK},
    {"eps0", &ord::eps0},
    {"",NULL}
};


