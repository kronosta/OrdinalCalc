if test -n "${WINDIR}" ;then ORDX=ord.exe ;else ORDX=ord ;fi
if ./${ORDX} tex ;then
if ./${ORDX} cmd admisCppExampCalcIns.sord > /dev/null ;then
mv admisCppExampCalcIns.tex tadmisCppExampCalcIns.tex
echo "\\begin{verbatim}" > admisCppExampCalcIns.tex
cat tadmisCppExampCalcIns.tex >> admisCppExampCalcIns.tex
echo "\\end{verbatim}" >> admisCppExampCalcIns.tex
if ./ord cmd nestedCppExamp.sord > /dev/null ; then
mv nestedCppExamp.tex tnestedCppExamp.tex
echo "\\begin{verbatim}" > nestedCppExamp.tex
cat tnestedCppExamp.tex >> nestedCppExamp.tex
echo "\\end{verbatim}" >> nestedCppExamp.tex

		if mv -f \
nestedCppExamp.tex \
admisCppExampCalcIns.tex \
figAdmisCppExampCalc.tex \
expExamp.tex \
ordArithBase.tex \
ordBaseLim.tex \
ordExamp.tex \
tabLimEltOrdinal.tex \
tabMultOrdinal.tex \
tabPowOrdinal.tex \
tabvecFunc.tex \
tabMultFiniteFuncOrdinal.tex \
tabPowFiniteFuncOrdinal.tex \
tabfiniteFuncCalcExamp.tex \
tabfiniteFuncCppExamp.tex \
tabFiniteFuncLimEltComExitCode.tex \
tabiterfuncCppExamp.tex \
tabIterFuncLimitEltComExitCode.tex \
tabOrdBaseCppExamp.tex \
tabMultIterFuncOrdinal.tex \
tabPowIterFuncOrdinal.tex \
tabAdmisCppExamp.tex \
tabLimEltAdmisLevOrdinal1.tex \
tabLimEltAdmisLevOrdinal2.tex \
tabLimEltAdmisLevOrdinal3.tex \
tabLimOrdAdmisLevOrdinal.tex \
tabMultAdmisLevOrdinal.tex \
tabPowAdmisLevOrdinal.tex \
tabAdmisDrillDownDef.tex \
tabNestedInterpExamp.tex \
cmdchapt.tex \
cmdman.tex \
descrNestedCollapse.tex \
ordCalcCmdLine.tex \
collapseConnect.tex \
admisPsi.tex \
admisLimPsi.tex \
admisBasePsi.tex \
tabAdmisNestedEtaExamp.tex \
texDefs.tex \
tabNestedDdLimitExamp.tex \
tabNestedDdLimitEqExamp.tex \
tabNestedEmbedLimitExamp.tex \
tabNestedLimitOrdExamp.tex \
tabTransitionLimitExamp.tex \
tabLimitTypeInfoadmisCodeLevel.tex \
tabLimitTypeExampInfoadmisCodeLevel.tex \
tabLimitTypeOrdExampInfoadmisCodeLevel.tex \
tabLimitTypeInfonestedEmbedCodeLevel.tex \
tabLimitTypeExampListInfonestedEmbedCodeLevel.tex \
tabLimitTypeOrdExampInfonestedEmbedCodeLevel.tex \
tabNestedParamLimitExamp.tex \
tabAdmisLimitELementExitCode.tex \
tabAdmisLimitELementComExitCode.tex \
tabAdmisDrillDownLimitExitCode.tex \
tabAdmisDrillDownLimitComExitCode.tex \
tabAdmisLimitOrdComExitCode.tex \
../doc ; then
		echo "../doc has ben updated" ; exit 0;else
		echo "mv files failed" ; fi
        else "execute ./${ORDX} cmd admisCppExampCalc.sord failed" ; fi
        else "execute ./${ORDX} cmd nestedCppExamp.sord failed" ; fi
	else echo "execute ./${ORDX} tex failed" ;fi
#else echo "make failed" 
#exit 1 ;fi
