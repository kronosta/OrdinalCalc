
	//a = w
	const Ordinal& a = expFunctional(Ordinal::one)	;


	//b = psi_{ 1}(1, 0)
	const Ordinal& b = iterativeFunctional(
		Ordinal::one,
		Ordinal::one,
		Ordinal::zero)	;


	//c = omega_{ 1}(1, 1, 0)
	const Ordinal& c = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		createParameters(
			&(Ordinal::one),
			&(Ordinal::one),
			&(Ordinal::zero))
	)	;


	//d = omega_{ 1}
	const Ordinal& d = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)	;


	//e = omega_{ 1}[ epsilon( 0)]
	const Ordinal& e = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		psi( Ordinal::one, Ordinal::zero)
	)	;


	//f = omega_{ 1}[ 5]
	const Ordinal& f = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::five
	)	;


	//g = omega_{ 1, omega_{ 1}}(1)
	const Ordinal& g = admisLevelFunctional(
		Ordinal::one,
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	),
		createParameters(
			&(Ordinal::one))
	)	;


	//h = omega_{ 1, 1}(1, omega_{ 1})
	const Ordinal& h = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(Ordinal::one),
			&(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)))
	)	;


	//i = omega_{ 1, 2}(1, w, 0)
	const Ordinal& i = admisLevelFunctional(
		Ordinal::one,
		Ordinal::two,
		createParameters(
			&(Ordinal::one),
			&(expFunctional(Ordinal::one)),
			&(Ordinal::zero))
	)	;


	//j = omega_{ w, w}(1, omega_{ 1}, 0, 0)
	const Ordinal& j = admisLevelFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		createParameters(
			&(Ordinal::one),
			&(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)),
			&(Ordinal::zero),
			&(Ordinal::zero))
	)	;


	//k = omega_{ omega_{ 1}, w}
	const Ordinal& k = admisLevelFunctional(
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	),
		expFunctional(Ordinal::one),
		NULL
	)	;


	//l = omega_{ 1, w}(psi_{ w})
	const Ordinal& l = admisLevelFunctional(
		Ordinal::one,
		expFunctional(Ordinal::one),
		createParameters(
			&(iterativeFunctional(
		expFunctional(Ordinal::one))))
	)	;


	//m = omega_{ omega_{ 1}}
	const Ordinal& m = admisLevelFunctional(
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	),
		Ordinal::zero,
		NULL
	)	;


	//n = [[2]]omega_{ 2}
	const Ordinal& n = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::two, Embeddings::paramRestrict))
	)	;


	//o = [[3]]omega_{ w}
	const Ordinal& o = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;


	//p = omega_{ w}
	const Ordinal& p = admisLevelFunctional(
		expFunctional(Ordinal::one),
		Ordinal::zero,
		NULL
	)	;


	//q = [[2]]omega_{ 2, omega_{ 1}}(1)
	const Ordinal& q = admisLevelFunctional(
		Ordinal::two,
		admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	),
		createParameters(
			&(Ordinal::one)),
		Ordinal::zero,
		(* new Embeddings(Ordinal::two, Embeddings::paramRestrict))
	)	;


	//r = [[1]]omega_{ w, w}(1, omega_{ 1}, 0)
	const Ordinal& r = admisLevelFunctional(
		expFunctional(Ordinal::one),
		expFunctional(Ordinal::one),
		createParameters(
			&(Ordinal::one),
			&(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	)),
			&(Ordinal::zero)),
		Ordinal::zero,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict))
	)	;

	outStream() << "a = " << a.normalForm() << "\n" ; 
	outStream() << "b = " << b.normalForm() << "\n" ; 
	outStream() << "c = " << c.normalForm() << "\n" ; 
	outStream() << "d = " << d.normalForm() << "\n" ; 
	outStream() << "e = " << e.normalForm() << "\n" ; 
	outStream() << "f = " << f.normalForm() << "\n" ; 
	outStream() << "g = " << g.normalForm() << "\n" ; 
	outStream() << "h = " << h.normalForm() << "\n" ; 
	outStream() << "i = " << i.normalForm() << "\n" ; 
	outStream() << "j = " << j.normalForm() << "\n" ; 
	outStream() << "k = " << k.normalForm() << "\n" ; 
	outStream() << "l = " << l.normalForm() << "\n" ; 
	outStream() << "m = " << m.normalForm() << "\n" ; 
	outStream() << "n = " << n.normalForm() << "\n" ; 
	outStream() << "o = " << o.normalForm() << "\n" ; 
	outStream() << "p = " << p.normalForm() << "\n" ; 
	outStream() << "q = " << q.normalForm() << "\n" ; 
	outStream() << "r = " << r.normalForm() << "\n" ; 
	outStream() << "cppList \"cpp2TestOut.h\"\n";
	outStream() << "quitf\n";
