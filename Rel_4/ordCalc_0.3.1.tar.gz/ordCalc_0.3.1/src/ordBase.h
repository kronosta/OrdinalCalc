#include <assert.h>
#include <iostream>
#include <iostream>
#include <sstream>
#include <string>
#include <list>


#include "ordDebug.h"
// #include <gmpxx.h>
#include <mpirxx.h>


using namespace std ;



namespace ord {




	typedef  mpz_class Int ;

	class OrdinalImpl ;
	class Ordinal ;
	class InterpNormalElement ;
    class Embeddings ;
    class LabeledOrdinal ;


	class OrdSubs {
		struct OrdSub {
			
			
			const InterpNormalElement& ordElt ;
			OrdSub * next ;
			OrdSub * stack ;
			OrdSub * fullStackNext ;
			OrdSub(const InterpNormalElement& e):
				ordElt(e),next(NULL),stack(NULL),
				fullStackNext(NULL){}
			void push(OrdSub * sub);
			OrdSub * pop();
		} * ordSubs ;
		OrdSub * fullStack ; 
public:
		OrdSubs():ordSubs(NULL),fullStack(NULL){}

		void add(const InterpNormalElement& e);
		bool remove(const InterpNormalElement& e);
		const InterpNormalElement * getOrdSub(const OrdinalImpl& ix) const ;
		const OrdinalImpl * check(const OrdinalImpl& limTp,
			const OrdinalImpl &ord) const;
		const OrdinalImpl * check(const OrdinalImpl& limTp,
			const Int &n) const;

	};

   



	struct NormalFormTerm ;
	class CantorNormalElement {
		friend struct NormalFormTerm ;
		friend class OrdinalImpl;
        friend class AdmisNormalElement;
        friend struct LastReturnCode;
protected:
		const class Parameters {
public:
			int codeLevel ;
			const OrdinalImpl * exponent ;
public:
			
			virtual ~Parameters(){}
		} * parameters ;

		unsigned int refCount ;
public:
        virtual const char * className() const {return "CantorNormalElement";}
		static const int cantorCodeLevel = 1  ;
		const int codeLevel ;
        static const char* codeLevelClassNames[] ;
		const Int factor ;
		const OrdinalImpl& exponent ;
		virtual const OrdinalImpl & getMaxParameter() const 
			{return exponent;}

        virtual const Ordinal& getMaxEmbedIndex() const  ;
        virtual const OrdinalImpl& getCompareIndexCK(bool ign) const ;
		static const OrdinalImpl & createOrdinal(const string& name,
			const NormalFormTerm& t)  ;
        
            
		enum LimitTypeInfo {
            infoStart,
            unknownLimit,
            zeroLimit,
            finiteLimit,        
            paramSucc,
            paramLimit,         
            paramSuccZero,
			paramsSucc,          
            paramNxtLimit,
            functionSucc,
            functionNxtSucc,
            functionLimit,
            functionNxtLimit,
            drillDownLimit,     
            drillDownSucc, 
            drillDownSuccCKOne, 
            drillDownSuccEmbed, 
            drillDownOne, 
            drillDownCKOne, 
            drillDownOneEmbed, 
            indexCKlimit,
            indexCKsuccParam,   
            indexCKsuccParamEq,   
            indexCKsuccEmbed,        
            indexCKsuccUn,        
            indexCKlimitParamUn,  
            indexCKlimitEmbed,  

            // additions for nested embed
            indexCKlimitParamEmbed,
            leastIndexLimit,
            leastLevelLimit,
            leastIndexSuccParam,
            leastLevelSuccParam,
            leastIndexLimitParam,
            leastLevelLimitParam,
            // drillDownEmbedLimit,
            // drillDownEmbedSucc
            infoTermination

        } theLimitTypeInfo ;

        static string limInfoName(LimitTypeInfo inf) ;

        static LimitTypeInfo incrementInfo(LimitTypeInfo typeInfo) ;
        // static void createInfoTables(int codeLevel,
        //    const char * fontSize = "\\scriptsize") ;
        static void createInfoTableType(int codeLevel,
            const char * fontSize = "\\scriptsize",
            bool makeTargets=false) ;
        static void createInfoTableExamp(int codeLevel,
            const char * fontSize = "\\scriptsize",bool mark = false) ;
        static void createInfoTableExampList(int codeLevel,
            const char * fontSize = "\\scriptsize",bool mark = false) ;
        static void createInfoTableOrdExamp(int codeLimit,
            const char * fontSize = "\\scriptsize") ;

        LimitTypeInfo getInfo() const ;

        virtual const OrdinalImpl& effectiveIndexCK(
            const Embeddings& embed) const ;

        static struct EquationCodeLevel {
        const char *eqn ;
        int codeLevel ;
        } *equationCodeLevels;

        static void initEquationCodeLevels();

        static int equationCodeLevel(const char * eqn);

        struct InfoDocLine {
            LimitTypeInfo index; 
            const char * desc;
            const int codeLevel ;
            const Ordinal* examp ;
            const char * limitType ;
            const Ordinal * limitOrdExamp ;
            const char * rule ;

            static InfoDocLine * infoDocTab  ;
            static void getExamples(list<LabeledOrdinal*>& labOrds);
            static void initInfoDocTab();
            static const InfoDocLine& getDocLine(LimitTypeInfo infoEntry);
        } ;



        
protected:
        virtual const OrdinalImpl& setLimitType(
            CantorNormalElement::LimitTypeInfo&
            typeInfo, const OrdinalImpl *type,
            const OrdinalImpl * embedType=NULL) const;
        virtual const OrdinalImpl& setMaxLimitType
            (const OrdinalImpl* newType) const;

		const OrdinalImpl * theLimitType ;
		const OrdinalImpl * theMaxLimitType ;
		const OrdinalImpl * theEmbedType ;
        bool testSize ;

        bool checkParamSize(const OrdinalImpl& dd) const ;

		static  int count ;
		const int id ;
		const OrdinalImpl* termValue ;
		void dereference() const {((CantorNormalElement *)this)->refCount-- ;
			if (!refCount) if (id > 1) delete this ;
		}
		void commonInit() ;
		static const CantorNormalElement & createCantorNormalElement(
			const OrdinalImpl& ord, Int fac=1) {
				return * new CantorNormalElement(ord,fac);}

		
		CantorNormalElement(int n, const OrdinalImpl& one);

		CantorNormalElement(const Parameters * params, Int fac=1);
		CantorNormalElement(const OrdinalImpl& expon,
			Int f =1);

		CantorNormalElement(const OrdinalImpl& expon,
			Int f , int codeLev );
		CantorNormalElement(const CantorNormalElement&elt);
		
		virtual ~CantorNormalElement();

		virtual const CantorNormalElement& getCopy(const Int fac=1) const;

		static const NormalFormTerm * getOrdinalTerm(const OrdinalImpl& ord);
		static const OrdinalImpl& createOrdinal(
			const CantorNormalElement &elt ) {return elt.termToOrdinal();}
		static const CantorNormalElement& createTerm(const OrdinalImpl& ord,
			Int f =1) {return * new CantorNormalElement(ord,f);}
		static const OrdinalImpl& createOrdinal(const OrdinalImpl& ord);
		const OrdinalImpl& addFactorPart(const OrdinalImpl& r) const ;
		
		

		virtual const OrdinalImpl& limitElement(Int n) const ;
        virtual const OrdinalImpl& getDDindexVal() const ;

		const OrdinalImpl * limitOrdCom(const OrdinalImpl & ord) const ;
		virtual const OrdinalImpl& limitOrd(const OrdinalImpl & ord) const ;
		void outOperands(char  oper, const CantorNormalElement& b) const ;
		static const OrdinalImpl& getImpl(const Ordinal& ord) ;
		virtual const CantorNormalElement & addFactors(
			const CantorNormalElement& toAdd) const ;
public:
		virtual bool isOne() const ;
		ostream & out(const string cmt = "") const ;

		virtual const OrdinalImpl& maxLimitType() const ;
        // virtual const OrdinalImpl&maxLimitType(const Ordinal& context)const;
        virtual bool isValidLimitOrdParam(const OrdinalImpl& dd) const ;
        // virtual bool isValidLimitParam(const OrdinalImpl& dd) const ;
		virtual const OrdinalImpl& limitType() const;
		virtual const OrdinalImpl* embedType() const;
		LimitTypeInfo getLimitInfo() const ;



        

         const OrdinalImpl& limitInfo( LimitTypeInfo& typeInfo) const  ;



		static const OrdinalImpl& nullLimitType ;
		static const OrdinalImpl& integerLimitType ;
		static const OrdinalImpl& recOrdLimitType ;
		virtual const OrdinalImpl& getIndexCK() const {return zero;}
		const OrdinalImpl& getOrdinalCopy(const Int fac=1) const;
		static const OrdinalImpl& createExpOrdinal(const OrdinalImpl& ord,
			Int factor = 1);
		static void outOperands(char  oper, const CantorNormalElement& a,
				const CantorNormalElement& b) ;
		const OrdinalImpl& termToOrdinal() const ;
		static const OrdinalImpl& createOrdinal(Int n) ;
		static const OrdinalImpl& fixedPointCheck(const OrdinalImpl& exp,
			const Int& fact=1);
		
		
		
		
		static const OrdinalImpl& zero ;
		static const OrdinalImpl& one ;
		static const OrdinalImpl& two ;
		static const OrdinalImpl& three ;
		static const OrdinalImpl& four ;
		static const OrdinalImpl& five ;
		static const OrdinalImpl& six ;
		static const OrdinalImpl& omega ;
		virtual void normalFormName(string& base) const ;

        virtual void psiNormalForm(string& str) const ;
		virtual void texNormalForm(string& str) const ;
		string& psiNormalForm() const
			{string &s = * new string ; psiNormalForm(s);return s;}
		string& texNormalForm() const
			{string &s = * new string ; texNormalForm(s);return s;}

		string& normalForm() const {
			string& temp = *new string ; normalFormName(temp); return temp;}
        virtual string& cppNormalForm(const string& nameBase, string& ret)
            const ;


        virtual const Embeddings &effectiveEmbedding(
            const Embeddings& termEmbed, bool compareFlag=false)const ;

        virtual const Embeddings &effectiveEmbedLevel(
            const Embeddings& termEmbed) const ;

         int compare(const Embeddings& context,
            const Embeddings& paramContext,
            const Ordinal& trm, bool ignoreFactor=false) const ;

        virtual int compare(const Embeddings& context,
            const Embeddings& paramContext,
            const CantorNormalElement& trm,
			bool ignoreFactor = false) const ;
        int parameterCompare(const Embeddings& context,
            const Embeddings& paramContext,
            const CantorNormalElement &trm) const ;


        int compare(const OrdinalImpl& ord) const ;

        int compare(const Embeddings& embedIx,
            const Embeddings& termEmbedIx,
            const OrdinalImpl& ord,bool ignoreFactor=false) const ;

		virtual int compare(const CantorNormalElement& trm,
			bool ignoreFactor = false) const ;
        bool isOmega() const ;
		bool isFinite() const ;
        bool isLimit() const {return !isFinite();}
		bool isIntOrCantorLevel() const {return codeLevel <= cantorCodeLevel;}
		virtual const CantorNormalElement& multiply(
			const CantorNormalElement& op) const;
		virtual const CantorNormalElement& multiply(const Int& fac) const ;
		virtual const CantorNormalElement& multiplyBy(
			const CantorNormalElement& op) const {return op.multiply(*this);}
		void reference() const {((CantorNormalElement *)this)->refCount++ ;}
		const Int& getFactor() const {return factor;}
		void deleteIfNotReferenced() const {
			if (refCount < 1) delete this;
		}

		void describe(ostream&out) const;
		void describel(ostream&out) const {describe(out); out << "\n" ;}

		int psuedoCodeLevel() const { if (factor > 1) return cantorCodeLevel;
			return codeLevel;}

		virtual const OrdinalImpl& toPower(const CantorNormalElement& elt)
			const;
		virtual const OrdinalImpl& powerOf(const CantorNormalElement& elt)
            const ;
		
        const class Embeddings& getEmbed() const;
        // int limitEmbedCheck(const OrdinalImpl& ord) const;
        // this returns 0 if either embed is none
        // source in admisOrd.cpp


		bool expTerm() const ;
        struct CodeLevelAndSections {
            const char * codeLevel;
            const char * section ;
            int level ;
        };
        static const CodeLevelAndSections codeLevelCodes[];
        static const char * codeLevelName(int level);
	};


	struct NormalFormTerm {
		const CantorNormalElement&  term ;
		const NormalFormTerm * next  ;
		
		NormalFormTerm(CantorNormalElement& trm);
		~NormalFormTerm();
		void append(const NormalFormTerm& trm) const 
			{if (next == NULL) {
				((NormalFormTerm *)this)->next = &trm;
			}
			else next->append(trm) ; }

		static void concatenate(const NormalFormTerm *& concatTo,
			const NormalFormTerm& concatFrom) ;

		void append(const CantorNormalElement& trm) const
			{append(*new NormalFormTerm(trm));}
		virtual void normalFormName(string& base) const ;
        virtual string& cppNormalForm(const string& nameBase, string& ret) const ;
		int compare(const Embeddings& context,
            const Embeddings& paramContext, const NormalFormTerm& trm,
            bool ignoreFactor = false) const ;
		int compare(const NormalFormTerm& trm, bool ignoreFactor = false)
            const ;
		int compare(const OrdinalImpl& ord) const ;
		int compare(const Ordinal& ord) const ;
		NormalFormTerm(const CantorNormalElement& elt):
			term(elt),next(NULL){term.reference();}
			
		static NormalFormTerm * create(const OrdinalImpl& exponent,
			Int factor=1);

 
		
		bool isFinite() const {return term.isFinite();}
		
		void add(const NormalFormTerm*& sum) const ;
		void add(const NormalFormTerm*& sum,
			const NormalFormTerm&  toAdd) const  ;
		void multiply(const NormalFormTerm*& prod, const NormalFormTerm&  op,
			const NormalFormTerm * finiteProdTerm) const ;
		void multiply(const NormalFormTerm& prod, const Int& finiteFac) const ;
		
		void prodInfiniteTerms(const OrdinalImpl*& ord) const ;

		void getInfiniteTerms(NormalFormTerm& trm) const 
		{
			if (isFinite()) return ;
			trm.append(term);
			if (next) next->getInfiniteTerms(trm);

		}
		const NormalFormTerm& getInfiniteTerms() const 
		{
			NormalFormTerm * trm = new NormalFormTerm(term);
			if (next) next->getInfiniteTerms(*trm);
			return *trm;
		}

		void addInfiniteTerms(const NormalFormTerm* toAdd) const {
			if (!toAdd) return ;
			if (isFinite()) return ;
			append(toAdd->term);
			addInfiniteTerms(toAdd->next);
		}
		
		const OrdinalImpl * takePowerOf(const CantorNormalElement & trm) const ;

		int count() const {
			if (next == NULL) return 1; return 1 + next->count();}
		const NormalFormTerm& getTail() const {if (next == NULL) return *this;
			return next->getTail();}

		const OrdinalImpl& subract(const Int& offset,
			NormalFormTerm * resultTerms = NULL) const ;

		const Int& getFiniteTerm() const ;
		bool hasFiniteTerm() const ;
        bool isSuccessor() const {return hasFiniteTerm() ;}
		const Int& getFiniteFac() const ;


		const OrdinalImpl& limitElement(Int n,const NormalFormTerm *t=0) const;
		void describe(ostream&out) const ;

		void describel(ostream&out) const {describe(out); out << "\n" ;}
		void doCountTerms(Int& count) const {
			count += term.factor; if (next) next->doCountTerms(count);}

		Int countTerms() const {Int temp; doCountTerms(temp); return temp;}

		const NormalFormTerm * listCopySubtractOmega() const ;
		const NormalFormTerm * listCopyOff(Int& offset) const ;
		const NormalFormTerm * listCopy() const ;
		const NormalFormTerm * makeInfiniteCopy() const {
			if (isFinite()) return NULL ;
			 NormalFormTerm * ret = new NormalFormTerm(term);
			if (next) ret->next = next->makeInfiniteCopy() ;
			return ret ;
		}
		void normalForm(string & s) const ;

		void psiNormalForm(string& str) const ;
		void texNormalForm(string& str) const ;
		string texNormalForm() const {string s; texNormalForm(s);return s;}

		string normalForm() const ;
		
		const NormalFormTerm * replaceLast(const CantorNormalElement& e) const ;
	};


	struct DebugControl ;

	class OrdinalImpl  {
		friend class CantorNormalElement ;
		friend class AdmisNormalElement ;
		friend class IterFuncNormalElement ;

		friend struct NormalFormTerm ;
		friend class Ordinal ;

        friend const Ordinal& admisLevelFunctional(const Ordinal& levCK,
		    const Ordinal& iter, const Ordinal* const * params,
		    const Ordinal* drillDown);

		static int idCount ;
        static int cppUniqueInt ;
		bool inDeleteList ;
		const int id ;
		const OrdinalImpl * theLimitType ;
		const OrdinalImpl * theMaxLimitType ;
		const OrdinalImpl * theEmbedType ;
public:
		static DebugControl& debugControl ;
protected:
		unsigned refCount ;
		const NormalFormTerm* terms ; 
		string assignedNameString ;
		string normalFormString ;
public:
		virtual void normalFormName(string& base) const {base += normalForm();}
		virtual int psuedoCodeLevel() const ;

        virtual const Ordinal& getMaxEmbedIndex() const  ;

        const OrdinalImpl& getCompareIndexCK(bool ign) const ;
        const OrdinalImpl& removeDelta(const Ordinal& bound) const ;
		const bool hasFiniteTerm ;
		bool isLimit() const {return !isZero() && !hasFiniteTerm;}
		bool isSuccessor() const {return hasFiniteTerm;}
        bool isOmegaSuccessor() const ;
        bool isOmega() const ;
		bool singleTerm() const {if (terms) if (terms->next == NULL)
			if (terms->term.factor == 1) return true; return false;}
	
		const Int termCount ;

        
        const class AdmisLevOrdinal* getAdmissibleBase() const ;
        int getFTcodeLevel() const ;
        const OrdinalImpl& getDDindexVal() const ;


		static const OrdinalImpl& zero ;
		static const OrdinalImpl& one ;
		static const OrdinalImpl& two;
		static const OrdinalImpl& three ;
		static const OrdinalImpl& four ;
		static const OrdinalImpl& five ;
		static const OrdinalImpl& six ;
		static const OrdinalImpl& omega ;
		static const Int zeroInt ;
		const Int getFiniteTerm() const {if (!terms) return 0;
			return terms->getFiniteTerm();}

        string normalFormOpt(bool texFlag) const;
		void texNormalForm(string& str) const ;
		void psiNormalForm(string& str) const ;
        virtual string& cppNormalForm(const string& nameBase, string& ret)
            const ;
        static string cppUnique() ;
        string & psiNormalForm() const 
            {string& s = *new string; psiNormalForm(s);return s;}
            
		string& texNormalForm() const
            {string& s = *new string; texNormalForm(s);return s;}
		const CantorNormalElement * lastTerm ;
		bool oneTerm() const
			{if (terms) if (!terms->next) return true; return false;}

		const OrdinalImpl& plus_1() const 
			{return addLoc(one);}
	    const OrdinalImpl& limPlus_1() const
			
			{if (psuedoCodeLevel() > CantorNormalElement::cantorCodeLevel)
				return addLoc(one); return *this; }

protected:
		
		
		
		void normalFormName() const ;

		static list<OrdinalImpl *> urefImp ;
		bool noRef() const {urefImp.push_front((OrdinalImpl *)this);
			return true;}
		
		void commonInit(const char * from);
		bool clearInDeleteList() const
			{if (!inDeleteList) describel(outStream());
			assert(inDeleteList) ;
			((OrdinalImpl *)this)-> inDeleteList = false ;
			return inDeleteList ; }

        int getHighestCodeLevel() const ;

        const Ordinal * maxEmbedIndex ;
	

		OrdinalImpl(const OrdinalImpl& copyFrom, Int off=0);

		OrdinalImpl(const CantorNormalElement& elt):lastTerm(0),
			assignedNameString(elt.normalForm()),id(idCount++),
			terms(new const NormalFormTerm(elt)),maxEmbedIndex(NULL),
			termCount(terms?terms->countTerms():0),
			hasFiniteTerm(terms->hasFiniteTerm()){commonInit("elt");}

		OrdinalImpl(const string& name,const NormalFormTerm&  trms):
			lastTerm(0),
			assignedNameString(name),id(idCount++),
			terms(&trms),refCount(0),maxEmbedIndex(NULL),
			termCount(terms?terms->countTerms():0),
			hasFiniteTerm(trms.hasFiniteTerm()) {commonInit("string");}

		OrdinalImpl(const char * name,const NormalFormTerm&  trms):
			lastTerm(0),maxEmbedIndex(NULL),
			assignedNameString(name),id(idCount++),
			terms(&trms),refCount(0),
			termCount(terms?terms->countTerms():0),
			hasFiniteTerm(trms.hasFiniteTerm()) {commonInit("char");}

		OrdinalImpl(unsigned long n) ;

		OrdinalImpl(Int n) ;

		OrdinalImpl(int n1, int n2) ; 

        OrdinalImpl(const NormalFormTerm * trms, const string& name);

		virtual ~OrdinalImpl();

        void termsCopy(NormalFormTerm *& terms, Int lastFactor) const ;

		const OrdinalImpl& makeInfiniteTermCopy() const {
			assert(terms);
			return * new OrdinalImpl(assignedNameString,
				*(terms->makeInfiniteCopy()));
		}

		string exprName(const OrdinalImpl& a, const char * oper,
			 const OrdinalImpl&b) const ;


		void outOperands(char  oper, const OrdinalImpl& b) const;

		const OrdinalImpl& finitePowerLoc(unsigned long) const ;
		const OrdinalImpl& finitePowerLoc(const Int& n) const ;

public:
		const CantorNormalElement * getLastTerm() const ;
		const OrdinalImpl& getMaxParameter() const	;

		const OrdinalImpl& maxLimitType() const	;
        virtual bool isValidLimitOrdParam(const OrdinalImpl& dd) const ;
        // virtual bool isValidLimitParam(const OrdinalImpl& dd) const ;
		virtual const OrdinalImpl& limitType() const ;
		virtual const OrdinalImpl* embedType() const ;

        CantorNormalElement::LimitTypeInfo getLimitInfo() const ;
		
		// const OrdinalImpl& maxEmbedLimitType(const OrdinalImpl& embedIX) const;
		// const OrdinalImpl& embedLimitType(const OrdinalImpl& embedIX) const ;
		
		
		static void outOperands(char  oper, const OrdinalImpl& a,
			const OrdinalImpl& b) ;
		const OrdinalImpl& subtract(const Int& offset) const ;
		const OrdinalImpl& subtractOmega() const ;
		const OrdinalImpl& addLoc(const OrdinalImpl&op) const ;
		const OrdinalImpl& addLoc(const int n) const ;
		const OrdinalImpl& addLoc(const Int n) const ;
		const OrdinalImpl& multLoc(const OrdinalImpl&op) const ;
		const OrdinalImpl& powerLoc(const OrdinalImpl&op) const ;


		ostream & out(const string cmt="") const ;


		const OrdinalImpl& addLoc(const Ordinal&op) const ;

		void reference() const {((OrdinalImpl *)this)->refCount++;}
		void dereference() const ;
		const OrdinalImpl& getInfiniteTerms() const ;
		const OrdinalImpl& limit(const Ordinal * const * const ords) const;
		const OrdinalImpl& limit(const Int n, const Ordinal& ord) const ;
		const OrdinalImpl& limitElement(Int n) const ;
		const OrdinalImpl& limitOrd(const OrdinalImpl & ord) const ;


		const string& assignedName() const {return assignedNameString;}
		const string& normalForm() const {
			if (normalFormString.empty()) normalFormName();
			return normalFormString;}
		int compare(const Embeddings& context, const Embeddings& paramContext,
            const OrdinalImpl& ord) const ;
		int compare(const OrdinalImpl& ord) const ;
		int compare(const Ordinal& ord) const ;


        static const OrdinalImpl& expFunctional(
            const OrdinalImpl &exponent, Int factor=1)  ;

		const NormalFormTerm * getTerms() const {return terms;}
		const CantorNormalElement* getFirstTerm() const {
			if (terms) return &(terms->term);
			return NULL ;
		}
        const CantorNormalElement * getOnlyTerm() const 
        {
            if (!terms || terms->next) return NULL ;
            return &(terms->term) ;
        }
		const OrdinalImpl& getIndexCK() const {
			if (!terms) return zero ;
			return terms->term.getIndexCK();
		}
		const CantorNormalElement* getSecondTerm() const {
			if (terms) if (terms->next) return &(terms->next->term);
			return NULL ;
		}

        const bool multipleTerms() const {return getSecondTerm() != NULL;}
			
		bool isFinite() const {if (!terms) return true ;
			return terms->isFinite();}
		bool isZero() const {return terms == NULL;}
		bool isOne() const {if (terms) return terms->term.isOne();
			else return false; }
		Int getInt() const ; 
		int get_int() const ; 
		static void deleteUnref();
		int refCnt() const {return refCount;}


		void describe(ostream&out) const
			{ out << assignedNameString << " : " << normalForm();}
		void describel(ostream&out) const {describe(out); out << "\n" ;}
		void descr(const char * comment=0) const ;
        virtual const OrdinalImpl& indexCKlimitType() const ;
        static const Ordinal& indexCKlimitType(const Ordinal &ix)  ;


		static Int intExp(const Int& a , const Int& b);
		static unsigned long int ulongFromInt(const Int& in);
		static string itoa(Int num);

        static void texDocument();

	};

  class NestedEmbeddings ;

 class Embeddings {
        const bool drillDownEmb ;
    public:
        bool isDrillDownEmbed() const {return drillDownEmb;}
        const Ordinal& embedIndex ;
        const Ordinal& embedIndexMo ;
        const Ordinal& baseLimitTypeEquiv ;
        const Ordinal& baseLimitTypeEquivDD ;

        virtual const Ordinal& getLimitTypeEquiv() const
            {return baseLimitTypeEquiv;}
        const enum Type {none,paramRestrict,indexedParamRestrict} type ;
        const int embedLevel ;
        static const int baseEmbedLevel = 1 ;

        Embeddings(const Ordinal& ddIx,Type typ, bool ddEmb=false,
            int embLevel = baseEmbedLevel);
        virtual Embeddings& createVirtualEmbedding(const Ordinal& ddIx,
            Type typ, bool ddEmb) const
        {return * new Embeddings(ddIx,typ,ddEmb);}

        bool isParamRestrict() const ;
        bool isAnyParamRestrict() const {return (type == paramRestrict) ||
            (type == indexedParamRestrict);}
        static const Embeddings embedNone ;
        virtual string normalForm() const ;
        virtual string& cppNormalForm(const string& nameBase, string& ret) const ;
        virtual string typeName(Type typ) const;
        virtual const Ordinal& getEffLevel() const {return embedIndex;}
        virtual const struct IndexedLevel * const * getIndicies() const
            {return NULL;}
        virtual int compare(const Embeddings& embed) const ;
        virtual const Embeddings& ddEmbCopy() const ;
        virtual const Embeddings& ddEmbFalseCopy() const ;
        virtual const NestedEmbeddings * getNested() const {return NULL;}
        virtual const Embeddings& embedClass() const {return *this;}
        virtual bool leastLevelEq(const Ordinal&ix) const ;
    };


    struct LastReturnCode {
            int codeLevel ;
            const char * exitCode ;

            int codeLevel2 ;
            const char * exitCode2 ;

            int codeLevel3 ;
            const char * exitCode3 ;
            enum ArgType{intType,ordType} argType;

            void setExitCode(const CantorNormalElement & elt);
            void setExitCode(const OrdinalImpl & ordI) ;
            void setExitCode(const Ordinal & ord);

            const char * getExitCode(const CantorNormalElement & elt);
            const char * getExitCode(const OrdinalImpl & elt);
            const char * getExitCode(const Ordinal & elt);


            void clear() {codeLevel = -1; codeLevel2 = -1; codeLevel3 = -1;
                exitCode = NULL; exitCode2 = NULL; exitCode3=0;}

            LastReturnCode(ArgType argTyp=intType):codeLevel(-1),
                codeLevel2(-1), codeLevel3(-1),exitCode(NULL), exitCode2(NULL),
                exitCode3(NULL), argType(argTyp){}
            void setExit(const char * ex, int lev)
                {
                    exitCode = ex ;
                    codeLevel=lev;
                }
            void setExit2(const char * ex2, int lev)
                {
                    exitCode2 = ex2 ;
                    codeLevel2=lev;
                    if (exitCode3==NULL) {
                        exitCode3 = ex2 ;
                        codeLevel3=lev;
                    }
                }

            static LastReturnCode lastLimitCode ;
            static LastReturnCode lastLimitOrdCode; 
        };


}

#include "ordinal.h"

#define DBGO if (dbg) outStream() << __LINE__ << " : " <<

