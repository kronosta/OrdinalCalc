#!/usr/local/bin/perl
while(<STDIN>){ s/^\%.*$/\%/; s/([^\\])\%.*$/\1\%/g; print; }
exit(0);
