/*
 *  linlist.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  linlist.h   */
/*  Copyright 1991 Mountain Math Software  */
/*  All Rights Reserved                    */
void ** AddToList (const void * Add, void ** const &  TheList) ;
void ** AddListToList (const void ** const Add,  void ** const &  TheList) ;
void *** AddListToListOfLists (const void ** Add, void *** const & TheList) ;
int ListLength(const void ** TheList) ;


