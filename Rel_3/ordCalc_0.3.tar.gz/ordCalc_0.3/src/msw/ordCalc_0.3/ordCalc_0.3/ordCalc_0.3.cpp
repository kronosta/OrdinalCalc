// ordCalc_0.3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

#include <string.h>
extern void  mn_program(int argc, char ** argv);


int _tmain(int argc, char * argv[])
{
	
	mn_program(argc,argv);
	
	return 0;
}

