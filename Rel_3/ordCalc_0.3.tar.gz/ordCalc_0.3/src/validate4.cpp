#include "stdafx.h"


#include "validate.h"
#include "ordTop.h"

using namespace std;
using namespace ord ;

void Validate::cppTest()
{
#include "cppTestOut.h"
}

void Validate::cppTestTeX()
{
#include "cppTestOutTeX.h"
}
