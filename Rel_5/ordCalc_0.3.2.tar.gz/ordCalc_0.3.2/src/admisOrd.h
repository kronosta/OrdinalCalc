#include "iterfuncOrd.h"

using namespace std ;
	
namespace ord {

   	class AdmisNormalElement : public IterFuncNormalElement {
        static const Ordinal& theAdmisClassLimit ;
	protected:

        class AdmisLevParameters : public IterFuncParameters {
		public:
			const OrdinalImpl * leastSigParam;
			const Ordinal& indexCK ;
			const Ordinal& drillDown ;
            const Embeddings& embeddings ;
			AdmisLevParameters(const Ordinal& ixCK, const Ordinal& iter,
				const Ordinal * const * const params=NULL,
				const Ordinal& dd = Ordinal::zero,
                const Embeddings & embed = Embeddings::embedNone,
				int level = admisCodeLevel);
			virtual ~AdmisLevParameters(){}

		};


        bool validAdmisNormalElementInt() const;
	public:
        virtual const char * className() const {return "AdmisNormalElement";}
        static bool validAdmisNormalElement(const Ordinal& inx,
            const Ordinal& iter, const Ordinal * const * const params,
            const Ordinal& dd, const Embeddings& embed=Embeddings::embedNone,
            int codeLevel=AdmisNormalElement::admisCodeLevel);

		const OrdinalImpl& indexCK ;
		const OrdinalImpl& indexCKmo ;
		const Ordinal& indexCKo ;
		const Ordinal& drillDown ;
		const OrdinalImpl & leastSigParam ;
        const bool indexCKeq ;

		virtual const OrdinalImpl& getIndexCK() const {return indexCK;}

private :    
        const AdmisLevOrdinal * admissibleBase;
        const AdmisNormalElement& createAdmissibleBase() const ;
        const OrdinalImpl& kappaLim(const OrdinalImpl& effEmbIx) const;
public:
        int entryCount ;
        int entryInc() const
            {return ++(((AdmisNormalElement *) this)->entryCount);}
        int entryDec() const
            {return --(((AdmisNormalElement *) this)->entryCount);}
        const AdmisNormalElement & admissibleBaseElement ;
		
        const AdmisLevOrdinal& getAdmissibleBase() const ;
        const class AdmisLevOrdinalImpl& getAdmissibleBaseImpl() const ;
        const OrdinalImpl& getCompareIndexCK(
            const Embeddings* emb=NULL) const ;
        const OrdinalImpl& ixMone ;
        const Embeddings &embeddings ;


		AdmisNormalElement(const Ordinal& indexCK, const Ordinal& iter,
			const Ordinal* const * const params, 
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings&embed = Embeddings::embedNone,
            Int fac=1);

		AdmisNormalElement(const AdmisLevParameters* prma, Int fac=1);

		static const int admisCodeLevel = iterFuncCodeLevel + 1 ;

        virtual const Ordinal & leUse(const OrdinalImpl& le) const;
        // const Ordinal & leUse(Int n) const;
        // const Ordinal & loUseLe(const OrdinalImpl& le) const;
        static const Ordinal & increasingLimit(const Ordinal& effDelta,
            const OrdinalImpl& limitElt) ;
        // virtual const Ordinal & loUse(const OrdinalImpl& ord) const;

        const AdmisNormalElement& addEmbeddings(const Embeddings& emb,
            const Ordinal&dd) const;


		virtual void normalFormName(string& base) const ;
		virtual void texNormalForm(string& str) const ;
        virtual void psiNormalForm(string& str) const ;
        virtual const string cppClassName()
            const {return "admisLevelFunctional";}
        virtual string& cppNormalForm(const string& nameBase, string& ret)const;

        const Ordinal& classLimit() const {return theAdmisClassLimit;}

        static const OrdinalImpl& indexCKtoLimitType(const OrdinalImpl&ix);
          //  const Ordinal&dd = Ordinal::zero);

		const AdmisNormalElement& addParam(const Ordinal& param) const;
		

        bool isEmbDrillDown() const ;
		

		virtual const CantorNormalElement& getCopy(const Int fac=1) const;

		const OrdinalImpl& typeIndexCK() const ;
		static const OrdinalImpl& typeIndexCK(const OrdinalImpl& ixCK)  ;
		static const OrdinalImpl& typeIndexCKemb(const OrdinalImpl& ixCK)  ;
        //const OrdinalImpl& deltaRestrict(const OrdinalImpl& type,
        //    bool ddz) const ;

		const OrdinalImpl* limitInfoCommon(
            CantorNormalElement::LimitTypeInfo& info) const ;
		virtual const OrdinalImpl& limitInfo(
            CantorNormalElement::LimitTypeInfo& info) const ;

        virtual const OrdinalImpl& setLimitType(
            CantorNormalElement::LimitTypeInfo&
            typeInfo, const OrdinalImpl *type) const ;

        static const OrdinalImpl& boundedLimitType(const Ordinal& bound,
            const OrdinalImpl&type, const Ordinal& dd = Ordinal::zero);

       // virtual bool isValidLimitParam(const OrdinalImpl& dd) const ;
        virtual bool isValidLimitOrdParam(const OrdinalImpl& dd) const ;

		// virtual const OrdinalImpl& limitType() const ;
		virtual const OrdinalImpl& maxLimitType() const ;
		/* virtual const OrdinalImpl& maxLimitType(const Ordinal&ignore) const 
            {return maxLimitType();} */
        //static const OrdinalImpl& limitTypeBound(const OrdinalImpl& delta) ;

		virtual const OrdinalImpl& limitElement(Int n) const;
		const OrdinalImpl& limitElementCom(Int n) const;
		virtual const OrdinalImpl& drillDownLimitElement(Int n) const;
		const OrdinalImpl& drillDownLimitElementCom(Int n) const;

		const OrdinalImpl& limitOrdCom(const OrdinalImpl & ord) const;
		virtual const OrdinalImpl& limitOrd(const OrdinalImpl & ord) const ;
		virtual const CantorNormalElement & addFactors(
			const CantorNormalElement& toAdd) const ;

        const Embeddings& effectiveEmbedding(
            const Embeddings& termEmbd,bool compareFlag=false) const ;

        virtual const OrdinalImpl& effectiveIndexCK(
            const Embeddings& embed) const ;

        virtual int compare(const Embeddings& embed,
            const Embeddings& termEmbed,
            const CantorNormalElement& trm, bool ignoreFactor = false) const ;

        int compareCom(const Embeddings& embed,
            const Embeddings& termEmbed,
            const CantorNormalElement& trm, bool ignoreFactor = false) const ;

        int compare(const OrdinalImpl& trm) const
            { return CantorNormalElement::compare(trm); }


		virtual int compare(const CantorNormalElement& trm,
			bool ignoreFactor = false) const ;

        virtual const OrdinalImpl& limitForIndexCKlimitParamUn(
            const OrdinalImpl& indexCKle) const;
		

		protected:
		const OrdinalImpl& dRep1(const Ordinal& nval) const;

		private:
        static const Ordinal & drillDownLimitValue ;

		virtual const OrdinalImpl & createVirtualOrdImpl(const Ordinal & ix,
			const Ordinal & lev, const Ordinal * const * const params,
			const Ordinal& drillDownParams,
            const Embeddings& embed) const ;
		virtual const Ordinal & createVirtualOrd(const Ordinal & ix,
            const Ordinal & lev, const Ordinal * const * const params,
			const Ordinal& drillDownParams, const Embeddings& embed) const ;

        virtual const OrdinalImpl & createVirtualOrdImpl(const Ordinal & lev,
			const Ordinal * const * const params=NULL) const ;
		virtual const Ordinal & createVirtualOrd(const Ordinal & lev,
			const Ordinal * const * const params=NULL) const ;

        virtual const OrdinalImpl & createVirtualOrdImpl(const Ordinal & ix,
            const Ordinal & lev, const Ordinal * const * const params,
                const Ordinal& dd) const ;
		virtual const Ordinal & createVirtualOrd(const Ordinal & ix,
            const Ordinal & lev, const Ordinal * const * const params,
                const Ordinal& dd ) const ;



		virtual const OrdinalImpl & createVirtualOrdImpl(
			const Ordinal * const * const params) const ;

		virtual const Ordinal & createVirtualOrd(
			const Ordinal * const * const params) const ;


	

	};


	class AdmisLevOrdinalImpl: public IterFuncOrdinalImpl {
		friend class AdmisNormalElement ;
		friend class AdmisLevOrdinal ;
		static const NormalFormTerm& createTerms(const Ordinal& indexCK,
			const Ordinal& iter, const Ordinal* const * const params,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone, Int factor=1);
        

		static string makeName(const Ordinal& ixCK, const Ordinal& iter,
			const Ordinal* const * const params,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone);
		static string makeTexName(const Ordinal& ixCK, const Ordinal& iter,
			const Ordinal* const * const params,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone);

    protected:
		static string makeNameCom(string& base, const Ordinal& ixCK,
            const Ordinal& iter, const Ordinal* const * const params,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone);
		static string makeTexNameCom(string& base, const Ordinal& ixCK,
            const Ordinal& iter, const Ordinal* const * const params,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone);
    public:

		AdmisLevOrdinalImpl(const Ordinal& indexCK, const Ordinal& iter,
			const Ordinal* const * const params=NULL,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone, Int factor = 1):
			IterFuncOrdinalImpl(makeName(indexCK,iter, params,drillDown,embed),
					createTerms(indexCK,iter, params,drillDown,embed,factor)){}

		AdmisLevOrdinalImpl(const AdmisNormalElement& elt):
			IterFuncOrdinalImpl(elt){}

		AdmisLevOrdinalImpl(const string& name,const NormalFormTerm&  trms):
			IterFuncOrdinalImpl(name,trms){}

        const AdmisLevOrdinal* getAdmissibleBase() const ;

			
		virtual ~AdmisLevOrdinalImpl(){}

        const AdmisNormalElement * getFirstAdmis() const ;
        
		const OrdinalImpl& getIndexCK() const ;
        
        

        const OrdinalImpl& addEmbeddings(const Embeddings &embed,
            const Ordinal&dd) const;

	};

	class AdmisLevOrdinal : public IterFuncOrdinal {
	public:
		AdmisLevOrdinal (const Ordinal& indexCK, const Ordinal& ord1,
			const Ordinal&ord2):
			IterFuncOrdinal(*new AdmisLevOrdinalImpl(indexCK,ord1,
				createParameters(&ord2))){}
			
		AdmisLevOrdinal (const Ordinal& indexCK, const Ordinal& ord1,
			const Ordinal&ord2, const Ordinal& ord3):IterFuncOrdinal(
			*new AdmisLevOrdinalImpl(indexCK,
			ord1,createParameters(&ord2,&ord3))){}

		AdmisLevOrdinal (const Ordinal& indexCK, const Ordinal& ord1,
			const Ordinal&ord2,
			const Ordinal& ord3, const Ordinal&ord4):IterFuncOrdinal(
			*new AdmisLevOrdinalImpl(indexCK,ord1,
			createParameters(&ord2,&ord3,&ord4))){}
		
		AdmisLevOrdinal (const Ordinal& indexCK, const Ordinal& iter,
			const Ordinal* const * const params=NULL,
			const Ordinal& drillDown = Ordinal::zero,
            const Embeddings& embed=Embeddings::embedNone, Int factor=1):
			    IterFuncOrdinal(*new AdmisLevOrdinalImpl(indexCK,iter,params,
				    drillDown,embed,factor)){}

		AdmisLevOrdinal(const AdmisLevOrdinalImpl& ord):
			IterFuncOrdinal(ord){}

	
		virtual ~AdmisLevOrdinal(){}
		
		
		// enum {indexCKmaxParam = -2};
		static bool fixedPoint(const OrdinalImpl& ixCK, const Ordinal& iter,
            int ix, const Ordinal* const * const params, const Embeddings& e);
		static void texDocument() ;


	};



    void admisLimitEle(bool testFlag = false);
    void admisLimitEle2(bool testFlag = false);
    void admisLimitEle3(bool testFlag = false);

	


}
