using namespace std ;
namespace ord {

    class Ordinal ;

    class LabeledOrdinal {
    public:
        const char * name ;
        const char * subName ;
        const char * lowerSubName ;
        const Ordinal &ord ;
        const Ordinal &ordp ;
        enum Act {output=0x1,testOnly=0x2,comment=0x4,setNames=0x8,
            noCheck=0x10} theAct ;
    private:
        void checkValidLimitCode(struct LastReturnCode& lrc);
        void checkValidLimitCode() ;
        void checkValidLimitOrdCode() ;
    public:
        LabeledOrdinal(const char * str, const Ordinal& o,
            const char * sStr=NULL, const Ordinal &p = Ordinal::zero,
            Act tAct = output, const char * lowerStr=NULL):
            name(str),ord(o),ordp(p),subName(sStr),theAct(tAct),
            lowerSubName(lowerStr){
            if (!(theAct&noCheck)) {
                if (p.isZero()) checkValidLimitCode(); 
                else checkValidLimitOrdCode(); 
            }
        }
        static const char * texName(const char *nm);

        typedef void ListLabeledOrds(list<LabeledOrdinal*>& labOrds);
        static void runTest(int count, ListLabeledOrds);


        static void limitOrdTable(ListLabeledOrds genList,
	        const Ordinal * const * indicies, string ordinalClass);


        // NestedEmbed
        static void nestedLimitEltExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void nestedDdLimitEltEqExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void nestedEmbedLimitEltExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void nestedBaseimitEltExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void nestedParamLimitEltExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void nestedEmbedLimitOrdExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void transitionTestNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void admisLimitElementExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void admisLimitEltComExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void admisdrillDownLimitExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void admisdrillDownLimitComExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void cppExampNames(
            list<LabeledOrdinal*>& labOrds) ;
        static void admisLimitOrdExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void admisLimitOrdExampleNames(
            list<LabeledOrdinal*>& labOrds);
        static void finiteFuncLimitElementComExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
        static void iterFuncLimitElementComExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);





        // Admis
        static void admisLimitEltExitCodeTestNames(
            list<LabeledOrdinal*>& labOrds);
    };

    


}
