sub writeMenu {
	##print "out menu $menuPlace:$menuPlace:T:$hasTopMenu:B:$hasBottomMenu\n" ;
	if (!$replaceMenus) {
		if (($menuPlace eq "top") && $hasTopMenu) {return;}
		if (($menuPlace eq "bottom") && $hasBottomMenu) {return;}
	}
	print OUTFILE "<!-- Start MMS $menuPlace menu -->\n" ; 
	print OUTFILE "<P><div align=\"center\">\n" ;
	if (($menuPlace ne "top") || !$hasTopLogo) {
		print OUTFILE "<strong><a href=\"$rootBase/index.html\" title =\n";
		print OUTFILE "\"Science and philosophy, facts and speculation\"\n" ;
		print OUTFILE ">Mountain Math Software</a></strong><br>\n";
	}
	print OUTFILE "<table bgcolor=\"#FFFFCC\" border=\"1\" cellpadding=\"5\" summary=\n" ;
	print OUTFILE "\"main menu\">\n" ;
	print OUTFILE "<tr>\n" ;
	print OUTFILE "<td><a href=\"$rootBase/index.html\" title =\n" ;
	print OUTFILE "\"Science and philosophy, facts and speculation\"\n>home</a></td>\n" ;
	print OUTFILE "<td><a href=\"$rootBase/consult/index.html\" title=\n" ;
	print OUTFILE "\"Image and signal processing, parallel computing\">consulting</a></td>\n" ;
	print OUTFILE "<td><a href=\"$rootBase/movies/index.html\" title =\n" ;
	print OUTFILE "\"Videos connecting biological evolution to mathematics\">videos</a></td>\n" ;
	print OUTFILE "<td><a href=\"$rootBase/willbe.html\" title =\n" ;
	print OUTFILE "\"What is and what will be: Integrating spirituality and science\">book</a></td>\n" ;
	print OUTFILE "<td><a href=\"$rootBase/faq/index.html\" title =\n" ;
	print OUTFILE "\"Measurement in quantum mechanics FAQ\">QM FAQ</a></td>\n" ;
	##print OUTFILE "<td><a href=\"$rootBase/wwwboard/index.html\" title =\n" ;
	##print OUTFILE "\"Post a comment and read the posts pf others\">postings</a></td>\n" ;
	print OUTFILE "<td><a href=\"$rootBase/mtnmath.html\" title =\n" ;
	print OUTFILE "\"Contact information for Mountain Math Software\">contact</a></td>\n" ;
	print OUTFILE "</tr>\n" ;
	print OUTFILE "</table>\n" ;
	if ($menuPlace eq "bottom") {
		print OUTFILE "Email comments to:\n" ;
		print OUTFILE "<a href=\"mailto:webmaster\@mtnmath.com\">webmaster\@mtnmath.com<\/a>\n" ;

	}
	print OUTFILE "</div>\n" ;
	print OUTFILE "<!-- End MMS $menuPlace menu -->\n" ; 
}

$replaceMenus = 1 ;

while ($iarg <= $#ARGV) {
	$inf = $ARGV[$iarg++] ;
	$truncName = $inf ;
	$truncName =~ s/htdocs\/// ;
	
	(open INFILE, $inf) || die "Cannot read file `$inf'.\n";
    print "Processing '$inf'.\n" ;
	##$str = $inf ;
	##$str =~ s/([^\/]*\/)+// ;
	$slash = 0 ;
	$i=0;
	$sv = vec("/",0,8);
	##print "sv: $sv\n" ;
	for ($i=0; $ch= vec($truncName, $i, 8); $i++) {
		##print "$ch\n" ;
		$ch != $sv || $slash++ ;}
	if ($slash == 0) {$rootBase = "." ;}
	else {
		$rootBase = ".." ;
		for ($i =1 ; $i < $slash;$i++) {$rootBase = $rootBase . "/.." ;}
	}
	##print "slash:$slash\n" ;
	$hasCharSet = 0 ;
	$hasTopLogo = 0 ;
	$hasCenteredTopLogo = 0 ;
	$hasDefaultCss = 0 ;
	$hasTopMenu = 0 ;
	$hasBottomMenu = 0 ;
	$hasGoogAnal = 0 ; 

	$bodyLine = 0 ;
	$inBody = 0 ;
	$checkCentered = 0 ;
	$logoLine = 0 ;
	$startTopMenu = "<!-- Start MMS top menu -->" ;
	$endTopMenu = "<!-- End MMS top menu -->" ;
	$startBottomMenu = "<!-- Start MMS bottom menu -->" ;
	$endBottomMenu = "<!-- End MMS bottom menu -->" ;
	while ($line = <INFILE>) {
		if ($line =~ /\<body/) {$inBody=1;}
		!$inBody || $bodyLine++ ;
		if ($line =~ /\<meta http-equiv=\"Content-Type\" content=*/ ){$hasCharSet = 1;}
		if ($line =~ /\<link rel=\"stylesheet\" type=\"text\/css\" href=\"$rootBase\/default.css\"\>/)
			{$hasDefaultCss = 1;}
		if ($line =~ /$startTopMenu/) {$hasTopMenu = 1 ;}
		if ($line =~ /$startBottomMenu/) {$hasBottomMenu = 1 ;}
		if ($line =~ /\/mmsfoot1.js\" type=\"text\/javascript/) {$hasGoogAnal = 1 ;}
		##if ($line =~ /getTracker\(\"UA-6428858-1\"\)*/) {$hasGoogAnal = 1 ;}
		if ($line =~ /\<img src=\"sdhrlogo.gif\"/) {
			if ($bodyLine < 10){
				$hasTopLogo = 1;
				$checkCentered = 1 ;
				##print "set checkCentered\n" ;
				$logoLine = $bodyLine ;
			}
		}
		if ($checkCentered) {
			if (($bodyLine - $logoLine) > 8) {$checkCentered=0;}
			elsif ($line =~ /\<\/div/) {
				$hasCenteredTopLogo = 1;
				$checkCentered = 0 ;
			}
			elsif ($line =~ /\<div/) {$checkCentered=0;}
		}
	}
	
	##print "char:$hasCharSet, Goog:$hasGoogAnal, TL:$hasTopLogo, cen:$hasCenteredTopLogo\n" ;
	close INFILE;
	print "$inf\n" ;
	(open INFILE, $inf) || die "Cannot read file `$inf'.\n";
	$checkBodyLine = 0 ;
	$headOut = 0 ;
	$outf = "temp_html" ;
	$htmlOut = 0 ;
	$addedChar = 0 ;
	$addedCss = 0 ;
	$addedTop = 0 ;
	$findLogoDviEnd = 0 ;
	$removedOldBottomMenu = 0 ;
	$addedBottom = 0 ;
	$addedAnal = 0 ;
	$replaceTopMenu = $replaceMenus && $hasTopMenu ;
	$replaceBottomMenu = $replaceMenus && $hasBottomMenu ;
	$replacedTop = 0 ; 
	$replacedBottom = 0 ;
	#print "has centered $hasCenteredTopLogo\n" ;
	(open OUTFILE, ">".$outf) || die "Cannot create file `$outf'.\n";
	$deletingTopMenu = 0 ;
	$deletingBottomMenu = 0 ;
	$skipped = 0 ;
	while ($line = <INFILE>) {
		$write = 1 ;
		$htmlLine = 0 ;
		$headLine = 0 ;
		$bodyLine= 0 ;
		$endBodyLine = 0 ; 
		$endLogoLine = 0 ;
		if ($replaceMenus) {
			if ($deletingTopMenu && $line =~ /$endTopMenu/) {
				$line = $' ;
				$deletingTopMenu = 0 ;
			} elsif ($deletingBottomMenu && $line =~ /$endBottomMenu/) {
				$line = $' ;
				$deletingBottomMenu = 0 ;
			} elsif ($line =~ /$startTopMenu/) {
				$line = $' ;
				print OUTFILE "$line\n";
				$menuPlace = "top" ;
				writeMenu ;
				$replacedTop = 1 ;
				$deletingTopMenu = 1;
			} elsif ($line =~ /$startBottomMenu/) {
				$line = $' ;
				print OUTFILE "$line\n";
				$menuPlace = "bottom" ;
				writeMenu ;
				$replacedBottom = 1 ;
				$deletingBottomMenu = 1;
			}

		}
		if (!$htmlOut && $line =~ /\<html\>/) {$htmlLine = 1;}
		if (!$htmlOut && $line =~ /\<head\>/) {$headLine = 1;}
		
		if (!$headOut && $line =~ /\<body/) {
			if ($line =~ /<body.*>/) {
				$bodyLine = 1;
			} else {$checkBodyLine=1;}
			##!$checkBodyLine || print "$line" ;
		} elsif ($checkBodyLine) {
			if ($line =~ />/) {
				$bodyLine = 1;}
				$checkBodyLine = 0 ;
		}

		if ($findLogoDviEnd) {
			if ($line =~ /<\/div/) {
				$findLogoDviEnd = 0 ;
				$endLogoLine = 1 ;
			}
		} elsif (!$addedTop && ($line =~ /\<img src=\"sdhrlogo.gif\"/)) {
			##print "FoundGif\n" ;
			if ($hasTopLogo && !$hasCenteredTopLogo) {$endLogoLine = 1 ;}
			elsif ($hasTopLogo) {
				$findLogoDviEnd = 1 ;
				##print "search div end\n" ;
			}
		}
		if ($line =~ /\<\/body\>/) {$endBodyLine = 1 ;}

		if (!$replaceBottomMenu && $endBodyLine && !$hasBottomMenu) {
			!$addedBottom || die "two bottoms\n" ;
			$menuPlace = "bottom" ;
			writeMenu ;
			$addedBottom = 1 ;
		}
		if ($endBodyLine && !$hasGoogAnal) {
			!$addedAnal || die "added Anal twice" ;
			print OUTFILE "<script src=\"$rootBase\/mmsfoot1.js\" type=\"text\/javascript\"> </script>\n" ;
			print OUTFILE "<script src=\"$rootBase\/mmsfoot2.js\" type=\"text\/javascript\"> </script>\n" ;
			$addedAnal = 1 ;
		}
		if ($deletingTopMenu || $deletingBottomMenu) {$write = 0 ;}
		if ($write) {print OUTFILE "$line" ;}
		else {$skipped++;}
		if ($headLine) {
			(!$htmlLine && !$bodyLine) || die "headLine and other line\n" ;
			if (!$hasCharSet) {
				!$addedChar || die "added char twice\n" ;
				print OUTFILE "<meta http-equiv=\"Content-Type\" content=\n" ;		
				print OUTFILE "\"text/html; charset=us-ascii\">\n" ;
				$addedChar = 1 ;
			}
			if (!$hasDefaultCss) {
				!$addedCss || die "added CSS twice\n" ;
			print OUTFILE "<link rel=\"stylesheet\" type=\"text/css\" href=\"$rootBase/default.css\">\n" ;
			$addedCss = 1 ;
			}
		}
		if (!$replaceTopMenu && $bodyLine) {
			!$htmlLine || die "bodyLine AND htmlLine\n" ;
			if (!$hasTopLogo) {
				!$addedTop || die "two tops A\n" ;
				$menuPlace = "top" ;
				writeMenu ;
				$addedTop=1 ;
			}
		}
		if (!$replaceTopMenu && $endLogoLine) {
			!$htmlLine || die "htmlLine AND logoLine\n" ;
				!$addedTop || die "two tops B\n" ;
			$menuPlace = "top" ;
			writeMenu ;
			$addedTop=1 ;
		}
	}
	
	close INFILE ;
	close OUTFILE ;
	if ($replaceMenus) {
		if (!$replacedTop) {print "Error: Top NOT replaced.\n" ;}
		if (!$replacedBottom) {print "Error: Bottom NOT replaced.\n" ;}
		if ($addedChar) {print "Error: added charset.\n" ;}
		if ($addedCss) {print "Error: addedCss.\n" ;}
		if ($addedTop) {print "Error: addedTop.\n" ;}
		if ($addedBottom) {print "Error: addedBottom.\n" ;}
		if ($addedAnal) {print "Error: addedAnalytics.\n" ;}
	}
	unlink $inf || die "Cannot unlink $inf.\n";
	#print "rename $outf $inf\n";
	rename $outf, $inf || die "Cannot rename $outf to $inf.\n";

	## now tidy it up
	$status = system("/usr/bin/tidy","-m",$inf);
	$status >=0|| die "Tidy error exit $status at $inf.\n";
}

