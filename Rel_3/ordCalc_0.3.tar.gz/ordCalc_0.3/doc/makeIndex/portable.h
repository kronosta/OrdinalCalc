/*
 *  portable.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  portable.h   */
/*  Copyright 1989 Mountain Math Software	*/
/*  All Rights Reserved                   	*/
/* This file contains definitions to facilitate			*/
/* porting code between various machines.			*/
/* The main problem is supporting 16 bit machines (primarily	*/
/* PC AT under DOS.						*/
/* It is used in both C and C++ code.				*/
#ifndef PORTABLE_DOT_H
#define PORTABLE_DOT_H

typedef unsigned int uint32;
typedef int int32;
typedef short int int16;
typedef unsigned short int uint16 ;
typedef char int8;
typedef unsigned char uint8 ;
#endif

