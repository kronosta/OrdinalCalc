#include "stdafx.h"


#include <fstream>

#include "nestedEmbedOrd.h"
#include "validate.h"
#include "validDoc.h"
#include <list>

using namespace std;

using namespace ord;

#define DBGO if (dbg) outStream() << __LINE__ << " : " <<

#define DBG1  outStream() <<__FILE__ << __LINE__ << " : " <<

string IndexedLevel::normalForm() const
{
    string ret = level.normalForm();
    ret += "/" ;
    ret += index.normalForm() ;
    return ret ;
}

NestedEmbeddings::PrevDiff NestedEmbeddings::getPrevLevDiff
    (const IndexedLevel * const * inds)
{
    assert(inds);
    assert(*inds);
    int last = 0 ;
    for (; inds[last]; last++);
    assert (last > 0) ;
    if (last == 1) return onlyOne ;
    const Ordinal& lLevel = inds[last-1]->level  ;
    const Ordinal& pLevel = inds[last-2]->level ;
    const Ordinal& lLevelMo = * new Ordinal(lLevel.getImpl().subtract(1));
    int diff = lLevelMo.compare(pLevel) ;
    // if (diff >=0) assert(lLevel.compare(pLevel) > 0);
    if (diff == 0) return equalMo ;
    if (diff < 0) return equal ;
    return less ;

}

NestedEmbeddings::PrevDiff NestedEmbeddings::getPrevInxDiff
    (const IndexedLevel * const * inds)
{
    assert(inds);
    assert(*inds);
    switch(prevLevDiff) {
case equal:
        {
            assert(inds);
            assert(*inds);
            int last = 0 ;
            for (; inds[last]; last++);
            assert (last > 1) ;
            const Ordinal& lIndex = inds[last-1]->index  ;
            const Ordinal& pIndex = inds[last-2]->index ;
            const Ordinal& lIndexMo =
                * new Ordinal(lIndex.getImpl().subtract(1));
            int diff = lIndexMo.compare(pIndex) ;
            if (diff == 0) return equalMo ;
            if (diff < 0) assert(0);
            return less ;

        }
case equalMo:
        return less ;
case less:
        return less ;
case onlyOne:
        return onlyOne ;
    }
}

NestedEmbeddings::LeastValue NestedEmbeddings::setLeastValue() const
{
    assert(levelCount > 0);
    const IndexedLevel * lastIndexedLevel = nestedIndicies[levelCount-1] ;
    if (lastIndexedLevel->index.isSuccessor())
        if (prevInxDiff == equalMo) return indexSuccDel ; else 
        if ((prevInxDiff == less) || (prevInxDiff == onlyOne))
            return indexSuccDecr; else
       assert(0);
    if (lastIndexedLevel->index.isLimit()) return indexLimit ;

    if (lastIndexedLevel->level.isSuccessor())
        if (prevLevDiff == equalMo) return levelSuccDel ; else 
        if ((prevLevDiff == less) || (prevLevDiff == onlyOne))
            return levelSuccDecr; else 
        assert(0);
    if (lastIndexedLevel->level.isLimit()) return levelLimit ;
    assert(0);

}

const Ordinal& NestedEmbeddings::setLeast() const
{
    assert(levelCount > 0);
    const IndexedLevel * lil = nestedIndicies[levelCount-1] ;
switch (leastValue) {
case indexSuccDecr:
case indexSuccDel:
case indexLimit:
        return lil->index;
case levelSuccDecr:
case levelSuccDel:
case levelLimit:
        return lil->level ;
default:
    assert(0);
    }

}


NestedEmbeddings::NestedEmbeddings(const IndexedLevel * const * inds,
    bool ddEmb, int lev, HowCreated how):
    Embeddings(inds[0]->level,
    paramRestrictLevel(inds).isZero()?indexedParamRestrict:
        paramRestrict, ddEmb,lev),
    embedOnly(*new Embeddings(inds[0]->level,paramRestrict, ddEmb,
        baseEmbedLevel)),
    nestedIndicies(inds),
    maxIndex(getMaxIndex(inds)),
    levelCount(countLevels(inds)),
    howCreated(how),
    lastLevel(nestedIndicies[levelCount-1]->level),
    lastIndex(nestedIndicies[levelCount-1]->index),
    prevLevDiff(getPrevLevDiff(inds)),
    prevInxDiff(getPrevInxDiff(inds)),
    leastValue(setLeastValue()),
    least(setLeast()),
    normalFormString(makeEmbName())
{
    // XXXX assert(embedLevel>=nestedEmbedLevel);
    assert(levelCount > 0);
}

NestedEmbeddings::NestedEmbeddings(const Ordinal& level, const Ordinal& index,
    bool ddEmb, int lev, HowCreated how):
    Embeddings(level,paramRestrict,ddEmb,lev),
    embedOnly(*new Embeddings(level,paramRestrict, ddEmb,
        baseEmbedLevel)),
    nestedIndicies(IndexedLevel::ary(lev,index)),
    maxIndex(index),
    howCreated(how),
    levelCount(1),
    lastLevel(level),
    lastIndex(nestedIndicies[levelCount-1]->index),
    prevLevDiff(onlyOne),
    prevInxDiff(onlyOne),
    leastValue(setLeastValue()),
    least(setLeast()),
    normalFormString(makeEmbName())
{}

bool NestedEmbeddings::validNestedEmbeddings(const IndexedLevel * const * inds,
    bool ddEmb, int lev)
{
    assert(inds[0]) ;
    if (!inds[1]) return true ;
    const Ordinal * prevLevel = &(inds[0]->level) ;
    const Ordinal * prevIndex = &(inds[0]->index) ;
    int count = 1 ;
    for (const IndexedLevel * const * ix = inds+1; *ix; ix++,count++) {
        const Ordinal& lev = (*ix)->level ;
        const Ordinal& inx = (*ix)->index ;
        int levDiff = lev.compare(*prevLevel) ;
        if (levDiff < 0) {
            outStream() << "Succesive level indicies in embed pair " <<
                (count + 1) << " must be equal or increasing,\n" ;
            return false ;
        }
        if (levDiff == 0) {
            int inxDiff = inx.compare(*prevIndex) ;
            if (inxDiff <= 0) {
                outStream() << "Index in embed pair " << (count+1) <<
                    " must be larger than the previous index when the " <<
                    "corresponding levels are equal.\n" ;
                return false ;
            } 
        }
    }
    return true ;
}

int NestedEmbeddings::countLevels( const IndexedLevel * const * levels)
{
    int ret = 0 ;
    if (levels)
        for (const IndexedLevel * const *levs = levels; *levs;levs++,ret++);
    return ret ;
}

const Ordinal& NestedEmbeddings::getMaxIndex(const IndexedLevel * const * inds)
{
    const Ordinal * max = &Ordinal::zero;
    for (const IndexedLevel * const * ind = inds; *ind; ind++)
        if (max->compare((*ind)->index)<0) max = &((*ind)->index) ;
    return *max ;
}

string NestedEmbeddings::makeEmbName() const
{
    assert((nestedIndicies[0] != NULL) && (
        (nestedIndicies[1] != NULL) || 
        (!nestedIndicies[0]->index.isZero())));
    string base = "" ;
    base += "[[" ;
    bool first = true ;
    for (const IndexedLevel * const * ix = nestedIndicies ;
        *ix != NULL; ix++) {
        if (first) first = false ; else base += ", " ;
        const IndexedLevel& ixLev =   **ix ;
        assert(!ixLev.level.isZero());
        base += ixLev.level.normalForm();
        if (!ixLev.index.isZero()) {
            base += "/" ;
            base += ixLev.index.normalForm();
        }
    }
    base += "]]" ;
    return base ;
}


static const char * getPrevDiffName(NestedEmbeddings::PrevDiff pr)
{
#define LISWE(name) case NestedEmbeddings::name: return #name
    switch (pr) {
        LISWE(equal);
        LISWE(equalMo);
        LISWE(less);
        LISWE(onlyOne);
default:
        assert(0);
    }
#undef LISWE
}

string NestedEmbeddings::normalForm() const
{
    
    string theTypeName = typeName(type);
    string ret = normalFormString ;
    ret += " : " ;
    ret += theTypeName ;
    ret += ", lev = " ;
    ret += getPrevDiffName(prevLevDiff) ;
    ret += ", inx = " ;
    ret += getPrevDiffName(prevInxDiff) ;

    return ret ;
}

const Ordinal& NestedEmbeddings::paramRestrictLevel(
    const IndexedLevel * const * indicies)
{
    assert(indicies != NULL) ;
    assert(indicies[0] != NULL);
    return indicies[0]-> level;
    //??????????????????????
    /*
    int ix = 0;
    while (indicies[ix++]);
    const IndexedLevel& last = *(indicies[ix-2]) ;
    if (!last.index.isZero()) return Ordinal::zero;
    return last.level ;
    */
}
    
string& NestedEmbeddings::cppNormalForm(const string& name, string& ret) const
{
    string mName = name ;
    string nameNum = OrdinalImpl::cppUnique();
    mName += nameNum ;
    mName += "IndexedLevel" ;

    string temp = "\tstatic const IndexedLevel * const " ;
    temp += mName ;
    temp += "[]= {\n" ;
    for (const IndexedLevel * const * ix = nestedIndicies ;
        *ix != NULL; ix++) {
        const IndexedLevel& ixLev =   **ix ;
        temp += "\t\tnew IndexedLevel(" ;
        ixLev.level.cppNormalForm(name,temp);
        temp += " ," ;
        ixLev.index.cppNormalForm(name,temp) ;
        temp += "),\n" ;
    }
    temp += "\t\tNULL\n\t};\n" ;
    if (ret.find_first_of('=')==string::npos) {
        temp += "\tconst Ordinal& " ;
        temp += name ;
        if (name == "cppName") temp += nameNum ;
        temp += " = " ;
     }
     ret.insert(0,temp);
     ret += "* new NestedEmbeddings( " ;
     ret += mName ;
     // ret += ", Embeddings::" ;
     // ret += typeName(type) ;
     ret += ", " ;
     ret += isDrillDownEmbed() ? "true" : "false" ;
     ret += ")" ;
    return ret ;

}


bool NestedEmbeddings::newDdEmb(DdEmbOpt ddOpt) const
{
    switch(ddOpt) {
case unchangedDdEmb:
        return isDrillDownEmbed();
case setDdEmb:
        return true ;
case clearDdEmb:
        return false ;
default:
        assert(0);
    }
}


const NestedEmbeddings& NestedEmbeddings::changeLeastIndex(
    const Ordinal& newIndex, DdEmbOpt ddOpt,HowCreated how) const
{
    assert(levelCount>0);
    assert((levelCount > 1 )||!newIndex.isZero());
    int last = levelCount-1 ;
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+1] ;
    retIndicies[levelCount] = NULL ;
    for (int i = 0 ; i < last ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[last] = new IndexedLevel(nestedIndicies[last]->level,
        newIndex) ;
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        embedLevel,how);
}

const NestedEmbeddings& NestedEmbeddings::deleteLeastIndexedLevel(
    DdEmbOpt ddOpt)const
{
    assert(levelCount>1);
    int lvCount = levelCount -1 ;
    int last = lvCount-1;
    const IndexedLevel ** retIndicies = new const IndexedLevel*[lvCount+1] ;
    retIndicies[lvCount] = NULL ;
    for (int i = 0 ; i < last+1 ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    if ((lvCount ==1) && (retIndicies[0]->index.isZero())) assert(0);
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        nestedEmbedLevel,deleteLeast);

}

const Embeddings& NestedEmbeddings::deleteLeastIndexedLevelAll(
    DdEmbOpt ddOpt)const
{
    assert(levelCount>1);
    int lvCount = levelCount -1 ;
    int last = lvCount-1;
    if ((lvCount ==1) && (nestedIndicies[0]->index.isZero())) 
        return * new Embeddings(nestedIndicies[0]->level,paramRestrict,
            newDdEmb(ddOpt));
    const IndexedLevel ** retIndicies = new const IndexedLevel*[lvCount+1] ;
    retIndicies[lvCount] = NULL ;
    for (int i = 0 ; i < last+1 ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        nestedEmbedLevel,deleteLeast);

}



const NestedEmbeddings& NestedEmbeddings::deleteLeastIndex(DdEmbOpt ddOpt) const
{
    assert(levelCount>1);
    int last = levelCount-1 ;
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+1] ;
    retIndicies[levelCount] = NULL ;
    for (int i = 0 ; i < last ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[last] = new IndexedLevel(nestedIndicies[last]->level,
        Ordinal::zero) ;
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        embedLevel);

}

const NestedEmbeddings& NestedEmbeddings::changeLeastLevel(
    const Ordinal& newLevel, DdEmbOpt ddOpt, HowCreated how) const
{
    assert(levelCount>1);
    assert(!newLevel.isZero());
    int last = levelCount-1 ;
    const IndexedLevel& lastIndexed = *(nestedIndicies[last]) ;
    const IndexedLevel& prevIndexed = *(nestedIndicies[last-1]) ;
    const Ordinal& pIndex = prevIndexed.index ;
    assert(lastIndexed.index.isZero())  ;
    const Ordinal * newIndex = &Ordinal::zero ;
    int diff = newLevel.getImpl().compare(prevIndexed.level);
    assert(!(diff <0));
    if (diff == 0) {
        if (pIndex.isZero()) newIndex = &Ordinal::one ;
        else newIndex = new Ordinal(pIndex.getImpl().addLoc(1));
    }
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+1] ;
        retIndicies[levelCount] = NULL ;
    for (int i = 0 ; i < last ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    //retIndicies[last] = new IndexedLevel(newLevel,nestedIndicies[last]->index);
    retIndicies[last] = new IndexedLevel(newLevel,*newIndex);
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        embedLevel,how);

}

const NestedEmbeddings& NestedEmbeddings::appendIndexedLevel
    (const IndexedLevel& ixl) const
{
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+2] ;
    retIndicies[levelCount+1]=NULL;

    for (int i = 0 ; i < levelCount;i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[levelCount]= &ixl ;
    return * new NestedEmbeddings(retIndicies,isDrillDownEmbed(),
        embedLevel);
}


const NestedEmbeddings& NestedEmbeddings::decrementIndexAppend(
    const IndexedLevel& ixl) const
{
    const IndexedLevel * lastLevel = nestedIndicies[levelCount-1];
    assert(!lastLevel->index.isZero());

    IndexedLevel * newLev = new IndexedLevel(lastLevel->level,
        * new Ordinal(lastLevel->index.getImpl().subtract(1)));

    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+2] ;
    retIndicies[levelCount+1]=NULL;

    for (int i = 0 ; i < levelCount-1;i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[levelCount-1] = newLev ;
    retIndicies[levelCount]= &ixl ;
    return * new NestedEmbeddings(retIndicies,isDrillDownEmbed(),
        embedLevel);
}

const NestedEmbeddings& NestedEmbeddings::decrementLevelAppend(
    const IndexedLevel& ixl) const
{
    const IndexedLevel * lastLevel = nestedIndicies[levelCount-1];
    assert(!lastLevel->level.isZero());

    IndexedLevel * newLev = new IndexedLevel(
        * new Ordinal(lastLevel->level.getImpl().subtract(1)));

    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+2] ;
    retIndicies[levelCount+1]=NULL;

    for (int i = 0 ; i < levelCount-1;i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[levelCount-1] = newLev ;
    retIndicies[levelCount]= &ixl ;
    return * new NestedEmbeddings(retIndicies,isDrillDownEmbed(),
        embedLevel);
}





const NestedEmbeddings& NestedEmbeddings::appendLevel(const Ordinal& lev)
        const
{
    IndexedLevel * newLev = new IndexedLevel(lev);
    return appendIndexedLevel(*newLev);
}



const NestedEmbeddings& NestedEmbeddings::replaceLeastIndexedLevel(
            const IndexedLevel& newIndexedLevel, DdEmbOpt ddOpt,
            HowCreated how) const
{
    assert(levelCount>0);
    assert(! newIndexedLevel.level.isZero());
    int last = levelCount-1 ;
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+1] ;
    retIndicies[levelCount] = NULL ;
    for (int i = 0 ; i < last ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[last] = &newIndexedLevel ;
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        embedLevel,how);

}
const NestedEmbeddings& NestedEmbeddings::replaceTwoLeastLevels(
    const Ordinal& pLev, const Ordinal& pIx, const Ordinal& lLev,
    const Ordinal& lIx, DdEmbOpt ddOpt, HowCreated how) const
{
    assert(levelCount>1);
    assert(!pLev.isZero());
    int cmp = pLev.compare(lLev);
    assert ((cmp < 0) || ((cmp ==0) && (pIx.compare(lIx)<0)));
    int last = levelCount-2 ;
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount+1] ;
    retIndicies[levelCount] = NULL ;
    for (int i = 0 ; i < last ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    retIndicies[last] = new IndexedLevel(pLev,pIx);
    retIndicies[last+1] = new IndexedLevel(lLev,lIx);
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        nestedEmbedLevel,how);

}



const NestedEmbeddings& NestedEmbeddings::deleteLeastLevel(DdEmbOpt ddOpt) const
{
    assert(levelCount>1);
    int last = levelCount-1 ;
    const IndexedLevel ** retIndicies = new const IndexedLevel*[levelCount] ;
    retIndicies[last]=NULL ;
    for (int i = 0 ; i < last ; i++)
        retIndicies[i] = nestedIndicies[i] ;
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        embedLevel);

}


const NestedEmbeddings& NestedEmbeddings::truncate(int n,
    const IndexedLevel * toAppend, DdEmbOpt ddOpt) const
{
    assert ((n<=levelCount) && (n>0));
    if (n==levelCount) return *this ;
    int newSize = n + 1 + (toAppend==NULL?0:1);
    assert(newSize>1);
    const IndexedLevel ** retIndicies = new const IndexedLevel*[newSize] ;
    retIndicies[newSize-1] = NULL;
    for (int i=0; i < n;i++) retIndicies[i] = nestedIndicies[i];
    if (toAppend != NULL) retIndicies[n]= toAppend;
    return * new NestedEmbeddings(retIndicies,newDdEmb(ddOpt),
        embedLevel);

}

const NestedEmbeddings& NestedEmbeddings::truncateAddLevel(int n,
    const Ordinal& lLev, DdEmbOpt ddOpt) const
{
    const IndexedLevel* added = new IndexedLevel(lLev);
    return truncate(n,added,ddOpt);
}

const NestedEmbeddings& NestedEmbeddings::truncateChangeIndex(int n,
    const Ordinal& lix, DdEmbOpt ddOpt) const
{
    assert ((n<=levelCount) && (n>0));
    const IndexedLevel* added = new IndexedLevel(
        nestedIndicies[n-1]->level,lix);
    return truncate(n-1,added,ddOpt);
    
}

const Embeddings &NestedEmbeddings::nextLeast()
    const
{
    // this assumes indexCK == leastLevel
    assert(levelCount>0) ;
    const IndexedLevel& leastIndexedLevel =
        *(nestedIndicies[levelCount-1]) ;
    const Ordinal& lLevel = leastIndexedLevel.level ;
    const Ordinal& lIndex = leastIndexedLevel.index ;

    const IndexedLevel * pIl = NULL ;
    if (levelCount > 1) pIl =
        (nestedIndicies[levelCount-2]) ;

   bool subtractIndex = false ;
   
   if (lIndex.isSuccessor()) {
        switch (prevLevDiff) {
case equal:
            switch (prevInxDiff) {
    case equalMo:
                {
                    assert(pIl);
                    return deleteLeastIndexedLevelAll();
                    /*
                    assert(pIl->index.isSuccessor());
                    const Ordinal& pIndexMo = * new Ordinal(
                        pIl->index.getImpl().subtract(1));
                    const Ordinal &lIndexMo = * new Ordinal(
                        lIndex.getImpl().subtract(1)) ;
                    return replaceTwoLeastLevels(pIl->level,pIndexMo, lLevel,
                        lIndexMo,unchangedDdEmb,indexDecrTwo);
                    */
                }
    case less:
                subtractIndex = true ;
                break ;
    case equal:
    case onlyOne:
    default:
                assert(0);
            }
        break ;
case equalMo:
case less:
case onlyOne:
            subtractIndex = true ;
            break;
            
default:
        assert(0);
        }
    } else {
        assert(lIndex.isZero());
        assert(prevLevDiff != equal) ;
        assert(lLevel.isSuccessor());
        const Ordinal& newLevel = * new Ordinal(lLevel.getImpl().subtract(1));
        if (newLevel.isLimit()) {
            if (prevLevDiff == equalMo) {
                return deleteLeastIndexedLevelAll();
            }
        }
        if (prevLevDiff == equalMo) {
            const Ordinal * newIndex = &Ordinal::one ;
            assert(pIl);
            if (!pIl->index.isZero()) newIndex = new Ordinal(
                pIl->index.getImpl().addLoc(1));
            const IndexedLevel * newIndexedLevel =
                new IndexedLevel(newLevel,*newIndex);
            return replaceLeastIndexedLevel(*newIndexedLevel,unchangedDdEmb,
                levelDecrIndexSet);
        } assert(!(prevLevDiff == onlyOne));
        return changeLeastLevel(newLevel,unchangedDdEmb,levelDecr);
    }

    if (subtractIndex) {
        const Ordinal& newIndex = * new Ordinal(lIndex.getImpl().subtract(1));
        if ((levelCount == 1) && newIndex.isZero())
            return embedClass();

        return changeLeastIndex(newIndex,unchangedDdEmb,indexDecr);
    } else assert(0);
    assert(0);
}

bool NestedEmbeddings::leastLevelEq(const Ordinal&ix) const
{
    if (!isParamRestrict()) return false ;
    return ix.compare(lastLevel) == 0 ;
}


int NestedEmbeddings::compareEmbed(const OrdinalImpl & ord) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    if (dbg) outStream() << "(" << normalForm() << ")->compareEmbed(" <<
        ord.normalForm() << ")\n" ;
    const CantorNormalElement * ft = ord.getFirstTerm();
    // outStream() << "Ck0\n" ;
    if (!ft) return 1 ;
    // outStream() << "Ck1\n" ;
    int ftcl = ft->codeLevel ;
    if (ftcl < AdmisNormalElement::admisCodeLevel) return 1 ;
    // outStream() << "Ck2\n" ;
    const AdmisNormalElement * adFt = (const AdmisNormalElement *) ft ;
    const Embeddings& ftEmbed  = adFt->embeddings ;
    if (ftcl == AdmisNormalElement::admisCodeLevel) {
        if (ftEmbed.type != paramRestrict) return 1;
        // outStream() << "Ck3\n" ;
        return compare(ftEmbed) ;
        // outStream() << "Ck4\n" ;
    }
    if (ftcl > NestedEmbedNormalElement::nestedEmbedCodeLevel) return
        ftEmbed.compare(*this);
    // outStream() << "Ck5\n" ;
    const NestedEmbeddings& ftNestedEmbed = (const NestedEmbeddings& ) ftEmbed ;
    return compare(ftEmbed);
   
}


const CantorNormalElement& NestedEmbedNormalElement::getCopy(const Int fac)const
{
    assert(codeLevel == nestedEmbedCodeLevel);
    // DBG1 fac << "\n" ;
    const CantorNormalElement& ret =
        *new NestedEmbedNormalElement(indexCKo, functionLevelO,
        nestedEmbeddings, funcParameters, drillDown,fac);
    // DBG1 ret.factor << "\n" ;  
    return ret ;

}

#define NLCK(x) (x?x->normalForm():"NULL")

int NestedEmbeddings::compare(const Embeddings& emb) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    if (dbg) outStream() << "(" << normalForm() << ")->compare(" << emb.normalForm()
        << ")\n" ;
     assert(embedLevel==nestedEmbedLevel) ; 
    if (emb.embedLevel == baseEmbedLevel) {
        if (emb.type != paramRestrict) return -1 ;
        int diff = embedIndex.compare(emb.embedIndex) ;
        if ( diff < 0) return -1 ;
        return 1 ;
    }
    assert(emb.embedLevel == nestedEmbedLevel) ;
    const NestedEmbeddings& nemb = (const NestedEmbeddings&) emb;
    /*
    int diff = levelCount-nemb.levelCount;
    if (diff) return diff ;
    */

    // const NestedEmbeddings& nemb = (NestedEmbeddings&) emb ;
    const IndexedLevel * const * embIxs = nemb.nestedIndicies ;
    int ix = 0 ;
    for (int ix = 0;true; ix++) { 
        const IndexedLevel* ixl = nestedIndicies[ix] ;
        const IndexedLevel * eixl = embIxs[ix] ;
        if (dbg) outStream() << "comparing " << NLCK(ixl) <<
            " :: " << NLCK(eixl) << "\n" ;
        if (!ixl) if (!eixl) return 0 ; else return -1 ;
        if (!eixl) return 1 ;
        int diff = ixl->compare(*eixl) ;
        if (diff) return diff ;
    }
    assert(0); // should never get here
}

const NestedEmbeddings& NestedEmbeddings::ddEmbCopy() const
{
    return * new NestedEmbeddings(nestedIndicies,true,embedLevel);
}

const NestedEmbeddings& NestedEmbeddings::ddEmbFalseCopy() const
{
    return * new NestedEmbeddings(nestedIndicies,false,embedLevel);
}

NestedEmbedNormalElement::NestedEmbedParameters::NestedEmbedParameters(
    const Ordinal& ixCK, const Ordinal& iter,
    const NestedEmbeddings & embed, const Ordinal * const * const params,
	const Ordinal& dd, int level):
        AdmisLevParameters(ixCK,iter,params,
        dd,embed,level),nestedEmbeddings(embed)
{
    assert(maxParameter);
    if (maxParameter->compare(embed.maxIndex)<0) maxParameter =
        &(embed.maxIndex);
    
}

NestedEmbedNormalElement::NestedEmbedNormalElement(
    const Ordinal& ixCK, const Ordinal& iter, const NestedEmbeddings & embed,
    const Ordinal * const * const params, const Ordinal& dd, Int fac):
        AdmisNormalElement(new NestedEmbedParameters(ixCK,iter,embed,
        params,dd),fac),nestedEmbeddings(embed)

{
    // DBG1 fac << "\n" ;
    // DBG1 factor << "\n" ;
    assert(validNestedEmbedNormalElementInt());
    /*
    if (!drillDown.isZero()) {
        const CantorNormalElement * ddTerm1 =
            drillDown.getImpl().getFirstTerm();
        if (ddTerm1 && ddTerm1->codeLevel >= admisCodeLevel) {
            const Embeddings& ddEmbed =
                ((const AdmisNormalElement *)ddTerm1)->embeddings;
            if (ddEmbed.compare(embed)<0) return ;
        }
        const NestedEmbedNormalElement temp = * new NestedEmbedNormalElement(
            ixCK,iter,embed,params,Ordinal::zero,fac);
            const Ordinal& ddMax = drillDown.maxLimitType();
            int cmp = ddMax.compare(temp.limitType());
           // if (cmp == 0 && ddMax.isLimit()) cmp = -1 ;
            if (cmp >=0) {
                outStream() << "For " << normalForm() << "\n" ;
                outStream() << "temp = " << temp.normalForm() << "\n" ;
                outStream() << "limitType = " <<
                    temp.limitType().normalForm() << "\n" ;
                outStream() << "drillDown = " << drillDown.normalForm() << "\n";
                outStream() << "dd.maxLimitType = " <<
                    drillDown.maxLimitType().normalForm() << "\n";
                if (!ord::interactiveMode) assert(0);
            }
    }
    */
}

bool NestedEmbedNormalElement::validNestedEmbedNormalElementInt() const
{
    return validNestedEmbedNormalElement(indexCKo,functionLevelO,
        nestedEmbeddings,funcParameters,drillDown);
}

bool NestedEmbedNormalElement::validNestedEmbedNormalElement(
    const Ordinal& inx, const Ordinal& iter, const NestedEmbeddings& embed, 
    const Ordinal * const * const params, const Ordinal& dd)
{
    // Do not need to duplicate admissible ordinal checks which will be done
    // in constructing the base class before this code is executed
    int err = 0 ;
    struct Errs {int flag; const char *err;} errors[] = {
        {2,"indexCK must be a successor with []"},
        {4,"functionalLevel must be 0 with []"},
        {8,"no parameters allowed with []"},
        {0x10,"indexCK must be <= least significant level"},

        // The FOLLOWING THREE CHECKS ARE TODO
        {0x40,"[parameter.maxLimitType] < limitType"},
        {0x80,"embedIndex must be >= all internal instances of embedIndex"},
        {0x200,"[[prefix]] must be <= affected internal indeCK's"},
        // {0x400,"[[prefix]] must be >= all parameter [[prefix]] values"},
        {0x400,"most significant prefix level cannot be a limit"},


        {0x10000,
            "Embedded indicies with equal levels must be strictly increasing"},
        {0x20000,"Embedded levels must be equal or increasing"},
        {0x40000,"Embedded index must be zero if associated level is a limit"},
        {0x80000,"Largest (last) embedded level must be <= indexCK"},
        {0x100000,
            "Last index (sigma) with nonzero drillDown must not be a limit"},
        {0x200000,
            "Last level (delta) with zero last indeax and nonzero drillDown must not be a limi"},
        {0.0}
    };


    const IndexedLevel * const * firstIndex = embed.nestedIndicies ;
    assert(firstIndex) ;
    assert(*firstIndex) ;
    if ((*firstIndex)->level.isLimit()) err|=0x400 ;
    const IndexedLevel * const * prev = NULL ;
    for (const IndexedLevel * const * nestedIndicies = firstIndex ;
      *nestedIndicies ; nestedIndicies++) {
        const IndexedLevel * ni = (*nestedIndicies);
        if (ni->level.isLimit() && ! ni->index.isZero()) err |= 0x40000;
        if (prev != NULL) {
            int cmp = (*prev)->level.compare(ni->level);
            if ((cmp)>0) err |= 0x20000;
            if (!cmp) if ((*prev)->index.compare(ni->index)>=0) {
                err |= 0x10000;
                assert(0);
            }

        } 
        prev = nestedIndicies ;
    }
    assert(prev);
    const IndexedLevel * lastIndexedLevel = *prev ;
    int diff = lastIndexedLevel->level.compare(inx) ;
    if (diff>0) err |= 0x10 ;
    /* outStream() << "llnf " << lastIndexedLevel->level.normalForm() <<
        ", inx = " << inx.normalForm() << ", diff = " << diff <<
        ", err = " << err << "\n" ;
    */
    

    if (!dd.isZero()) {
        const Ordinal& lastLevel = (*prev)->level ;
        const Ordinal& lastIndex = (*prev)->index ;
        if (lastLevel.compare(inx)==0) {
            if (lastIndex.isLimit()) err|= 0x100000 ;
            if (lastIndex.isZero() && lastLevel.isLimit()) err |= 0x200000;
        }
    }
    // XXXX if (inx.compare(embed.lastLevel)<0) err |= 0x80000;

    // Code for nested embed check
    /*
    int cmp = embed.compareEmbed(inx);
    if (cmp < 0) err|= 0x400 ;
    cmp = embed.compareEmbed(iter);
    if (cmp < 0) err|= 0x400 ;
    */
    int sz=0;
    if (params) for (;params[sz];sz++) {
        const Ordinal * param = params[sz] ;
        // cmp = embed.compareEmbed(*param);
        //if (cmp < 0) err|= 0x400 ;
    }
    // cmp = embed.compareEmbed(dd);
    // if (cmp < 0) err|= 0x400 ;
    

    if (!dd.isZero()) {
        // if (!(*firstIndex)->level.isSuccessor()) err|=2 ;
        if (!iter.isZero()) err|=4 ;
        if (sz != 0) err |= 8 ;
        
    }


    if (err) {
        outStream() << "ERROR: in defining '[[list]]omega_{indexCK}(" << sz <<
            " parameter" << ((sz==1) ? ")" : "s)") ;
        if (!dd.isZero()) outStream() << "[" << dd.normalForm() << "]" ;
        outStream() << "':" ;
        bool out = false ;
        for (Errs * er = errors; er->flag;er++) {
            if (er->flag & err) {
                if (out) outStream() << "\nand " ;
                else outStream() << "\n" ;
                outStream() << er->err ;
                out = true ;
            }
        }
         outStream() << ".\n" ;
         outStream().flush();
        return false ;
    }
    return true ;
}


/*
const OrdinalImpl& NestedEmbedNormalElement::limitType() const
{
    if (theLimitType) return * theLimitType;

    LimitTypeInfo typeInfo = unknownLimit ;

    return AdmisNormalElement::limitType();
}
*/
/*
    LimitTypeInfo typeInfo;
    const OrdinalImpl& type = limitInfo(typeInfo) ;
    switch (typeInfo) {
case unknownLimit:
default:
        assert(0);
case zeroLimit:
case finiteLimit:        
case drillDownLimit:     
case drillDownSucc: 
case paramLimit:         
case paramNxtLimit:      
case paramSucc:          
case paramSuccZero:          
case paramsSucc:          

// CK related that still return type
case indexCKlimit:
case indexCKsuccParam:   
        return type ;
case indexCKsuccEmbed:        
        break ;
    }
}
*/
/*
const OrdinalImpl& NestedEmbedNormalElement::maxLimitType() const
{
    return AdmisNormalElement::maxLimitType();
}
*/
const Ordinal & NestedEmbedNormalElement::leUse(const OrdinalImpl& ord) const
{
    const IndexedLevel& lastLevel=nestedEmbeddings.lastLevelPair();
    return increasingLimit(lastLevel.level,ord);
}




void NestedEmbedNormalElement::normalFormName(string& base) const
{
    if (codeLevel < nestedEmbedCodeLevel) return
        AdmisNormalElement::normalFormName(base);
    bool useFactor = factor > 1 ;
    if (useFactor) base += "(" ;
    
    base += NestedEmbedOrdinalImpl::makeName(indexCKo,functionLevelO,
        funcParameters,drillDown,nestedEmbeddings);
    if (useFactor) {
        base += "*" ;
        base += OrdinalImpl::itoa(factor) ;
        base += ")" ;
    }


}



void NestedEmbedNormalElement::texNormalForm(string& str) const
{
    if (codeLevel < nestedEmbedCodeLevel) {
        NestedEmbedNormalElement::texNormalForm(str);
        return ;
    }
    bool useFactor = factor > 1 ;
    if (useFactor) str += "(" ;
    str += NestedEmbedOrdinalImpl::makeTexName(indexCKo,functionLevelO,
        funcParameters,drillDown,nestedEmbeddings);
    if (useFactor) {
        str += " " ;
        str += OrdinalImpl::itoa(factor) ;
        str += ")" ;
    }

}
string& NestedEmbedNormalElement::cppNormalForm(const string& name,
    string& ret) const
{
    bool useCreaParam = size <= ord::maxCreaParam ;
        ret += cppClassName();
        ret += "(\n\t\t" ;
        indexCKo.cppNormalForm(name,ret) ;
        ret += ",\n\t\t" ;
        functionLevelO.cppNormalForm(name,ret) ;
        ret += ",\n\t\t(" ;
        embeddings.cppNormalForm(name,ret);
        ret += "),\n\t\t" ;
        if (size == 0) ret += "NULL" ;
        else if (useCreaParam) {
            ret += "createParameters(\n\t\t\t&(";
            for (int i = 0 ; i < size ; i++) {
                if (i > 0) ret += "),\n\t\t\t&(" ;
                funcParameters[i]->cppNormalForm(name,ret) ;
            } 
            ret += "))" ;
        } else cppParamNormalForm(name,ret);
        ret += ",\n\t\t" ;
        drillDown.cppNormalForm(name,ret);
        if (factor > 1) {
            ret += ", " ;
            ret += factor.get_str();
        }
        ret += "\n\t)\n" ;
            
        return ret;

    
}


static const OrdinalImpl& returning1(bool dbg, const char *id,
    const OrdinalImpl& r,
    const Int& n, const NestedEmbedNormalElement& elt,bool saveFlag=false)
{
    if (saveFlag) {
        LastReturnCode::lastLimitCode.codeLevel =
            NestedEmbedNormalElement::nestedEmbedCodeLevel;
        LastReturnCode::lastLimitCode.exitCode = id ;
    } else LastReturnCode::lastLimitCode.setExit2(id,
        NestedEmbedNormalElement::nestedEmbedCodeLevel);

    if (!dbg) {
        if (Validate::validationTest)
            outDbgStream() << "Nested le ex " << id << "\n";
        
        return r ;
    } 

    outDbgStream() << "Nested -le limit returning at " << id << ", val = "
        << r.normalForm() << ", " << n << " limit of " << elt.normalForm()
            << "\n" ;
    return r;
}




#define RETURN1(id,x) return returning1(dbg, id, addFactorPart(x), n, \
    *this, true)

#define RETURN1X(id,x) return returning1(dbg, id, x, n, *this)


// The cases are :
        //      1. there is a least sigmificant index that can be decremented
        //      2. there is a least significant level that can be decremented
        //      3. all other cases that require creating Iterarive ordinals
        //      These are :
        //          1. Only the most significant level can be decremented
        //          2. The least sigificant value that can be decremented is
        //          an index limit
        //          3. The least significant value that can be decremmented is
        //          a level limit
#define CKU assert(limitState.indexUse < levelCount)

void NestedEmbedNormalElement::drillDownGetLimitInfo(LimitState&limitState)
const 
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    int levelCount = nestedEmbeddings.levelCount ;
    assert(levelCount) ;
    const IndexedLevel * prev =
            nestedEmbeddings.nestedIndicies[levelCount-1];
    const IndexedLevel * cur = NULL;
    /*
    int lastMatch = -1 ;
    int indexUse = -1;
    enum MatchState {LimitState::levelLimit, LimitState::indexLimit,
        noMatchLevel, noMatchIndex, unknown} ;
    MatchState matchState = unknown ;
    */
    int i = levelCount - 2 ;
    for (;i>-1;i--,prev=cur) {
        cur = nestedEmbeddings.nestedIndicies[i];
        if (prev->level.compare(cur->level)!=0) {
            if (!prev->index.isZero()) {
                if (prev->index.isLimit())
                    limitState.matchState = LimitState::indexLimit ;
                else limitState.matchState = LimitState::noMatchIndex ;
                limitState.indexUse=i+1 ;
                CKU;
                break ;
            }
            const Ordinal& curLevPo =
               * new Ordinal(cur->level.getImpl().addLoc(1));
            if (curLevPo.compare(prev->level) != 0) {
                if (prev->level.isLimit()) limitState.matchState = LimitState::levelLimit;
                else limitState.matchState = LimitState::noMatchLevel;
                limitState.indexUse = i+1 ;
                CKU;
                break ;
            }
            limitState.lastMatch = i ;
            continue ;
        } else { // prev->level.compare(cur->level)==0)
            if (prev->index.isLimit()) {
                limitState.matchState = LimitState::indexLimit;
                break ;
            }
            const Ordinal& curIndexPo =
               * new Ordinal(cur->index.getImpl().addLoc(1));
            if (curIndexPo.compare(prev->index)!=0) {
                limitState.matchState = LimitState::noMatchIndex ;
                limitState.indexUse =  i+1 ;
                CKU;
                break ;
            }
            limitState.lastMatch = i ;
            continue ;

        }
    }
    assert(cur);
    if (cur->index.isLimit()) {
        limitState.indexUse = 0 ;
        limitState.matchState = LimitState::indexLimit ;
    } else if (cur->level.isLimit()) {
        limitState.indexUse = 0 ;
        limitState.matchState = LimitState::levelLimit ;
    }
    if (limitState.matchState == LimitState::unknown) {
        limitState.indexUse = 0 ;
        limitState.matchState = LimitState::noMatchLevel ;
    }

    DBGO "limitState.indexUse = " << limitState.indexUse << "\n" ;
    DBGO "limitState.lastMatch = " << limitState.lastMatch << "\n" ;
    DBGO "unknown = " << LimitState::unknown << "\n" ;
    DBGO "limitState.matchState = " << limitState.matchState << "\n" ;
}

const OrdinalImpl& NestedEmbedNormalElement::drillDownLimitElementEq(Int n)
const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    // only called from drillDownLimitElement if 
    // drillDown.isSuccessor && !isDrillDownEmbed && lLevel.compare(indexCK)==0)
    const Embeddings& smallerEmbed = nestedEmbeddings.nextLeast();
    DBGO "smallerEmbed = " << smallerEmbed.normalForm() << "\n" ;
    const Ordinal& ddMo = * new Ordinal(drillDown.subtract(1));
    const Ordinal * base = NULL ;
    if (smallerEmbed.embedLevel == Embeddings::baseEmbedLevel) {
        if (ddMo.isZero()) base=&(admisLevelFunctional(indexCKo,Ordinal::zero,
            NULL,Ordinal::zero,smallerEmbed));
        else  base=&(createVirtualOrd(indexCKo,Ordinal::zero,
            NULL,ddMo));
       for (int i = 1; i < n;i++) base = &(admisLevelFunctional(
           *base,Ordinal::zero,NULL,Ordinal::zero,smallerEmbed));
        RETURN1("DQA",base->getImpl());
    }

    assert(smallerEmbed.embedLevel == NestedEmbeddings::nestedEmbedLevel);
    NestedEmbeddings& nestedSmallerEmbed = (NestedEmbeddings&) smallerEmbed;
    base = &(createVirtualOrd(indexCKo,Ordinal::zero, NULL,ddMo,
        ddMo.isZero()?nestedSmallerEmbed:nestedEmbeddings));

    switch (nestedSmallerEmbed.howCreated) {
default:
case NestedEmbeddings::unspecified:
        assert(0);
case NestedEmbeddings::indexDecr:
case NestedEmbeddings::indexDecrTwo:
        for (int i = 1; i < n ; i++) {
            const Ordinal& b = *base ;
            const NestedEmbeddings& newEmbed=nestedSmallerEmbed.
                appendLevel(b);
            base = &(createVirtualOrd(b,Ordinal::zero,NULL,
                Ordinal::zero,newEmbed));
        }
        RETURN1("DQB",base->getImpl());
       
case NestedEmbeddings::levelDecrIndexSet:
case NestedEmbeddings::levelDecr:
        if (nestedSmallerEmbed.lastLevel.isLimit()) {
            assert(nestedSmallerEmbed.lastIndex.isZero());
            for (int i = 1; i < n ; i++) {
                const NestedEmbeddings& newEmbed = nestedSmallerEmbed.
                    appendLevel(*base) ;
                base = &(createVirtualOrd(*base,Ordinal::zero,NULL,
                    Ordinal::zero,newEmbed)) ;
            }
            RETURN1("DQC",base->getImpl()) ;
        }
        for (int i = 1; i < n ; i++) {
            const NestedEmbeddings& newEmbed=nestedSmallerEmbed.
                changeLeastIndex( base->limPlus_1());
            base = &(createVirtualOrd(indexCKo,Ordinal::zero,NULL,
                Ordinal::zero,newEmbed));
        }
        RETURN1("DQD",base->getImpl()) ;
case NestedEmbeddings::deleteLeast:
        for (int i = 1; i < n ; i++) 
            base =  &(createVirtualOrd(*base,Ordinal::zero,NULL,
                Ordinal::zero,smallerEmbed));
        RETURN1("DQE",base->getImpl()) ;
    }
    assert(0);

}



/*
const OrdinalImpl& NestedEmbedNormalElement::drillDownLimitElement(Int n) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    DBGO "Entering Nested::drDwnLe(" << n << ")\n" ;
    //int levelCount = nestedEmbeddings.levelCount ;
    // assert(levelCount) ;
 //   const IndexedLevel * last = nestedEmbeddings.nestedIndicies[levelCount-1];
  //  const Ordinal &lLevel = last->level ;
   // const Ordinal &lIndex = last->index ;
    
    if (!drillDown.isLimit() && !nestedEmbeddings.isDrillDownEmbed() && 
         (nestedEmbeddings.lastLevel.compare(indexCK)==0)) {
        // (lLevel.compare(indexCK)==0)) {
        const OrdinalImpl& ret = drillDownLimitElementEq(n);
        RETURN1X("NDDD",ret);
     } // end !isLimit && !isDrillDownEmbed && level.compare(indexCK)==0

    assert(!drillDown.isZero());
    RETURN1X("NDDF", AdmisNormalElement::drillDownLimitElementCom(n));
}
*/
/*
#undef RETURN1
#undef RETURN1X

#define RETURN1(id,x) return returning1(dbg, id, addFactorPart(x), n, \
    *this, true)

#define RETURN1X(id,x) return returning1(dbg, id, x, n, *this)

*/
/*
const Ordinal& NestedEmbedNormalElement::zeta(Int nI)
{
    static const int stepSize = 10 ;
    static int savedCount = 0 ;
    static const Ordinal ** savedZeta = NULL ;
    unsigned long int nB = OrdinalImpl::ulongFromInt(nI) ;
    assert(nB < 10000000) ;
    int n = nB ;
    if (n>=savedCount) {
        int newCount = savedCount+stepSize ;
        if (newCount <= n) newCount = n+1;
        int baseIndex = savedCount-1 ;
        const Ordinal ** newSavedZeta = new const Ordinal *[newCount] ;
        if (savedZeta==NULL) {
            savedZeta = newSavedZeta ;
            newSavedZeta[0] = &Ordinal::zero ;
            newSavedZeta[1] = &Ordinal::omega ;
            baseIndex = 1 ;
        } else {
            for (int i = 0 ; i < savedCount; i++)
                newSavedZeta[i] = savedZeta[i] ;
        }
        const Ordinal * base = savedZeta[baseIndex] ;
        for (int i = baseIndex + 1; i < newCount ; i++) {
            base = &(admisLevelFunctional(*base,Ordinal::zero,NULL,
                 Ordinal::zero));
            newSavedZeta[i] = base ;
        }
        savedZeta = newSavedZeta ;
        savedCount = newCount ;
    }
    return *(savedZeta[n]);
}
*/
/*
 
     switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
case paramSucc:          
case paramLimit:         
case paramSuccZero:          
case paramsSucc:          
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
case drillDownLimit:     
case drillDownSucc:
case drillDownSuccCKOne:
case drillDownSuccEmbed:
case drillDownOne:
case drillDownCKOne: 
case drillDownOneEmbed:
case indexCKlimit:       
case indexCKsuccParam:
case indexCKsuccEmbed:
case indexCKsuccUn:
case indexCKlimitParamUn:
case indexCKlimitEmbed:
case leastIndexLimit:
case leastLevelLimit:
case leastIndexSuccParam:
case leastLevelSuccParam:
case leastIndexLimitParam:
case leastLevelLimitParam:


default:
        break ; // change to assert 0
    }



 */


const OrdinalImpl& NestedEmbedNormalElement::limitElement(Int n) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    if (dbg) outStream() << "Entering Nested " <<
        normalForm() << ".limitElement(" << n << ")\n" ;
    assert(codeLevel >= nestedEmbedCodeLevel) ;

         switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
case paramSucc:          
case indexCKsuccParamEq: // impossible for this level of ordinal
        assert(0);
case paramLimit:         
case paramSuccZero:          
case paramsSucc:          
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
case indexCKsuccParam:

case indexCKlimitParamUn:
        RETURN1X("NLA",AdmisNormalElement::limitElementCom(n));
case drillDownSucc:
case drillDownSuccCKOne:
case drillDownOne:
case drillDownCKOne: 
        if (nestedEmbeddings.lastLevel.compare(indexCK)==0) {
            const OrdinalImpl& ret = drillDownLimitElementEq(n);
            RETURN1X("NLB",ret);
        }
case drillDownLimit:     
case drillDownSuccEmbed:
case drillDownOneEmbed:
        RETURN1X("NLC", AdmisNormalElement::drillDownLimitElementCom(n));
case indexCKlimit:       
case indexCKsuccEmbed:
case indexCKsuccUn:
case indexCKlimitEmbed:
case leastIndexLimit:
case leastIndexLimitParam:
case leastLevelLimit:
case indexCKlimitParamEmbed:
case leastLevelLimitParam:
        RETURN1X("NLE",embedLimitElement(n));

case leastIndexSuccParam:
case leastLevelSuccParam:
    RETURN1X("NLP",paramLimitElement(n));

default:
        assert(0);
    }
    assert(0);
}


const OrdinalImpl& NestedEmbedNormalElement::limitForIndexCKlimitParamEmbed(
    const OrdinalImpl& indexCKle) const 
{
    assert(indexCK.isLimit());
    assert(size==1);
    // assert(lLevel.compare(indexCK)<0);
    const Ordinal *const * params = NULL ;
    const Ordinal& param = *(funcParameters[0]);
    if (!param.isOne()) {
        const Ordinal& paramMo = * new Ordinal(param.subtract(1));
        params = createParameters(&paramMo,NULL);
    }
    const Ordinal& base = createVirtualOrd(indexCKo,Ordinal::zero,
        params,Ordinal::zero);
  //   const OrdinalImpl& le = indexCK.limitElement(n);
    // const Ordinal& useBase = increasingLimit(lLevel,indexCKle);
    const Ordinal& useBase = leUse(indexCKle);
    return createVirtualOrdImpl(useBase,base.limPlus_1(),
            NULL,Ordinal::zero);
}


const OrdinalImpl& NestedEmbedNormalElement::limitForLeastIndexLimitParam(
    const OrdinalImpl& le) const 
{
    assert(size==1);
    const Ordinal& param = *(funcParameters[0]) ;
    assert(param.isSuccessor());
    const Ordinal& paramMo= * new Ordinal(param.subtract(1));
    const Ordinal& lIndexLim = * new Ordinal(le);
    // const Ordinal& lIndexLim = * new Ordinal(lIndex.limitElement(n));
    const Ordinal * indexBaseUse = &lIndexLim ;
    const Ordinal * slIndex = NULL ;
    int levelCount = nestedEmbeddings.levelCount;
    if (levelCount>1) slIndex =
        &(nestedEmbeddings.nestedIndicies[levelCount-2]->index) ;
    if (nestedEmbeddings.prevLevDiff == NestedEmbeddings::equal) 
        if (slIndex && !slIndex->isZero()) indexBaseUse =
            &(increasingLimit(*slIndex,indexBaseUse->getImpl()));
    const NestedEmbeddings& newEmbed =
        nestedEmbeddings.changeLeastIndex(*indexBaseUse);
    const Ordinal& base =
        createVirtualOrd(indexCKo,Ordinal::zero,createParameters(
        &paramMo,NULL),Ordinal::zero);

    return createVirtualOrdImpl(indexCKo,base.limPlus_1(),
        NULL,Ordinal::zero,newEmbed);
}


const OrdinalImpl& NestedEmbedNormalElement::limitForLeastLevelLimitParam(
    const OrdinalImpl& le) const 
{
    int levelCount = nestedEmbeddings.levelCount ;
    assert(nestedEmbeddings.lastIndex.isZero());
    assert(size==1);
    const Ordinal *const * params = NULL ;
    const Ordinal& param = *(funcParameters[0]);
    assert(param.isSuccessor());
    if (!param.isOne()) {
        const Ordinal& paramMo = * new Ordinal(param.subtract(1));
        params = createParameters(&paramMo,NULL);
     }
     const Ordinal& base = createVirtualOrd(indexCKo,Ordinal::zero,
                params,Ordinal::zero);

     assert(levelCount>1) ; // most significant level cannot be a limit
     const Ordinal & slLevel =
        nestedEmbeddings.nestedIndicies[levelCount-2]->level;

     // const OrdinalImpl& le = lLevel.getImpl().limitElement(n);
     const Ordinal & use = increasingLimit(slLevel,le);
     const NestedEmbeddings& newEmbed =
               nestedEmbeddings.changeLeastLevel(use);
    return createVirtualOrdImpl(use,base.limPlus_1(),NULL,
                Ordinal::zero,newEmbed);




}






const OrdinalImpl& NestedEmbedNormalElement::embedLimitElement(Int n) const 
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    assert(embeddings.type == Embeddings::paramRestrict) ;
    assert(functionLevel.isZero() );
    assert(drillDown.isZero());
    assert(size<2);
    int levelCount = nestedEmbeddings.levelCount ;
    assert(levelCount > 0);
    const IndexedLevel * last = nestedEmbeddings.nestedIndicies[levelCount-1];
    const Ordinal &lLevel = last->level ;
    const Ordinal &lIndex = last->index ;
        
    const Ordinal * slIndex = NULL ;
    const Ordinal * slLevel = NULL ;
    if (levelCount > 1) {
        const IndexedLevel * sLast = nestedEmbeddings.nestedIndicies[levelCount-2];
        slLevel = &(sLast->level) ;
        slIndex = &(sLast->index) ;
        
    }

 
     switch (getLimitInfo()) {
case indexCKsuccEmbed:
        {
            const NestedEmbeddings& embed =
                (const NestedEmbeddings &)nestedEmbeddings.ddEmbCopy();
            RETURN1("NEA",createVirtualOrdImpl(indexCKo,Ordinal::zero,NULL,
                *new Ordinal(n),embed));
        }

case leastIndexLimitParam:
        {
            const Ordinal & le = lIndex.limitElement(n);
            RETURN1("NEB", limitForLeastIndexLimitParam(le.getImpl()));
        }
case leastLevelLimitParam:
        {

            const Ordinal & le = lLevel.limitElement(n);
            RETURN1("NEC", limitForLeastLevelLimitParam(le.getImpl())) ;
        }

case indexCKsuccUn:
case indexCKlimitParamUn:
        assert(0);
case indexCKlimitEmbed:
        {
            assert(lLevel.compare(indexCK)<0);
            const Ordinal& ixLex = indexCKo.limitElement(n);
            const Ordinal& ixLe = increasingLimit(lLevel,ixLex.getImpl()) ;
            RETURN1("NED",createVirtualOrdImpl(ixLe,Ordinal::zero,NULL,
                Ordinal::zero));

        }

case leastIndexLimit:
        {
            const Ordinal *nIndex = &( lIndex.limitElement(n));
            bool useIncLm = slLevel && slIndex &&
                (slLevel->compare(lLevel)==0);
            if (useIncLm) {
                nIndex = &(increasingLimit(*slIndex,nIndex->getImpl()));
                
            }
            const NestedEmbeddings& nembed=
                nestedEmbeddings.changeLeastIndex(*nIndex);
            RETURN1("NEF",
                createVirtualOrdImpl(indexCKo,Ordinal::zero,
                NULL,Ordinal::zero,nembed));

        }

case leastLevelLimit:
        {
            assert(lIndex.isZero());
            assert(levelCount > 1);

            const Ordinal& levelLex = lLevel.limitElement(n);
            const Ordinal& levelLe = increasingLimit(
                *slLevel,levelLex.getImpl()) ;
            const NestedEmbeddings& retEmb = 
                nestedEmbeddings.changeLeastLevel(levelLe);
            RETURN1("NEG",createVirtualOrdImpl(levelLe,Ordinal::zero,
                NULL,Ordinal::zero,retEmb));

        }
case indexCKlimitParamEmbed:
        {
            const OrdinalImpl& le = indexCK.limitElement(n);
            RETURN1("NEH",limitForIndexCKlimitParamEmbed(le));
           
        }

default:
        assert(0) ; 
    }
    assert(0);
}

const OrdinalImpl& NestedEmbedNormalElement::paramLimitElement(Int n) const 
{

    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;

    assert((size==1)&&functionLevel.isZero());

    const Ordinal& param = *(funcParameters[0]);
    assert(param.isSuccessor());
    const Ordinal& paramMo = *new Ordinal(param.getImpl().subtract(1));
    const Ordinal * const * newParamArray = NULL ;
    if (!paramMo.isZero()) newParamArray = createParameters(
        &paramMo,NULL);

    const Ordinal * base = &(createVirtualOrd(Ordinal::zero,
        newParamArray));
    DBGO "base = " << base->normalForm() << "\n" ;

    const Embeddings& smallerEmbed = nestedEmbeddings.nextLeast();
    DBGO "smallerEmbed = " << smallerEmbed.normalForm() << "\n" ;
    switch(getLimitInfo()) {
case leastIndexSuccParam:
       if (smallerEmbed.embedLevel == Embeddings::baseEmbedLevel) {
            assert(smallerEmbed.embedIndex.compare(indexCK)==0);
            for (int i=1; i < n ; i++) base =
                &(admisLevelFunctional(indexCKo,
                base->limPlus_1(),NULL,Ordinal::zero,smallerEmbed));
            RETURN1("PLEB",base->getImpl()) ;
        }
        {
            const NestedEmbeddings& nestedSmallerEmbed =
                (const NestedEmbeddings &)smallerEmbed;
            if (nestedSmallerEmbed.howCreated ==
                NestedEmbeddings::deleteLeast) {
                for (int i=1; i < n ; i++) 
                    base=&(createVirtualOrd(*base,Ordinal::zero,NULL,
                        Ordinal::zero,nestedSmallerEmbed));
                RETURN1("PLEC",base->getImpl()) ;

            } else {
                for (int i=1; i < n ; i++) {
                    const NestedEmbeddings& nextEmbed =
                        nestedSmallerEmbed.appendLevel(*base);
                    base = &(createVirtualOrd(*base,Ordinal::zero,NULL,
                        Ordinal::zero,nextEmbed));
                }
                RETURN1("PLED",base->getImpl()) ;
            }
        }
case leastLevelSuccParam:
        {
            const NestedEmbeddings& nestedSmallerEmbed =
                (const NestedEmbeddings &)smallerEmbed;
            for (int i=1; i < n ; i++) {
                const NestedEmbeddings& nextEmbed = 
                    nestedSmallerEmbed.changeLeastIndex(base->limPlus_1());
                base = &(createVirtualOrd(indexCKo,Ordinal::zero,NULL,
                    Ordinal::zero,nextEmbed));
            }
            RETURN1("PLEE",base->getImpl()) ;
        }
default:
        assert(0);
    }
}

const OrdinalImpl* NestedEmbedNormalElement::limitInfoCommon(
            CantorNormalElement::LimitTypeInfo& typeInfo) const
{
    typeInfo = unknownLimit;
    const OrdinalImpl * type =  NULL ;
    /*AdmisNormalElement::limitInfoCommon(typeInfo);
    if (type) return type ;*/

    const IndexedLevel& lastLev = nestedEmbeddings.lastLevelPair();
     if ((size == 0) && functionLevel.isZero() && drillDown.isZero() &&
        (lastLev.level.compare(indexCK)==0)){
        if (lastLev.index.isLimit()) {
            typeInfo = leastIndexLimit;
            type = &(lastLev.index.limitType());
            return type;
        }
        if (lastLev.index.isZero() && lastLev.level.isLimit()) {
            typeInfo = leastLevelLimit;
            type = &(lastLev.level.limitType());
            return type;
        }
    }
    if ((size ==1)&&functionLevel.isZero()) {
        if (funcParameters[0]->isLimit()) {
            type = &(funcParameters[0]->limitType()) ;
            typeInfo = paramLimit ;
            return type ;
        } 
         type = &(integerLimitType);
        switch (nestedEmbeddings.leastValue) {
case NestedEmbeddings::indexSuccDecr:
case NestedEmbeddings::indexSuccDel:
            if (indexCK.compare(lastLev.level)==0)
            typeInfo = leastIndexSuccParam ;
            else if (indexCK.isSuccessor()) typeInfo = indexCKsuccParam ;
            else {
                typeInfo = indexCKlimitParamUn ;
                type = &(indexCK.limitType());
            }

            break ;
case NestedEmbeddings::levelSuccDecr:
case NestedEmbeddings::levelSuccDel:
            if (indexCK.compare(lastLev.level)==0)
                typeInfo = leastLevelSuccParam ;
            else if (indexCK.isSuccessor()) typeInfo = indexCKsuccParam ;
            else {
                type = &(indexCK.limitType());
                typeInfo = indexCKlimitParamEmbed ;
            }
            break ;
case NestedEmbeddings::indexLimit:
            if (indexCK.compare(lastLev.level)==0) {
                type = &(nestedEmbeddings.least.limitType());
                typeInfo = leastIndexLimitParam ;
             } else if (indexCK.isSuccessor()) {
                type = &(integerLimitType);
                typeInfo = indexCKsuccParam;
            } else {
                type = &(indexCK.limitType());
                typeInfo = indexCKlimitParamEmbed ;
            }
            break ;
case NestedEmbeddings::levelLimit:
            if (indexCK.compare(lastLev.level)==0) {
                type = &(nestedEmbeddings.least.limitType());
                typeInfo = leastLevelLimitParam ;
            }  else if (indexCK.isSuccessor()) {
                type = &(integerLimitType);
                typeInfo = indexCKsuccParam;
            } else {
                type = &(indexCK.limitType());
                typeInfo = indexCKlimitParamEmbed ;
            }

            break ;
default:
            assert(0);
        }
            
        return type ;
       
    }   
    if (!type) type = AdmisNormalElement::limitInfoCommon(typeInfo);
    return type ;



}


const OrdinalImpl& NestedEmbedNormalElement::limitInfo(
            CantorNormalElement::LimitTypeInfo& typeInfo) const
{
    typeInfo = unknownLimit;
    const OrdinalImpl * type = limitInfoCommon(typeInfo);

    return AdmisNormalElement::setLimitType(typeInfo,type);
}

static const OrdinalImpl& returningOrd(bool dbg, const char *id,
    const OrdinalImpl& r, const OrdinalImpl& ord,
    const NestedEmbedNormalElement& elt, bool saveFlag=false)
{
    if (saveFlag) {
        LastReturnCode::lastLimitOrdCode.codeLevel =
            NestedEmbedNormalElement::nestedEmbedCodeLevel;
        LastReturnCode::lastLimitOrdCode.exitCode = id ;
    } else LastReturnCode::lastLimitOrdCode.setExit2(id,
        NestedEmbedNormalElement::nestedEmbedCodeLevel);
    if (dbg) outDbgStream() << "Nested limitOrd returning at " << id <<
        ", val = " << r.normalForm() << ", " << ord.normalForm() <<
        " limit of " << elt.normalForm() << "\n" ;
    else if(Validate::validationTest) outDbgStream()
        << "Nested lo ex " << id << "\n";
    return r;
}

#define RETURNO(id,x) return returningOrd(dbg, id, addFactorPart(x),ord, \
    *this,true)
#define RETURNOX(id,x) return returningOrd(dbg, id, x,ord,*this)



const OrdinalImpl& NestedEmbedNormalElement::limitOrd(const OrdinalImpl & ord)
    const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    if (dbg) outStream() << "Nested entering for " <<
        normalForm() << ".limitOrd(" << ord.normalForm() << ")\n" ;
    assert(codeLevel==nestedEmbedCodeLevel) ;
    assert(!ord.isFinite());
    assert(isValidLimitOrdParam(ord));
    if (nestedEmbeddings.compareEmbed(ord) < 0) assert(0);
    int levelCount = nestedEmbeddings.levelCount;

    assert(levelCount > 0);
    const IndexedLevel * last = nestedEmbeddings.nestedIndicies[levelCount-1];
    const Ordinal &lLevel = last->level ;
    const Ordinal &lIndex = last->index ;
        
    const Ordinal * slIndex = NULL ;
    const Ordinal * slLevel = NULL ;

    if (levelCount > 1) {
        const IndexedLevel * sLast = nestedEmbeddings.nestedIndicies[levelCount-2];
        slLevel = &(sLast->level) ;
        slIndex = &(sLast->index) ;
        
    }





    switch(getInfo()) {
case indexCKlimit:
        assert(indexCK.isLimit());
        if (nestedEmbeddings.isParamRestrict() ) {
            const IndexedLevel& lastLevel=nestedEmbeddings.lastLevelPair();
            assert(lastLevel.level.compare(indexCK)<0);
            const Ordinal& lLevel = lastLevel.level ;
            const Ordinal& lim = * new Ordinal (indexCK.limitOrd(ord));
            const Ordinal& incLm = increasingLimit(lLevel,lim.getImpl());
            /*NHLM*/
            RETURNO("NOA",createVirtualOrdImpl(incLm,Ordinal::zero,
               NULL,Ordinal::zero));
        }
        break ;

case leastIndexLimit:
        {
            const IndexedLevel& lPair = nestedEmbeddings.lastLevelPair();
            assert(lPair.index.isLimit());
            assert(funcParameters==NULL);
            assert(functionLevel.isZero());
            assert(!indexCK.isLimit()) ;
            assert(indexCK.compare(lPair.level)==0);
            const OrdinalImpl* limEleI =
                &(lPair.index.limitOrd(ord).getImpl());
            bool incLim = false ;
            if (levelCount>1) {
                const IndexedLevel*previous=
                nestedEmbeddings.nestedIndicies[levelCount-2];
                const Ordinal &pLevel = previous->level ;
                const Ordinal &pIndex = previous->index ;
                if (incLim = (lPair.level.compare(pLevel)==0)) 
                    limEleI = &(increasingLimit(pIndex,*limEleI).getImpl()) ;
            }
            const Ordinal& limEle = * new Ordinal(*limEleI);
            const NestedEmbeddings& nestEmb =
                nestedEmbeddings.changeLeastIndex(
                    * new Ordinal(lPair.index.limitOrd(ord)));
            // "NJLM":"NILM"
            RETURNO("NOB",createVirtualOrdImpl(
                indexCKo,Ordinal::zero,NULL,drillDown,nestEmb));

        }
case leastLevelLimit:
        {
            const IndexedLevel& lPair = nestedEmbeddings.lastLevelPair();
            assert(lPair.level.isLimit());
            assert(funcParameters==NULL);
            assert(functionLevel.isZero());
            assert(indexCK.compare(lPair.level)==0);
            assert(indexCK.isLimit());
            const Ordinal& limEle = * new Ordinal(indexCK.limitOrd(ord));
            const NestedEmbeddings& nestEmb =
                nestedEmbeddings.changeLeastLevel(limEle);
            // NLVM
            RETURNO("NOC",createVirtualOrdImpl(
                limEle,Ordinal::zero,NULL,drillDown,nestEmb));

        }
case leastLevelLimitParam:
        {

            const OrdinalImpl& le = lLevel.getImpl().limitOrd(ord);
            RETURNO("NOD",limitForLeastLevelLimitParam(le));
        }
case indexCKlimitParamEmbed:
        {
            // NEF
            const OrdinalImpl& le = indexCK.limitOrd(ord);
            RETURNO("NOE",limitForIndexCKlimitParamEmbed(le));
        }
case leastIndexLimitParam:
        {   //NEG
            const OrdinalImpl& le = lIndex.getImpl().limitOrd(ord);
            RETURNO("NOF",limitForLeastIndexLimitParam(le));

        }
case paramLimit:
case paramNxtLimit:
case functionLimit:
case functionNxtLimit:
case drillDownLimit:
case indexCKsuccEmbed:
case indexCKlimitEmbed:
case indexCKlimitParamUn:
    RETURNOX("NOG",AdmisNormalElement::limitOrdCom(ord));
default:
        assert(0);
    }
    assert(0);
}

const CantorNormalElement & NestedEmbedNormalElement::addFactors(
    const CantorNormalElement& toAdd) const
{
    if (codeLevel < nestedEmbedCodeLevel) return
        AdmisNormalElement::addFactors(toAdd);
    return *new NestedEmbedNormalElement(indexCKo,functionLevelO,
        nestedEmbeddings,
        funcParameters,drillDown,factor+toAdd.factor);

}

static int returning(bool dbg, const char *id, int r, 
    const AdmisNormalElement& op1, const CantorNormalElement &op2,
    bool ignoreFactor, const Embeddings& embed, const Embeddings& termEmbed) 

{
     if (!dbg) {
        if (Validate::validationCmpTest)
            outDbgStream() << "Nested le cmp " << id << "\n";
        
        return r ;
    } 

    if (dbg) {
        outDbgStream() << "Nested elt compare returning at " << id <<
            ", val = "
            << r << ", cmp(" << op1.normalForm() << " ::\n" << op2.normalForm()
            << "), ignf = " << ignoreFactor << "\nemb = " <<
            embed.normalForm() << 
            ", trm.emb = " << termEmbed.normalForm() << "\n" ;
    }

    return r;
}

#define RETURN2(id,x) return returning(dbg, id, x, *this, trm, ignoreFactor,\
    embed,termEmbed)

// static int abortFlag = 0 ;

int NestedEmbedNormalElement::compare(const Embeddings& embed,
    const Embeddings& termEmbed, const CantorNormalElement& trm,
    bool ignoreFactor) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    if (dbg) {
        outDbgStream() << "Nested elt compare entry(" <<
            normalForm() << " : " << trm.normalForm() << ", " <<
                ignoreFactor << ")\n"  ;
        DBGO "embed = " << embed.normalForm() << " : " <<
            termEmbed.normalForm() << "\n" ;
    }
    assert(codeLevel >= nestedEmbedCodeLevel) ;

    const Embeddings& effEmbed = effectiveEmbedding(embed);
    const Embeddings& trmEffEmbed = trm.effectiveEmbedding(termEmbed);
    DBGO "parameterCompare calling , trm = " << trm.normalForm() << "\n" ;
    DBGO "this is " << normalForm() << "\n" ;
    int diff = parameterCompare(effEmbed,trmEffEmbed,trm);
    // int diff = parameterCompare(embed,termEmbed,trm);
    if (diff) RETURN2 ("NEA1",diff);
    if (trm.codeLevel >=  admisCodeLevel ) {
        bool termParamRestrict = trmEffEmbed.type == Embeddings::paramRestrict ;
        int embDiff = effEmbed.compare(trmEffEmbed) ;
#define DBGX DBGO
        DBGX "effEmbed = " << effEmbed.normalForm() << "\n" ;
        DBGX "trmEffEmbed = " << trmEffEmbed.normalForm() << "\n" ;
        DBGX "normalForm() = " << normalForm() << "\n" ;
        DBGX "trm = " << trm.normalForm() << ", termEmbed = " <<
            termEmbed.normalForm() << "\n" ;
        DBGX "embDiff = " << embDiff << ", termParamRestrict = " <<
            termParamRestrict << "\n" ;
        if (trm.codeLevel >= admisCodeLevel)
        if (termParamRestrict&&embDiff) RETURN2("NEA2",embDiff);
    } else RETURN2("NEA3",1);

    if (trm.codeLevel > nestedEmbedCodeLevel)
        RETURN2("NEA4", -trm.compare(trmEffEmbed,effEmbed,*this));

    const AdmisNormalElement &ntrm = (const AdmisNormalElement&) trm ;

    const Ordinal& embedIndex = effEmbed.embedIndex ;
    if (trmEffEmbed.type != Embeddings::paramRestrict) {
            bool dd = false ;
            const Ordinal* trmIndexCK = &(ntrm.indexCKo);
            if (!ntrm.drillDown.isZero()){
                 if (!trmIndexCK->isLimit()) 
                    trmIndexCK = new Ordinal(trmIndexCK->subtract(1));
                else dd = true ;
            }
            int diff = trmIndexCK->compare(embedIndex) ;
            int ret = diff >=0 ? -1:1;
            if (dd && diff == 0) ret = 1 ;
            RETURN2("NECA",ret);
    }

   
    RETURN2 ("NECZ",AdmisNormalElement::compareCom(embed,termEmbed,trm,
        ignoreFactor));
}
        
const OrdinalImpl & NestedEmbedNormalElement::createVirtualOrdImpl(
    const Ordinal & ix, const Ordinal & lev,
    const Ordinal * const * const params, const Ordinal& drillDownParams,
    const Embeddings& embed) const
{
    assert(embed.embedLevel >= NestedEmbeddings::nestedEmbedLevel);
    const NestedEmbeddings&nembed = (const NestedEmbeddings&) embed;
    return nestedEmbedFunctional(ix,lev,nembed,params,drillDownParams).getImpl();
}

const Ordinal & NestedEmbedNormalElement::createVirtualOrd(const Ordinal & ix,
    const Ordinal & lev, const Ordinal * const * const params,
    const Ordinal& drillDownParams, const Embeddings& embed) const
{
    assert(embed.embedLevel >= NestedEmbeddings::nestedEmbedLevel);
    const NestedEmbeddings&nembed = (const NestedEmbeddings&) embed;
    return nestedEmbedFunctional(ix,lev,nembed,params,drillDownParams);
}


        
const OrdinalImpl & NestedEmbedNormalElement::createVirtualOrdImpl(
    const Ordinal & ix, const Ordinal & lev,
    const Ordinal * const * const params, const Ordinal& drillDownParams)const
{
    return nestedEmbedFunctional(ix,lev,nestedEmbeddings,
        params,drillDownParams).getImpl();
}

const Ordinal & NestedEmbedNormalElement::createVirtualOrd(const Ordinal & ix,
    const Ordinal & lev, const Ordinal * const * const params,
    const Ordinal& drillDownParams) const
{
    return nestedEmbedFunctional(ix,lev,nestedEmbeddings,params,drillDownParams);
}

const OrdinalImpl & NestedEmbedNormalElement::createVirtualOrdImpl(
    const Ordinal & lev, const Ordinal * const * const params) const
{
    return nestedEmbedFunctional(indexCKo,lev,nestedEmbeddings,
        params,drillDown).getImpl();

}

const Ordinal & NestedEmbedNormalElement::createVirtualOrd(const Ordinal & lev,
	const Ordinal * const * const params) const
{
    return nestedEmbedFunctional(indexCKo,lev,nestedEmbeddings,
        params,drillDown);
}



const OrdinalImpl & NestedEmbedNormalElement::createVirtualOrdImpl(
	const Ordinal * const * const params) const
{
    return nestedEmbedFunctional(indexCKo,functionLevelO,nestedEmbeddings,
        params,drillDown).getImpl();
}

const Ordinal & NestedEmbedNormalElement::createVirtualOrd(
	const Ordinal * const * const params) const
{

    return nestedEmbedFunctional(indexCKo,functionLevelO,nestedEmbeddings,
        params,drillDown);
}
    

const NormalFormTerm& NestedEmbedOrdinalImpl::createTerms(
    const Ordinal& indexCK,
	const Ordinal& iter, const Ordinal* const * const params,
    const NestedEmbeddings& embed,
	const Ordinal& drillDown, Int factor)
{
    const NestedEmbedNormalElement& elt =
        * new NestedEmbedNormalElement(indexCK, iter, embed,params,drillDown,
            factor) ;
    return * new NormalFormTerm(elt) ;



}
        

string NestedEmbedOrdinalImpl::makeName(const Ordinal& ixCK,
    const Ordinal& iter, const Ordinal* const * const params,
    const Ordinal& drillDown, const NestedEmbeddings& embed)
{
    // assert(embed.type == Embeddings::paramRestrict) ;
    assert((embed.nestedIndicies[0] != NULL) && (
       (embed.nestedIndicies[1] != NULL) || 
       (!embed.nestedIndicies[0]->index.isZero())));
    string base = embed.normalFormString ;
    /*
    string base = "" ;
    base += "[[" ;
    bool first = true ;
    for (const IndexedLevel * const * ix = embed.nestedIndicies ;
        *ix != NULL; ix++) {
        if (first) first = false ; else base += ", " ;
        const IndexedLevel& ixLev =   **ix ;
        assert(!ixLev.level.isZero());
        base += ixLev.level.normalForm();
        if (!ixLev.index.isZero()) {
            base += "/" ;
            base += ixLev.index.normalForm();
        }
    }
    base += "]]" ;
    */
    return AdmisLevOrdinalImpl::makeNameCom(base,ixCK,iter,params,drillDown,
        embed);

}

string NestedEmbedOrdinalImpl::makeTexName(const Ordinal& ixCK,
    const Ordinal& iter, const Ordinal* const * const params,
    const Ordinal& drillDown, const NestedEmbeddings& embed)
{
    // assert(embed.type == Embeddings::paramRestrict) ;
    assert((embed.nestedIndicies[0] != NULL) && (
       (embed.nestedIndicies[1] != NULL) || 
       (!embed.nestedIndicies[0]->index.isZero())));
    string base = "" ;
    base += "[[" ;
    bool first = true ;
    for (const IndexedLevel * const * ix = embed.nestedIndicies ;
        *ix != NULL; ix++) {
        if (first) first = false ; else base += ", " ;
        const IndexedLevel& ixLev =   **ix ;
        assert(!ixLev.level.isZero());
        base += ixLev.level.texNormalForm();
        if (!ixLev.index.isZero()) {
            base += "\\lmoustache{}" ;
            base += ixLev.index.texNormalForm();
        }
    }
    base += "]]" ;
    return AdmisLevOrdinalImpl::makeTexNameCom(base,ixCK,iter,params,
        drillDown, embed);


}

static void fixReturn(const char * id, bool bl, const Ordinal* ord)
{
    outStream() << "Nested fpr ret " << bl ;
    if (bl) {
        assert(ord && ! ord->isZero()) ;
        outStream() << " with value " << ord->normalForm() ;
    }
    outStream() << " at " << id << "\n" ;
}

#define FRETURN(id,bl,ord) {if (dbg) fixReturn(id,bl,ord); return bl;}

bool NestedEmbedOrdinal::fixedPoint(const OrdinalImpl& levCK,
    const Ordinal& iter, int maxIndex, const Ordinal* const * const params,
    const NestedEmbeddings& embedIn, const Ordinal *& ret)
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::ctrOrd) ;

    // FRETURN("PHONY",false,ret);
    const Ordinal * tret = NULL ;
    if ((maxIndex!=FiniteFuncOrdinal::maxIndexPosUndefined)) {
        if (maxIndex> -1) {
            tret = params[maxIndex];
        } else if (maxIndex == AdmisLevOrdinal::iterMaxParam) {
            tret = &iter ;
        } else assert(0);
        if (dbg) outStream() << "FP tret = " << tret->normalForm() << 
            ", maxIndex = " << maxIndex << "\n" ;
        if (tret->psuedoCodeLevel() < AdmisNormalElement::admisCodeLevel) 
            FRETURN("NPFP",false,ret);
        if (maxIndex> -1) {
            int size = 0 ;
            for (;params[size];size++);
            for (int i = size-1; i> maxIndex;i--)
                if (!params[i]->isZero())
                    FRETURN("NFPP",false,ret);
            const Ordinal** nParams = new const Ordinal *[size+1] ;
            nParams[size]=0;
            assert(maxIndex<size);
            for (int i = 0 ; i < maxIndex;i++) nParams[i] = params[i] ;
            for (int i = maxIndex ; i < size ; i++)
                nParams[i] = &(Ordinal::zero) ;
            if ((new NestedEmbedOrdinal(levCK,iter,embedIn,nParams))->
                compare(embedIn,embedIn,*tret)>=0)
                    FRETURN("NFG",false,ret);
        } else if (maxIndex == AdmisLevOrdinal::iterMaxParam) {
            if (params && params[0]) FRETURN("NFPI",false,ret);
            if ((new NestedEmbedOrdinal(levCK,Ordinal::zero, embedIn,NULL))->
                compare(embedIn,embedIn,*tret)>=0) FRETURN("NFC",false,tret);
        } else assert(0);

        const CantorNormalElement * firstTerm = tret->getImpl().getFirstTerm();
        int codeLev = firstTerm->codeLevel ;
        assert(codeLev >= AdmisNormalElement::admisCodeLevel);
        assert(codeLev <= NestedEmbedNormalElement::nestedEmbedCodeLevel);
        assert(tret->getImpl().getTerms()->next == NULL);
        const Embeddings& firstTermEmbed = firstTerm->getEmbed();
        assert(!firstTermEmbed.isParamRestrict() ||
            (embedIn.embedIndex.compare(firstTermEmbed.embedIndex) >= 0));
        if (!firstTermEmbed.isParamRestrict() ||
            embedIn.compare(firstTermEmbed)>0) {
            const NestedEmbedNormalElement& aFt =
                (const NestedEmbedNormalElement&) * firstTerm ;
             tret = new NestedEmbedOrdinal(aFt.indexCKo,
                    aFt.functionLevelO,embedIn,
                aFt.funcParameters,aFt.drillDown);
                if (dbg) outStream() << "tret = " <<tret->normalForm()<<"\n" ;
        }

        //const Ordinal& eRet = * new NestedEmbedOrdinal(
        ret = tret ;
        FRETURN("NADFP",true,ret);
    }
    FRETURN("NFPF",false,ret);
    /*
    const int levelCount = embedIn.levelCount ;
    const Ordinal& lastIndex = embedIn.nestedIndicies[levelCount-1]->index ;
    if ((maxIndex==FiniteFuncOrdinal::maxIndexPosUndefined) &&
        lastIndex.isLimit()) {
        // check for index fixed point (only can occur at least sig index
        if (!lastIndex.getTerms()->next &&
            (lastIndex.getFirstTerm()->factor==1)) {
            const NestedEmbeddings& checkEmbed =
                embedIn.changeLeastIndex(Ordinal::zero);
            const Ordinal& checkOrd = * new NestedEmbedOrdinal(levCK,
                Ordinal::zero,embedIn,NULL,Ordinal::zero);
            if (checkOrd.getImpl().compare(checkEmbed,checkEmbed,
                lastIndex.getImpl()) < 0) {
                ret = &lastIndex ;
                
                FRETURN("NLVFP",true,ret.checkAddEmbedding(checkEmbed));
            }
        }
    }
    FRETURN("NF",false,ret);
    */
}

/*
static void tabNestedBaseLimEle()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedBaseimitEltExitCodeTestNames(labOrds);

    string tname = "tabNestedBaseLimitExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 2 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,
        "TabNestedLimEltCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<< "\\caption{\\MIndextt{" <<
     "NestedEmbedNormalElement::LimitElement} examples}\n" ;
    outStream << "\\mindex{{\\tt LimitElement} examples\n" <<
        "\\tt NestedEmbedNormalElement}\n";
    outStream << "\\label{TabBaseNestedLeExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();
}
*/

static void tabNestedParamLimEle()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedParamLimitEltExitCodeTestNames(labOrds);

    string tname = "tabNestedParamLimitExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 2 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,
        "TabNestedEmbedParamLimEltCases","\\footnotesize");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\Index\n" <<
        "{{\\tt NestedEmbedNormalElement::paramLimitElement} examples}}\n" ;

    outStream << "\\mindex{{\\tt paramLimitElement} examples}\n";
    outStream << "\\label{TabParamNestedLeExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();
}


static void tabNestedLimEle()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedLimitEltExitCodeTestNames(labOrds);


    string tname = "tabNestedDdLimitExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 2 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,
        "TabNestedLimEltCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\MIndextt{NestedEmbedNormalElement::limitElement}"
    << " examples}\n" ;

    outStream <<
        "\\mindex{{\\tt NestedEmbedNormalElement::limitElement}"
        << " examples}\n" ;
    outStream <<
        "\\mindex{examples, {\\tt NestedEmbedOrdinal::limitElement}}\n" ;
    outStream << "\\label{TabDdNestedLeExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();


}

static void tabNestedLimOrd()
{
    string tname = "tabNestedLimitOrdExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{table}\n\\centering\n" ;
    outStream << "\\begin{tabular}{|l|l|l|l|r|}\\hline\n" ;
    int tCol = 5 ;
    outStream << "\\multicolumn{" << tCol << "}{|c|}\n";
    outStream << "{{\\bf X} is an exit code (see Table~\\ref" <<
        "{TabNestedLimOrdCases}).\n" <<
        "{\\bf upX} is a higher level exit code from a calling routine.}" <<
        "\\\\\\hline\n" ;
    outStream << "{\\bf X} & {\\bf UpX} & $\\alpha$ & " <<
        "$\\beta$ &{\\tt $\\alpha$.limitOrd($\\beta$)}\\\\\\hline\\hline\n" ;

    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedEmbedLimitOrdExitCodeTestNames(labOrds);

     for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) 
        if ((*iter)->theAct & LabeledOrdinal::output) {
            outStream << "\\lecrf{" <<
                LabeledOrdinal::texName((*iter)->name)  << "} &" ;
            if ((*iter)->subName != NULL) outStream <<  "\\lecrf{" <<
                LabeledOrdinal::texName((*iter)->subName) << "}"  ;
            const Ordinal & base  = (*iter)->ord;
            const Ordinal & arg = (*iter)->ordp ;
            outStream << "&$" << base.texNormalForm() ;
            outStream << "$&$" << arg.texNormalForm() ;
            outStream << "$&$" << base.limitOrd(arg).texNormalForm() ;
            outStream << "$\\\\\\hline\n" ;
    }
    outStream << "\\end{tabular}\n" ;

    outStream<<
     "\\caption{\\MIndextt{NestedEmbedNormalElement::limitOrd}"
    << " examples}\n" ;

    outStream <<
        "\\mindex{{\\tt NestedEmbedNormalElement::limitOrd}"
        << " examples}\n" ;
    outStream <<
        "\\mindex{examples, {\\tt NestedEmbedOrdinal::limitOrd}}\n" ;
    outStream << "\\label{TabNestedLimOrdExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();





}

static void tabTransitionLimit()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::transitionTestNames(labOrds);


    string tname = "tabTransitionLimitExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    int nCol = 2 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,
        "TabNestedLimEltCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\MIndextt{NestedEmbedNormalElement transitions}}\n" ;

    outStream << "\\label{TabDdNestedTransitionExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();


}



static void tabNestedLimEleEq()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedDdLimitEltEqExitCodeTestNames(labOrds);


    string tname = "tabNestedDdLimitEqExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    int nCol = 2 ;
    Ordinal::beginLimitEltTable(outStream,nCol,
        "TabNestedDrillDownLimEltEqCases");

    Ordinal::tabNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\MIndextt{NestedEmbedNormalElement::drillDownLimitElementEq}"
    << " examples}\n" ;

    outStream <<
        "\\mindex{{\\tt NestedEmbedNormalElement::drillDownLimitElementEq}"
        << " examples}\n" ;
    outStream <<
        "\\mindex{examples, {\\tt NestedEmbedOrdinal::drillDownLimitElementEq}}\n" ;
    outStream << "\\label{TabDdNestedDdLeEqExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();


}

static void tabNestedLimEleEmbed()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::nestedEmbedLimitEltExitCodeTestNames(labOrds);


    string tname = "tabNestedEmbedLimitExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    int nCol = 2 ;
    Ordinal::beginLimitEltTable(outStream,nCol,
        "TabNestedEmbedLimEltCases");

    Ordinal::tabNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\MIndextt{NestedEmbedNormalElement::embedLimitElement}"
    << " examples}\n" ;

    outStream <<
        "\\mindex{{\\tt NestedEmbedNormalElement::embedLimitElement}"
        << " examples}\n" ;
    outStream <<
        "\\mindex{examples, {\\tt NestedEmbedOrdinal::enbedLimitElement}}\n" ;
    outStream << "\\label{TabDdNestedEmbedLeExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();


}





static void typeNestedLimitEle()
{
    const Int indicies[] = {1,2,3,-1};
    
    const Ordinal expI=(admisLevelFunctional(one,one)^(admisLevelFunctional(one,one)+1));

    const Ordinal & omega1CKp1 = omega1CK+1 ;
    const Ordinal & o1ckt4 = omega1CK*4 ;
    const Ordinal & o1cksq = omega1CK*omega1CK ;
    const Ordinal & bg1 = admisLevelFunctional(eps0,omega);
    const Ordinal & off1 = omega1CK*omega ;
    const Ordinal & sum1 = bg1 + off1 ;
    const Ordinal & w1xw = omega1CK*omega ;
    const Ordinal & w1x2 = omega1CK*Ordinal::two ;
    const Ordinal & w2dd = admisLevelFunctional(Ordinal::two,zero,NULL,
        omega1CK);
    const Ordinal & wxx = admisLevelFunctional(Ordinal::two,zero,NULL,
        w2dd);
    const Ordinal* ordAry [] = {
        
        
        &admisLevelFunctional(omega,zero),
        &omega1CK,
        &finiteFunctional(omega1CK,one,zero,zero),
        &finiteFunctional(createParameters(&omega1CKp1,&one)),
        &admisLevelFunctional(one,zero,NULL,Ordinal::one),
        &admisLevelFunctional(one,zero,NULL,Ordinal::two),
        &admisLevelFunctional(one,zero,NULL,Ordinal::omega),
        &admisLevelFunctional(Ordinal::two,zero,NULL,omega1CK),
        & w2dd,
        & wxx ,
        &o1ckt4,
        &o1cksq,
        &admisLevelFunctional(one,zero,createParameters(&one)),
        
        
        &admisLevelFunctional(one,zero,createParameters(&one,&one)),
        
        &admisLevelFunctional(one,zero,createParameters(&one,&zero,&one)),
        
        &admisLevelFunctional(one,zero,createParameters(&one,&one,&zero)),
        
         &admisLevelFunctional(one,zero,createParameters(&eps0, &zero)),
         
         
         
         &admisLevelFunctional(one,zero,createParameters(&eps0, &one, &zero)),
         
         
         &admisLevelFunctional(one,zero,createParameters(&eps0, &one)),
        0
    };
/*
    Ordinal::limitElementTable(ordAry,indicies,"NestedLevOrdinal",
        1,"\\small");
    Ordinal::limitTypeTable(ordAry,"NestedLevOrdinal", 1,NULL);
*/
}




static void tabNestedInterExamp()
{
    string tname = "tabNestedInterpExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{comment}\n" ;
    outStream << "\\end{comment}\n" ;
    outStream << "\\begin{table}\n\\centering\n" ;

    // source file src/ord_calc/nestedTab.ord
    /************** BEGIN tabList output **************/
 outStream << "\\begin{tabular}{|l|l|}\\hline\n" << 
	"{\\bf Interpreter code }&{\\bf Ordinal notation}\\\\ \\hline\\hline\n";
	outStream << "{\\tt [[1, 2]]w\\_\\{ 2\\}} & $[[1, 2]]{\\omega_{2}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1/1]]w\\_\\{ 1\\}} & $[[1\\lmoustache{}1]]{\\omega_{1}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1/1]]w\\_\\{ 1\\}[ 5]} & $[[1\\lmoustache{}1]]{\\omega_{1}}[5]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1/1]]w\\_\\{ 1\\}[[ 12]]} & $[[1\\lmoustache{}1]]{\\omega_{1}}[[12]]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 1/1]]w\\_\\{ 1\\}[ 1]} & $[[1, 1\\lmoustache{}1]]{\\omega_{1}}[1]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, w]]w\\_\\{ w\\}} & $[[1, \\omega{}]]{\\omega_{\\omega{}}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2/1]]w\\_\\{ 2\\}} & $[[1, 2\\lmoustache{}1]]{\\omega_{2}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2/w]]w\\_\\{ 2\\}} & $[[1, 2\\lmoustache{}\\omega{}]]{\\omega_{2}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2/w]]w\\_\\{ w\\}} & $[[1, 2\\lmoustache{}\\omega{}]]{\\omega_{\\omega{}}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[3, 12]]w\\_\\{ w\\}} & $[[3, 12]]{\\omega_{\\omega{}}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1/1, 1/2]]w\\_\\{ 1\\}} & $[[1\\lmoustache{}1, 1\\lmoustache{}2]]{\\omega_{1}}$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2]]w\\_\\{ 2\\}[ 1]} & $[[1, 2]]{\\omega_{2}}[1]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2]]w\\_\\{ 2\\}[[ 8]]} & $[[1, 2]]{\\omega_{2}}[[8]]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 1/1]]w\\_\\{ 1\\}[ 31]} & $[[1, 1\\lmoustache{}1]]{\\omega_{1}}[31]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[2, 2/1]]w\\_\\{ 20\\}[ 1]} & $[[2, 2\\lmoustache{}1]]{\\omega_{20}}[1]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2, 3, 4/1]]w\\_\\{ 4\\}[ 1]} & $[[1, 2, 3, 4\\lmoustache{}1]]{\\omega_{4}}[1]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[w + 1/1]]w\\_\\{ w + 1\\}[ 1]} & $[[\\omega{} + 1\\lmoustache{}1]]{\\omega_{\\omega{} + 1}}[1]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[1, 2, 2/5, w + 1]]w\\_\\{ w + 12\\}[ 1]} & $[[1, 2, 2\\lmoustache{}5, \\omega{} + 1]]{\\omega_{\\omega{} + 12}}[1]$ \\\\ \\hline\n" ;
	outStream << "{\\tt [[w + 1, w + 1/1]]w\\_\\{ w + 1\\}[ 1]} & $[[\\omega{} + 1, \\omega{} + 1\\lmoustache{}1]]{\\omega_{\\omega{} + 1}}[1]$ \\\\ \\hline\n" ;
	outStream << "\\end{tabular}\n" ;

    /************** END tabList output **************/

    outStream<<"\\caption{{\\tt NestedEmbedOrdinal} interpreter code examples}\n";
    outStream << "\\mindex{{\\tt NestedEmbedOrdinal} interpreter code examples}\n" ;
    outStream <<
        "\\mindex{examples, {\\tt NestedEmbedOrdinal} interpreter code}\n" ;
    outStream << "\\label{TabNestedLevOrdinalIntExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();


}

/*
static void tabNestedDefinition()
{
    string tname = "tabNestedDefinition" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{table}\n\\centering\n" ;
    outStream << "\\begin{tabular}{|l|l|l|l|r|}\\hline\n" ;


}
*/

void NestedEmbedOrdinal::texDocument()
{
  //  tabNestedDefinition();
    tabNestedInterExamp();
    tabNestedLimEle();
    // tabNestedBaseLimEle();
    tabNestedParamLimEle() ;
    tabNestedLimEleEq();
    tabNestedLimEleEmbed();
    tabNestedLimOrd();
    typeNestedLimitEle();
    tabTransitionLimit();

    CantorNormalElement::createInfoTableType(
        NestedEmbedNormalElement::nestedEmbedCodeLevel,
            "\\footnotesize",true);
    CantorNormalElement::createInfoTableExampList(
        NestedEmbedNormalElement::nestedEmbedCodeLevel,"\\scriptsize",true);
    // CantorNormalElement::createInfoTableExamp(
        // NestedEmbedNormalElement::nestedEmbedCodeLevel,"\\footnotesize",true);
    CantorNormalElement::createInfoTableOrdExamp(
        NestedEmbedNormalElement::nestedEmbedCodeLevel,
            "\\footnotesize");


}

