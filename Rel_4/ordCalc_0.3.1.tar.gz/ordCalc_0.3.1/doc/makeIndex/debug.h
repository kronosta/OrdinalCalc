/*
 *  debug.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  debug.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef DEBUG_DOT_H
#define DEBUG_DOT_H
#include "dbgcode.h"

#include "errcode.h"
void DbgError(const char * Routine, const char *ErrorType, const char *Class=0);
static const char * NotInString = "not yet implemented" ;
inline void NotYetIn(char * r) {DbgError(r, NotInString) ; }

#define DoNotChangeDbgError DbgError

void DbgCode(int Code);

#if USE_DBG_ERROR_STRINGS
#define DebugCodeError(a,b,c,d) DbgError(b,c,d) 
#else 
#define  DebugCodeError(a,b,c,d) DbgCode(a) 
#endif

#endif /* #ifdef DEBUG_DOT_H */
