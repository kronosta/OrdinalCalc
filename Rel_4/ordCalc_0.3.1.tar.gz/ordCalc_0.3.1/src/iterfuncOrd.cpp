#include "stdafx.h"


#include <fstream>


#include "admisOrd.h"
#include "validate.h"
#include "validDoc.h"

using namespace std;
using namespace ord;




IterFuncNormalElement::IterFuncParameters::IterFuncParameters(
	const Ordinal& iter, const Ordinal * const * const params,
    const Embeddings& embed, int level):functionLevel(iter),
        FiniteFuncParameters(params,embed,level)
{
	if (codeLevel <= iterFuncCodeLevel) 
		if (iter.isZero()) if (size < 2)
			if (codeLevel == iterFuncCodeLevel) codeLevel = cantorCodeLevel ;
	else codeLevel = finiteFuncCodeLevel;
	assert(maxParameter);
	maxParameter = (iter.getImpl().compare(embeddings,embeddings,
        maxParameter->getImpl())>0)?
		 &iter : maxParameter;

    const Ordinal& iterMaxEmbed = iter.getMaxEmbedIndex();
    if (maxEmbedIndex->compare(iterMaxEmbed) <0) maxEmbedIndex = &iterMaxEmbed;
	
}

void IterFuncNormalElement::iterFuncDebug(const char * where) const
{

}

IterFuncNormalElement::IterFuncNormalElement(const Ordinal& iter,
	const Ordinal* const * const params, Int fac, int level):
	FiniteFuncNormalElement(new IterFuncParameters(iter,params,
    Embeddings::embedNone,level),fac),
	functionLevel(iter.getImpl()),
	functionLevelO(iter)
{
    iterFuncDebug("IA");
}

IterFuncNormalElement::IterFuncNormalElement(const IterFuncParameters* prma,
	Int fac):FiniteFuncNormalElement(prma,fac),
	functionLevel(prma->functionLevel.getImpl()),
	functionLevelO(prma->functionLevel)
{
    iterFuncDebug("IB");
}

void IterFuncNormalElement::normalFormName(string& base) const 
{
	if (codeLevel < iterFuncCodeLevel) return
		FiniteFuncNormalElement::normalFormName(base);
	bool useFactor = factor > 1 ;
	if (useFactor) base += "(" ;
	base += IterFuncOrdinalImpl::makeName(functionLevel, funcParameters);
	if (useFactor) {
		base += "*" ;
		base += OrdinalImpl::itoa(factor) ;
		base += ")" ;
	}


}


void IterFuncNormalElement::psiNormalFormKernel(string& str) const
{
    const Ordinal& virtualLimit = classLimit();
    if (!virtualLimit.isZero()) if (functionLevel.compare(virtualLimit)>=0)
    {
        str = notBasic();
        return ;
    }
    bool expSum = size > 1 ;
    if (!functionLevel.isZero()) {
        if (expSum) str += "(\\Omega^{" ;
        else str += "\\Omega^{" ;
        const Ordinal & ord = Ordinal::omega*functionLevelO ;
        str += ord.psiNormalForm();
        str += "}" ;
    } 
    if (size>0) {
        const Ordinal ** params = new const Ordinal * [size+2] ;
        params[size+1]=NULL ;
        params[0]=&Ordinal::one;
        for (int i =1; i < size+1; i++) params[i] = &Ordinal::zero;
        if (createVirtualOrdImpl(params).compare(*(funcParameters[0]))>0) {
            params[size] = NULL ;
            bool badFlag = false ;
            for (int i = 0 ; i < size -1 ;i++) {
                if (!funcParameters[i+1]->isFinite()) {
                    params[i]=new Ordinal(*(funcParameters[i])+Ordinal::one) ;
                    if (finiteFunctional(params).compare(*(funcParameters[i+1]))
                        <=0) {
                          badFlag = true ;
                          break ;
                    }
                }
                params[i]=funcParameters[i] ;
            }
            if (badFlag) {
                str = notBasic();
                return ;
            } else {
                for (int i = 0 ; i < size; i++) { 
                    const Ordinal &f = *(funcParameters[i]) ;
                    int exp = size - i - 1  ;
                    bool fz = f.isZero() ;
                    if (!fz) {
                        if ((i == 0) && expSum) str += " (" ;
                        if (i > 0) str += " + " ;
                        if (exp > 0) str += "\\Omega" ;
                        if (exp > 1) {
                            str += "^" ;
                            str += OrdinalImpl::itoa(exp) ;
                        }
                        str+= " " ;
                        if (!f.isOne() || (exp==0))
                             str += f.psiNormalForm();
                    }
                }
                if (expSum) {
                    str += ")" ;
                    if (!functionLevel.isZero()) str += ")" ;
                }

            }
            delete params ;
            params = NULL ;
                
        } else {
            str = notBasic();
            return ;
        }

    }
    
}

void IterFuncNormalElement::psiNormalForm(string& str) const
{
	bool useFactor = factor > 1 ;
	if (useFactor) str += "(" ;
    str += "\\Psi(\\Omega^{" ;
    psiNormalFormKernel(str);
    if (isNotBasic(str)) return ;
    str += "})" ;
    if (useFactor) {
		str += " " ;
		str += OrdinalImpl::itoa(factor) ;
		str += ")" ;
	}


}

void IterFuncNormalElement::texNormalForm(string& str) const 
{
	if (codeLevel < iterFuncCodeLevel) {
		FiniteFuncNormalElement::texNormalForm(str);
		return ;
	}
	bool useFactor = factor > 1 ;
	if (useFactor) str += "(" ;
	str += IterFuncOrdinalImpl::makeTexName(functionLevel,funcParameters);
	if (useFactor) {
		str += " " ;
		str += OrdinalImpl::itoa(factor) ;
		str += ")" ;
	}

}

string& IterFuncNormalElement::cppNormalForm(const string& name,
    string& ret) const
{
    const int maxParam = 4 ;
    if ((factor==1) && (size <= maxParam)) {
        ret += "iterativeFunctional(\n\t\t" ;
        functionLevelO.cppNormalForm(name,ret) ;
        for (int i = 0 ; i < size ; i++) {
            ret += ",\n\t\t" ;
            funcParameters[i]->cppNormalForm(name,ret) ;
        }
        ret += ")" ;
        return ret;
    }
    if (size <= ord::maxCreaParam) {
        ret += "iterativeFunctional(\n\t\t" ;
        functionLevelO.cppNormalForm(name,ret) ;
        ret += ",\n\t\tcreateParameters(\n\t\t\t&(";
        for (int i = 0 ; i < size ; i++) {
            if (i > 0)ret += "),\n\t\t\t&(" ;
            funcParameters[i]->cppNormalForm(name,ret) ;
        }
        ret += "),\n\t\t\tNULL)" ;
        if (factor > 1) {
            ret += ", " ;
            ret += factor.get_str();
        }
        ret+= "\n\t\t)" ;
        return ret;

    }
    ret += "iterativeFunctional(\n\t\t" ;
    functionLevelO.cppNormalForm(name,ret);
    ret += ",\n\t\t" ;
    cppParamNormalForm(name,ret);
    if (factor > 1) {
         ret += ", " ;
         ret += factor.get_str();
    }   
    ret += ")" ;
    return ret ;
}





const CantorNormalElement& IterFuncNormalElement::getCopy(const Int fac) const
{
	if (codeLevel < iterFuncCodeLevel)
		return FiniteFuncNormalElement::getCopy(fac);
	assert(codeLevel == iterFuncCodeLevel);
	return *new IterFuncNormalElement(functionLevelO,funcParameters,fac);

}


static const OrdinalImpl& returningOrd(bool dbg, const char *id,
    const OrdinalImpl& r, const OrdinalImpl& ord,
    const IterFuncNormalElement& elt, bool saveFlag = false)
{
    if (saveFlag) {
        LastReturnCode::lastLimitOrdCode.codeLevel =
            AdmisNormalElement::admisCodeLevel;
        LastReturnCode::lastLimitOrdCode.exitCode = id ;
    } else {
        LastReturnCode::lastLimitOrdCode.setExit2(id,
            AdmisNormalElement::admisCodeLevel);
    }
    if (dbg) outDbgStream() << "FiniteFunc limitOrd returning at " << id <<
        ", val = " << r.normalForm() << ", " << ord.normalForm() <<
        " limit of " << elt.normalForm() << "\n" ;
    else if(Validate::validationTest) outDbgStream()
        << "FiniteFunc lo ex " << id << "\n";
    return r;
}

#define RETURNO(id,x) return returningOrd(dbg, id, addFactorPart(x),ord,\
    *this, true)

#define RETURNOX(id,x) return returningOrd(dbg, id, x, ord, *this)



const OrdinalImpl& IterFuncNormalElement::limitOrdCom(
    const OrdinalImpl & ord) const 
{
	bool dbg = OrdinalImpl::debugControl.check(
        DebugControlParam::limit,0) ;
	
	if (dbg) outStream() << "IterFunc entering for " <<
		normalForm() << ".limitOrd(" << ord.normalForm() << ")\n" ;
    assert(isValidLimitOrdParam(ord));

    switch (getLimitInfo()) {
case paramLimit:
case paramNxtLimit:         
        RETURNOX("FOA",FiniteFuncNormalElement::limitOrdCom(ord));
case functionLimit:
case functionNxtLimit:
        {
            const Ordinal& lim = * new Ordinal(functionLevel.limitOrd(ord).
                limPlus_1());
            DBGO "ord = " << ord.normalForm() << ", lim = " <<
                lim.normalForm() << "\n" ;

/* case */  if (theLimitTypeInfo == functionLimit) 
                RETURNO("FOB", createVirtualOrdImpl(lim, funcParameters));

/* case */  assert((theLimitTypeInfo == functionNxtLimit));

            const Ordinal& paramMo = * new Ordinal(funcParameters[0]->getImpl().
                subtract(1));
            const Ordinal& base = * new Ordinal(replace1(0,paramMo));

            RETURNO("FOC",createVirtualOrdImpl(lim,createParameters(
                &(base.limPlus_1()),NULL)));
        }
default:
        assert(0);
    }
    assert(0);
}

const OrdinalImpl& IterFuncNormalElement::limitOrd(
    const OrdinalImpl & ord) const 
{
	bool dbg = OrdinalImpl::debugControl.
        check(DebugControlParam::limit,0) ;
	RETURNOX("FOD",limitOrdCom(ord));
}




static const OrdinalImpl& returning1(bool dbg, const char *id,
	const OrdinalImpl& r,
	const Int& n, const IterFuncNormalElement& elt, bool saveFlag=false)
{
	const OrdinalImpl * ret = &r ;
    if (saveFlag) {
        LastReturnCode::lastLimitCode.codeLevel =
            IterFuncNormalElement::iterFuncCodeLevel;
        LastReturnCode::lastLimitCode.exitCode = id ;
    } else LastReturnCode::lastLimitCode.setExit2(id,
        IterFuncNormalElement::iterFuncCodeLevel);
	
	if (!dbg) {
		
		return *ret ;
	}
	outDbgStream() << "IterFunc -le limit returning at "
        << id << ", val = " << ret->normalForm() << ", " << n
        << " limit of " << elt.normalForm() << "\n" ;
	return *ret ;
}


#define RETURN1(id,x) return returning1(dbg, id, addFactorPart(x), n, *this, \
    true)

#define RETURN1X(id,x) return returning1(dbg, id, x, n, *this)




const OrdinalImpl& IterFuncNormalElement::limitElement(Int n) const
{
	assert(n>0);
	assert(!functionLevel.isZero()) ;
	bool dbg = OrdinalImpl::debugControl.
        check(DebugControlParam::limit,0) ;
	
	if (dbg) outStream() << "Entering IterFunc " <<
		normalForm() << ".limitElement(" << n << ") if\n" ;

	if (codeLevel < iterFuncCodeLevel) return
		FiniteFuncNormalElement::limitElement(n);
	assert(codeLevel == iterFuncCodeLevel);
	return limitElementCom(n);
}

const OrdinalImpl& IterFuncNormalElement::limitElementCom(Int n)
    const 
{
	bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
	
	
	assert(n>0);
	assert(funcParameters || !size);

	int leastNz = size-1;
	if (funcParameters) while ((leastNz >= 0) &&
		funcParameters[leastNz]->isZero()) leastNz--;


    switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
case drillDownLimit:     
case drillDownSucc:
case drillDownSuccEmbed:
case drillDownOne:
case drillDownOneEmbed:
        assert(0);
case paramSucc:          
case paramSuccZero:          
case paramsSucc:          
case paramLimit:         
case paramNxtLimit:
        RETURN1X("IF", FiniteFuncNormalElement::limitElementCom(n)) ;
case functionSucc:
        {
            const Ordinal & funcLevMo =
		        * new Ordinal(functionLevel.subtract(1));
		    const Ordinal * base = NULL ;
		
		    base = &(createVirtualOrd(funcLevMo).limPlus_1());
		    int nint ;
		    const Ordinal** params = createParamArray(n,nint);
		    params[0] = base ;
		
		    RETURN1("IG",createVirtualOrdImpl(funcLevMo,params));
        }
case functionNxtSucc:
        {
            const Ordinal& leastNzOrd = *(funcParameters[0]) ;
            const Ordinal*const* param = NULL ;
            if (!leastNzOrd.isOne()) {
                Ordinal& leastNzMo =
                    * new Ordinal(leastNzOrd.getImpl().subtract(1));

                param=createParameters(&leastNzMo);
            }
            const Ordinal * base = &(createVirtualOrd(functionLevelO,param).
                limPlus_1());
            if (n>1) {
                int nint ;
                if (dbg) outStream() << "createParamArray(" << n << "...)\n" ;
		        const Ordinal** params = createParamArray(n,nint);
		        params[0] = base ;
                const Ordinal& funcLevMo = * new Ordinal(functionLevel.subtract(1));
		        if (dbg) outStream() << funcLevMo.normalForm() << " funcLevMo\n" ;
                base = &(createVirtualOrd(funcLevMo,params));
            }
		    // RETURN1("II",createVirtualOrdImpl(funcLevMo,params));
            RETURN1("II",base->getImpl());
        }
case functionLimit:
        RETURN1("IJ", createVirtualOrdImpl(
			* new Ordinal(functionLevel.limitElement(n).limPlus_1())));
case functionNxtLimit:
        {
	        const Ordinal& leastNzOrd = *(funcParameters[leastNz]) ;
            Ordinal& leastNzMo =
                * new Ordinal(leastNzOrd.getImpl().subtract(1));
            const Ordinal& tmp = 
                *new Ordinal(createVirtualOrdImpl(functionLevelO,
                createParameters(&leastNzMo)).limPlus_1());
            DBGO "tmp = " << tmp.normalForm() << "\n" ;
            const OrdinalImpl& fl = functionLevel.limitElement(n).limPlus_1();
            DBGO "fl = " << fl.normalForm() << "\n" ;
            const Ordinal& ofl = * new Ordinal(fl);
            const OrdinalImpl& ret = createVirtualOrdImpl(ofl,
                createParameters(&tmp));
            RETURN1("IK",ret);

        }
        break;
case indexCKlimit:       
case indexCKsuccParam:
case indexCKsuccEmbed: 
case indexCKlimitEmbed:
        assert(0);
    }
    assert(0);
}


const OrdinalImpl & IterFuncNormalElement::createVirtualOrdImpl(
	const Ordinal & lev, const Ordinal * const * const params) const 
{
	return iterativeFunctional(lev,params).getImpl();
}


const Ordinal & IterFuncNormalElement::createVirtualOrd(const Ordinal & lev,
			const Ordinal * const * const params) const 
{
	return iterativeFunctional(lev,params);
}

const OrdinalImpl & IterFuncNormalElement::createVirtualOrdImpl(
			const Ordinal * const * const params) const 
{
	return iterativeFunctional(functionLevelO,params).getImpl();
}


const Ordinal & IterFuncNormalElement::createVirtualOrd(
			const Ordinal * const * const params) const 
{
	return iterativeFunctional(functionLevelO,params);
}




const CantorNormalElement & IterFuncNormalElement::addFactors(
	const CantorNormalElement& toAdd) const 
{
	if (codeLevel < iterFuncCodeLevel) return
		FiniteFuncNormalElement::addFactors(toAdd);
	return * new IterFuncNormalElement(functionLevelO,
		funcParameters,factor+toAdd.factor);
}


static int returning(bool dbg, const char *id, int r, 
	const IterFuncNormalElement& op1, const CantorNormalElement &op2,
	bool ignoreFactor) 

{
	if (!dbg) return r ;
	outDbgStream() << "IterFunc elt compare returning at " << id <<
		", val = "  << r <<
		", cmp(" << op1.normalForm() << " ::\n" << op2.normalForm() <<
		"), ignf = " << ignoreFactor <<  "\n" ;
	return r;
}

#define RETURN2(id,x) return returning(dbg, id, x, *this, trm,  ignoreFactor)




int IterFuncNormalElement::compare(const CantorNormalElement& trm,
	bool ignoreFactor ) const 
{
    if (trm.codeLevel >=AdmisNormalElement::admisCodeLevel)
        return -trm.compare(*this,ignoreFactor);

    return compare(Embeddings::embedNone,Embeddings::embedNone,trm,ignoreFactor);
}



int IterFuncNormalElement::compare(const Embeddings& context,
    const Embeddings& paramContext, const CantorNormalElement& trm,
	bool ignoreFactor ) const
{
	bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
	
	if (dbg) {
		outDbgStream() << "IterFunc elt compare(" <<  normalForm() << ", " 
			<< trm.normalForm() << ")\n" ;
	}
    if (trm.codeLevel > iterFuncCodeLevel) RETURN2("A1", -trm.compare(
        paramContext,context,*this,ignoreFactor));


	if (codeLevel < iterFuncCodeLevel)
		RETURN2("IA",FiniteFuncNormalElement::compare(context,paramContext,
            trm, ignoreFactor));
	
	assert(codeLevel == iterFuncCodeLevel) ;
	assert(trm.codeLevel <= iterFuncCodeLevel) ;

	if (trm.codeLevel < iterFuncCodeLevel) { 
		if (dbg) outStream() << trm.getMaxParameter().normalForm() <<
			"  " << trm.normalForm() <<  "  " << normalForm() <<
			" mxc from trm this\n";
		const OrdinalImpl&  trmMaxComp = trm.getMaxParameter();
		
		if (!trmMaxComp.isZero()) {
			const CantorNormalElement * firstTerm = trmMaxComp.getFirstTerm();
			if (firstTerm) if (compare(context,paramContext,*firstTerm,true) <=0)
                RETURN2("A3", -1) ;
		}
		RETURN2("A4",1); 
	}
	assert(trm.codeLevel == iterFuncCodeLevel);
    int diff = parameterCompare(context,paramContext,trm);
    if (diff) RETURN2("A5",diff);
	const IterFuncNormalElement& ftrm = (const IterFuncNormalElement&) trm;
   	diff = functionLevel.compare(context,paramContext,ftrm.functionLevel) ;
	if (diff) RETURN2("A6",diff);

	diff = compareFiniteParams(context,paramContext,ftrm);
	if (diff) RETURN2("IR",diff);
	int factDiff = 0 ;
	if (!ignoreFactor) factDiff = cmp(factor,ftrm.factor) ;
	RETURN2("IS", factDiff) ;

}

static int returning3(bool dbg, const char * id, int v,
	const IterFuncNormalElement &th, const OrdinalImpl& ord)
{
	if (!dbg) return v ;
	outDbgStream() << "IterFuncn -b compareOrd at " << id << ", returning " << v <<
		", cmp(" << th.normalForm() << "::\n" << ord.normalForm() << ")\n";
	return v ;
}

#define RETURN3(id,x) return returning3(dbg,id,x,*this,ord)






const OrdinalImpl* IterFuncNormalElement::limitInfoCommon(
	CantorNormalElement::LimitTypeInfo& typeInfo) const
{
    typeInfo = unknownLimit;
    
    const OrdinalImpl * type =
        FiniteFuncNormalElement::limitInfoCommon(typeInfo) ;
    // if ((size==0) && functionLevel.isZero()) return NULL ;
    // const OrdinalImpl * type = NULL ;
   	// if (size>1) {
		// type = FiniteFuncNormalElement::limitInfoCommon(typeInfo) ;
		// assert(typeInfo != unknownLimit);
    if (type==NULL) 
	    if (functionLevel.isLimit()) {
		    type = &(functionLevel.limitType());
            if (size==0) typeInfo = functionLimit ;
            else typeInfo = functionNxtLimit ;
	// }  else if (!functionLevel.isZero()){
	}  else if (functionLevel.isSuccessor()) {
		type = &integerLimitType ;
        if (size==0) typeInfo = functionSucc ;
        else if (size==1) typeInfo = functionNxtSucc ;
        else (assert(0));
	}
    return type  ;
}


const OrdinalImpl& IterFuncNormalElement::limitInfo(
	CantorNormalElement::LimitTypeInfo& typeInfo) const 
{
	assert(!theLimitType) ;
	assert(size || !functionLevel.isZero()) ;
	typeInfo = unknownLimit;
	const OrdinalImpl * type = limitInfoCommon(typeInfo) ;
    if (type == NULL) {
        assert(!functionLevel.isZero());
        type = &integerLimitType ;
		typeInfo = functionSucc ;
    }
    assert((typeInfo !=  unknownLimit) & (type != NULL));
    return setLimitType(typeInfo,type);
    /*
	IterFuncNormalElement * setThis = (IterFuncNormalElement *)this;
	setThis->theLimitType = type ;
	setThis->theLimitTypeInfo = typeInfo ;
	return *theLimitType ;
	*/

}
/*
const OrdinalImpl& IterFuncNormalElement::limitType() const
{
	if (theLimitType) return * theLimitType ;
	LimitTypeInfo typeInfo = unknownLimit;
	return limitInfo(typeInfo) ;
	
}
*/
/*
const OrdinalImpl& IterFuncNormalElement::maxLimitType() const
{
    return IterFuncNormalElement::maxLimitType(Ordinal::zero);
}
*/
const OrdinalImpl& IterFuncNormalElement::maxLimitType() const
{
    
    /* if (embIx.isZero()) */ if (theMaxLimitType) return *theMaxLimitType ;
    const OrdinalImpl * type = NULL ;
    if (size) type = &(FiniteFuncNormalElement::maxLimitType(/* embIx*/));
    if (!functionLevel.isZero()) {
        const OrdinalImpl& flt = functionLevel.maxLimitType(/*embIx*/);
        if (!type || (flt.compare(*type)>0)) type = &flt;
    }
    /* if (embIx.isZero()) { */
        // ((CantorNormalElement *)this)->theMaxLimitType = type ;
        return // *theMaxLimitType ;
            setMaxLimitType(type);
   /* }
    type = &(AdmisNormalElement::boundedLimitType( embIx,*type));
    return *type ;
    */
}


const NormalFormTerm& IterFuncOrdinalImpl::createTerms(const Ordinal& iter,
			const Ordinal* const * const params,Int factor)  
{
	const IterFuncNormalElement& elt = * new IterFuncNormalElement(iter,
		params,factor) ;
	return * new NormalFormTerm(elt) ;

}

string IterFuncOrdinalImpl::makeName(const Ordinal& iter,
			const Ordinal* const * const params)  
{
	if (iter.isZero()) return FiniteFuncOrdinalImpl::makeName(params);
	int count = 0 ;
	if (params) for (;params[count];count++) ;

	string base = "psi_{ " ;
	base += iter.normalForm() ;
	base += "}" ;
	if (count) {
		base += "(" ;
		for (int i = 0 ; i < count; i++) {
			if (i) base += ", " ;
			base += params[i]->normalForm() ;
		}
		base += ")" ;
	}
	return base ;

}

string IterFuncOrdinalImpl::makeTexName(const Ordinal& iter,
			const Ordinal* const * const params)  
{
	if (iter.isZero()) return FiniteFuncOrdinalImpl::makeTexName(params);
	int count = 0 ;
	if (params) for (;params[count];count++) ;

	string base = "\\varphi_{" ;
	base += iter.texNormalForm() ;
	base += "}" ;
	if (count) {
		base += "(" ;
		for (int i = 0 ; i < count; i++) {
			if (i) base += ", " ;
			base += params[i]->texNormalForm() ;
		}
		base += ")" ;
	}
	return base ;

	
}

bool IterFuncOrdinal::fixedPoint(const Ordinal& iter, int ix,
			const Ordinal* const * const params, const Embeddings& embedIn)
{
	
	if (iter.isZero()) {
		if ((ix == iterMaxParam) || !params) return false ;
		return FiniteFuncOrdinal::fixedPoint(ix,params,embedIn);
	}
	if (ix==iterMaxParam ) return iter.psuedoCodeLevel() >
		IterFuncNormalElement::iterFuncCodeLevel ;
	int paramsPcl = params[ix]->getImpl().psuedoCodeLevel() ;
	if (paramsPcl != IterFuncNormalElement::iterFuncCodeLevel)
		return paramsPcl > IterFuncNormalElement::iterFuncCodeLevel ;

	if (ix == 0) return IterFuncOrdinal(iter).compare(embedIn,
        embedIn, *params[0]) < 0;
	int size = 0 ;
	for (;params[size];size++);
	const Ordinal** nParams = new const Ordinal *[size+1] ;
	nParams[size]=0;
	assert(ix<size);
	for (int i = 0 ; i < ix;i++) nParams[i] = params[i] ;
	for (int i = ix ; i < size ; i++) nParams[i] = &zero ;
	return  IterFuncOrdinal(iter,nParams).compare(embedIn,embedIn,
        *(params[ix])) < 0;


}

static void iterFuncExamp()
{
	string tname = "tabiterfuncCppExamp" ;
	string fname = tname;
	fname += ".tex" ;
	ofstream outStream(fname.c_str());
	OutStream::streamManager.push(outStream);

#define CPP_EXAMP(str) outStream << "{\\tt " << "\\verb#" << #str <<"#" \
	<< "}&$" << (str).texNormalForm()  << "$\\\\  \n"

#define cp createParameters	

	outStream << "\\begin{table}\\centering\n" ;
	outStream << "\\begin{tabular}{|l|l|}\\hline\n" ;

	outStream << "\\multicolumn{2}{|c|}{\\bf `{\\tt cp}' stands for function" <<
		" {\\tt createParameters}}\\\\ \\hline \n" ;
	outStream << "{\\bf \\Cpp{} code} &{\\bf Ordinal}\\\\ \\hline \n" ;
	CPP_EXAMP(iterativeFunctional(zero,cp(&one)));
	CPP_EXAMP(iterativeFunctional(zero,cp(&one,&zero)));
	CPP_EXAMP(iterativeFunctional(zero,cp(&one,&one,&zero)));
	CPP_EXAMP(iterativeFunctional(one));
	CPP_EXAMP(iterativeFunctional(one,cp(&one)));
	CPP_EXAMP(iterativeFunctional(one,cp(&one,&omega)));
	CPP_EXAMP(iterativeFunctional(one,cp(&one,&omega,&zero,&zero)));
	CPP_EXAMP(iterativeFunctional(omega,cp(&one,&omega,&zero,&zero)));
	CPP_EXAMP(iterativeFunctional(omega));
	CPP_EXAMP(iterativeFunctional(one,cp(&iterativeFunctional(omega))));

	outStream << "\\hline\n" ;
	outStream << "\\end{tabular}\n" ;
	outStream<<"\\caption{{\\tt iterativeFunctional} \\Cpp{} code examples}\n";
    outStream << "\\mindex{{\\tt iterativeFunctional} C{\\tt ++} examples}\n" ;
    outStream <<
        "\\mindex{examples {\\tt iterativeFunctional} C{\\tt ++} code}\n" ;

	outStream << "\\label{TabIterFuncOrdinalCppExamp}\n" ;
	outStream << "\\end{table}\n\n" ;

	OutStream::streamManager.pop();
#undef cp
#undef CPP_EXAMP
}


static void iterArithExamp()
{
	const char * cName = "IterFuncOrdinal" ;
        const Ordinal &iter1  = iterativeFunctional(one);
        const Ordinal &iter2  = iterativeFunctional(Ordinal::three) ;
        const Ordinal &iter3  =
            iterativeFunctional(Ordinal::three,createParameters(&one,&zero,&zero));
        const Ordinal &iter4  = iterativeFunctional(one,createParameters(&omega,&one)) ;
        const Ordinal &iter5  =
            iterativeFunctional(one,createParameters(&omega,&one,&zero)) + iter1 ;
        const Ordinal &iter6  = iterativeFunctional(eps0) + iter5 ;
	const Ordinal * const am[] = {
		&iter1,
		&iter2,
		&iter3,
		&iter4,
		&iter5,
		&iter6,


		NULL
	};

	Ordinal::arithExamp(am,cName,Ordinal::multType);

	const Ordinal * const * bm = am ;

	Ordinal::arithExamp(bm,cName,Ordinal::powerType);

}



static const Ordinal ** getIterativeExamples()
{

     //ifc = psi_{ w}(1, 0)
	const Ordinal& ifc = iterativeFunctional(
		expFunctional(Ordinal::one),
		Ordinal::one,
		Ordinal::zero)	;

    // NM2_LIM_ELT_TST(FB,IF,ifc);


	//if_1 = psi_{ 12}(w, 0)
	const Ordinal& if_1 = iterativeFunctional(
		(*new Ordinal(12)),
		expFunctional(Ordinal::one),
		Ordinal::zero)	;

    // NM2_LIM_ELT_TST(FL,IF_1,if_1);

	//ig = psi_{ 1}
	const Ordinal& ig = iterativeFunctional(
		Ordinal::one)	;
    // NM_LIM_ELT_TST(IG,ig);


	//ig_1 = psi_{ w + 1}
	const Ordinal& ig_1 = iterativeFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))))	;
    // NM_LIM_ELT_TST(IG_1,ig_1);


	//ii = psi_{ w + 1}(1)
	const Ordinal& ii = iterativeFunctional(
		( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::one)	;
    // NM_LIM_ELT_TST(II,ii);


	//ii_1 = psi_{ 1}(1)
	const Ordinal& ii_1 = iterativeFunctional(
		Ordinal::one,
		Ordinal::one)	;
    // NM_LIM_ELT_TST(II_1,ii_1);


	//ij = psi_{ w}
	const Ordinal& ij = iterativeFunctional(
		expFunctional(Ordinal::one))	;
    // NM_LIM_ELT_TST(IJ,ij);


	//ik = psi_{ w}(1)
	const Ordinal& ik = iterativeFunctional(
		expFunctional(Ordinal::one),
		Ordinal::one)	;
    // NM_LIM_ELT_TST(IK,ik);




    static const Ordinal* ordAry [] = {
        &ifc,
		&iterativeFunctional(one,createParameters(&one,&zero,&zero)),
		&iterativeFunctional(Ordinal::three,createParameters(&one,&zero,&zero)),
		&iterativeFunctional(one,createParameters(&omega,&one,&zero)),
        &iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&one,&zero)),
		&iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&eps0,&one,&one)),
        &if_1,
        &iterativeFunctional(one,createParameters(&eps0)),
		&iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&eps0)),
		&iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&eps0,&zero)),
		&iterativeFunctional(one,createParameters(&omega,&one)),
		&iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&eps0,&one)),
		


        &ig,
        &ig_1,
		&iterativeFunctional(Ordinal::two),
		&iterativeFunctional(Ordinal::three),

        &ii_1,
		&iterativeFunctional(one,createParameters(&Ordinal::two)),
		&iterativeFunctional(Ordinal::two,createParameters(&Ordinal::four)),
        &ii,

        &ij,
		&iterativeFunctional(eps0),
		&iterativeFunctional(gamma0,NULL),
		&iterativeFunctional(finiteFunctional(Ordinal::three,zero,zero)),
        
        &ik,
		&iterativeFunctional(eps0,createParameters(&Ordinal::five)),
		&iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&one)),
		0
	};

    return ordAry ;
}



void LabeledOrdinal::iterFuncLimitElementComExitCodeTestNames(
    list<LabeledOrdinal*>& labOrds)
//static void appendOrdinals(list<LabeledOrdinal*>& labOrds)
{
    const Ordinal ** ords= getIterativeExamples();


    for (const Ordinal ** ord = ords; *ord; ord++)
        labOrds.push_back (new LabeledOrdinal("DIM",**ord,NULL,Ordinal::zero, 
            (LabeledOrdinal::Act)
            (LabeledOrdinal::setNames|LabeledOrdinal::output))) ;

    const Ordinal & ifx = iterativeFunctional(finiteFunctional(one,zero,zero),
			createParameters(&eps0,&one,&one,&Ordinal::two));

#define NM2_LIM_ELT_TST_skd(name,sname,ordinal) labOrds.push_back \
    (new LabeledOrdinal(#name,ordinal,#sname,Ordinal::zero, \
    LabeledOrdinal::testOnly))

     NM2_LIM_ELT_TST_skd(FD,IF,ifx);
#undef NM2_LIM_ELT_TST_skd
}

static void iterFuncLimitEltComExitTab()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::iterFuncLimitElementComExitCodeTestNames(labOrds);
 //   appendOrdinals(labOrds);

    string tname = "tabIterFuncLimitEltComExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 3 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,
        "TabIterFuncLimEltComCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
    outStream<<
     "\\caption{\\Index{{\\tt IterFuncNormalElement::limitElementCom}" <<
        " exit codes}}\n";
    outStream << "\\label{TabIterFuncLimtEltComExitCodes}\n" ;
     // outStream <<
     // "\\mindex{exit codes {\\tt IterFuncNormalElement::limitElementCom}}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}




void IterFuncOrdinal::texDocument()
{


    iterFuncLimitEltComExitTab();
	iterFuncExamp();

	iterArithExamp();

	
	// const Int indicies[] = {1,2,3,-1};
	
    // const Ordinal** ordAry = getIterativeExamples();
	
	// limitElementTable(ordAry,indicies,"IterFuncOrdinal");


}
