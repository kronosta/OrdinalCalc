/*
 *  texutil.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  texutil.h   */
/*  Copyright 1991 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef TEXUTIL_DOT_H
#define TEXUTIL_DOT_H
#include <ostream>
using namespace std;

class OutTokens ;
OutTokens& VSpace(OutTokens& Out);
void LitFillOut(const char *, ostream *) ;
void LitFillConcat(const char *, ostream *) ;
void LitFillQuoteConcat(const char *, ostream *) ;
void LitQuoteOut(const char *, ostream *) ;

const char * GetTeXSectionName(int index) ;
int MaxTeXSectionDepth();

const int MaxTeXLengthToIndex = 40 ;
void ConditionalTeXIndex(OutTokens& Out, const char * String) ;
int IsTeXEscapable(char Check)  ;
int IsTeXSpecial(char Check)  ;
int TeXstrcmp(const char * a, const char * b) ;
int TeXchrcmp(char a, char b) ;

#endif /* #ifdef TEXUTIL_DOT_H */
