    latex $1.tex
	latex $1.tex
	./tth $1.tex
    rm $1.pdf
    mv $1.html htdocs/axioms
    perl htdocs/useHeaders.pl htdocs/axioms/$1.html
    perl htdocs/useHeaders.pl htdocs/axioms/$1.html
    perl htdocs/useHeaders.pl htdocs/axioms/$1.html

