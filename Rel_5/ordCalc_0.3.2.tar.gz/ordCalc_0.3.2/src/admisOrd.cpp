#include "stdafx.h"


#include <fstream>

#include "admisOrd.h"
#include "validate.h"
#include "validDoc.h"

using namespace std;
using namespace ord;

#define TDB  outStream() <<__FILE__ << __LINE__ << " : " <<



static const Ordinal * const * const ckDd(const Ordinal * const * const dd)
{
    if ((dd !=  NULL) && (*dd != NULL) && !dd[0]->isZero()) return dd;
    return NULL;
}

void breakPointEmbed()
{
}


AdmisNormalElement::AdmisLevParameters::AdmisLevParameters(
    const Ordinal& ixCK, const Ordinal& iter,
    const Ordinal * const * const params, const Ordinal& dd,
    const Embeddings& embed, int level):indexCK(ixCK),drillDown(dd),
    embeddings(embed),
    IterFuncParameters(iter,params,embed,level),leastSigParam(NULL)
{
    breakPointEmbed();
    if (maxEmbedIndex->compare(ixCK.getMaxEmbedIndex())<0)
        maxEmbedIndex = &(ixCK.getMaxEmbedIndex());
    if (embed.type == Embeddings::paramRestrict) {
        const Ordinal& ix = embed.embedIndex ;
        assert(!ix.isZero()) ;
        assert(ix.compare(*maxEmbedIndex)>=0);
        maxEmbedIndex = &ix ;
        
        
    }
    if (parameters) for (int sz = size -1; sz > -1; sz--) {
        if (!parameters[sz]->isZero()) {
            leastSigParam = &(parameters[sz]->getImpl()) ;
            break ;
        }
    }
    if (!leastSigParam) if (!functionLevel.isZero()) leastSigParam =
        &(functionLevel.getImpl()) ;
    if (!leastSigParam) leastSigParam = &(indexCK.getImpl()) ;
    if (maxParameter->getImpl().compare(
        embed.embedClass(),embed.embedClass(),indexCK.getImpl())<0)
            maxParameter  = &indexCK;
    
    if (!drillDown.isZero()) if (maxParameter->getImpl().compare(
        embed.embedClass(),embed.embedClass(),drillDown.getImpl())<0)
            maxParameter  = &drillDown;
    if (codeLevel > admisCodeLevel)  return ;
    assert(!indexCK.isZero());

}




const AdmisNormalElement& AdmisNormalElement::createAdmissibleBase() const
{
    if (!size && functionLevel.isZero() && drillDown.isZero()) return *this ;
    ((AdmisNormalElement *)this)->admissibleBase =
        new AdmisLevOrdinal(indexCKo,Ordinal::zero) ;
    const CantorNormalElement * firstTerm =
        admissibleBase->getImpl().getFirstTerm();
    assert(firstTerm);
    assert(firstTerm->codeLevel == admisCodeLevel);
    return *(const AdmisNormalElement *) firstTerm ;
}

const AdmisLevOrdinalImpl& AdmisNormalElement::getAdmissibleBaseImpl() const 
{
    return (AdmisLevOrdinalImpl&) getAdmissibleBase().getImpl();
}

const AdmisLevOrdinal& AdmisNormalElement::getAdmissibleBase() const 
{
    
    if (!admissibleBase) ((AdmisNormalElement *)this)->admissibleBase =
         (AdmisLevOrdinal*) new Ordinal(*new OrdinalImpl (admissibleBaseElement));
    return *  admissibleBase ;
}

AdmisNormalElement::AdmisNormalElement(const Ordinal& ixCK,
    const Ordinal& iter,
	const Ordinal* const * const params, 
	const Ordinal& dd, const Embeddings& embed, Int fac):
    indexCK(ixCK.getImpl()),
    indexCKmo(ixCK.isSuccessor()?ixCK.getImpl().subtract(1):ixCK.getImpl()),
    indexCKo(ixCK),
    drillDown(dd),
    entryCount(0),
    embeddings(embed),
    indexCKeq(embed.leastLevelEq(ixCK)),
    ixMone(indexCK.isSuccessor()?indexCK.subtract(1):indexCK),
    IterFuncNormalElement(new AdmisLevParameters(ixCK,iter,params,
        dd,embed,admisCodeLevel), fac),
        leastSigParam(*(((AdmisLevParameters*)parameters)->leastSigParam)),
         admissibleBase(NULL),
         admissibleBaseElement(createAdmissibleBase())
         
            
    
{
    iterFuncDebug("C");
    assert(validAdmisNormalElementInt());
}


AdmisNormalElement::AdmisNormalElement(const AdmisLevParameters* params,
    Int fac): indexCK(params->indexCK.getImpl()),
    indexCKo(params->indexCK),
    indexCKmo(params->indexCK.isSuccessor()?
        params->indexCK.getImpl().subtract(1):params->indexCK.getImpl()),
    drillDown(params->drillDown),
    IterFuncNormalElement(params,fac),
    leastSigParam(*(params->leastSigParam)),
    indexCKeq(params->embeddings.leastLevelEq(params->indexCK)),
    embeddings(params->embeddings),
    ixMone(indexCK.isSuccessor()?indexCK.subtract(1):indexCK),
    admissibleBase(NULL),
    entryCount(0),
    admissibleBaseElement(createAdmissibleBase())
   
{
    iterFuncDebug("D");
    assert(validAdmisNormalElementInt());
}



bool AdmisNormalElement::validAdmisNormalElementInt() const
{
    assert(codeLevel >= admisCodeLevel);
    if ((codeLevel == admisCodeLevel) &&
        (embeddings.embedLevel != Embeddings::baseEmbedLevel)) assert(0);
    return validAdmisNormalElement(indexCKo,functionLevelO,
        funcParameters,drillDown,embeddings,codeLevel);
}


static void errorBreak(ostream& out, int sz)
{
    if (documentMode) assert(0);
    out << "ERROR: in defining '[[delta]]omega_{indexCK}(" << sz <<
            " parameter" << ((sz==1) ? ")" : "s)") ;

}


bool AdmisNormalElement::validAdmisNormalElement(const Ordinal& inx,
    const Ordinal& iter, const Ordinal * const * const params,
    const Ordinal& dd, const Embeddings& embed, int codeLevel)
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::ctrOrd) ;
    if (dbg) outStream() << "Checking (" << inx.normalForm() << ", " <<
        iter.normalForm() << ",params ," << dd.normalForm() <<
        ", " << embed.normalForm() << "\n" ;
    const OrdinalImpl& embedIx = embed.embedIndex.getImpl() ;
    struct Errs {int flag; const char *err;} errors[] = {
        {1,"[[Index]] prefix must be <= indexCK"},
        {2,"indexCK must be a successor with drill down"},
        {4,"functionLevel must be 0 with drill down"},
        {8,"no parameters allowed with drill down"},
        // {0x10,"internal error: inconcistent embedLevel"},
        {0x20,"internal error: indexCK is zero"},
        {0x40,"drillDown parameter is too large"},
        {0x80,"embedIndex must be >= all internal instances of embedIndex"},
        {0x100,"With [[index]] indexCK must be > 0"},
        {0x200,"[[d]] prefix with d a limit is not allowed"},
        // {0x200,"if indexCK is a limit all smaller parameters must be 0"},
        // {0x200,"[[Index]] must be <= affected internal indeCK's"}, 
        // {0x400,"in x[y] x.limitType > y.maxLimitType required"},
        // {0x800,"indexCK must be >= drillDown parameter limitType"},
        // {0x1000,"[[prefix]] limitType must not be < drillDown maxLimitType"},
        // {0x4000," [drillDown] too large"},
        // {0x8000,"[[]] prefix not valid with [] suffix and delta == kappa"},
        {0,0}
    };
    int err = 0 ;

    int sz=0;
    if (params) for (;params[sz];sz++) ;
    bool checkEmbed = true ;
    // if (inx.isLimit()) if ((sz>0) || !iter.isZero()) err|=0x200;

    const Ordinal * maxEmbedIx = &Ordinal::zero ;
    if (embedIx.isZero()) {
        assert(embed.type != Embeddings::paramRestrict);
        checkEmbed = false ;
    }
    if (embed.isParamRestrict() && embedIx.isLimit()) err |= 0x200;
    // outStream() << "codeLevel = " << codeLevel << "\n" ;
        //if (checkEmbed) {
        // if (embed.embedLevel==Embeddings::baseEmbedLevel) {

            // if (assert(isValidLimitOrdParam(ord)) 
            // int diff = dd.maxLimitType().compare(embed.getLimitTypeEquiv());
            /*
            int diff = dd.maxLimitType().
                compare(OrdinalImpl::indexCKlimitType(inx));
            if (diff >=0) err|= 0x40;
            if (diff ==0) {
                const CantorNormalElement * first = dd.getImpl().getFirstTerm();
                assert(first);
                if (first->codeLevel >= admisCodeLevel) {
                    const AdmisNormalElement& aFirst =
                        (const AdmisNormalElement&) *first ;
                    if (dd.isLimit() && aFirst.drillDown.isZero()) err |= 0x40 ;
                }
            } 
        }*/
        for (int i =0;i<sz;i++) {
            const Ordinal& ord = params[i]->getMaxEmbedIndex();
            if (ord.compare(*maxEmbedIx)>0) maxEmbedIx = &ord ;
        }
        const Ordinal &iord = iter.getMaxEmbedIndex();
        if (iord.compare(*maxEmbedIx)>0) maxEmbedIx = &iord ;
        const Ordinal &xord = inx.getMaxEmbedIndex();
        if (xord.compare(*maxEmbedIx)>0) maxEmbedIx = &xord ;
        if (inx.compare(embedIx)<0) {
            err|= 0x1 ;
        }
        if (!embedIx.isZero() &&
            (embedIx.compare(*maxEmbedIx)<0)) err |= 0x80 ;
        if (inx.isZero()) err|=0x100 ;
       
    if (!dd.isZero()){
        const OrdinalImpl* inxTst = &(inx.getImpl());
        if (inxTst->isFinite()) inxTst = &(inxTst->addLoc(OrdinalImpl::one));
        // if (dd.limitType().compare(*inxTst)>=0) err|=0x800;
    }
        
    if (dbg) outStream() << inx.normalForm() << " = inx, " <<
         dd.normalForm() << " = dd, " << sz <<
        " = sz, " << iter.normalForm() << " = iter, " <<
        embedIx.normalForm() << " = embIx\n" ;
    if (inx.isZero()) err |= 0x20;
    if (!dd.isZero()) {
        if (!iter.isZero()) err|=0x4 ;
        if (sz) err|= 8 ;
        if (inx.isLimit()) err|=0x2 ;
        const CantorNormalElement *ddft = dd.getImpl().getFirstTerm();
        /*
        int compare = -1;
        if (ddft) compare = ddft->maxLimitType().compare(
               inx.getImpl().indexCKlimitType());
        if (embedIx.isZero()) {
              if (ddft) {
                if (compare >= 0) err|=0x40 ;
                    

                if (dbg) outStream() << "maxCK: " << 
                    ddft->maxLimitType().normalForm() << " mx::ixLim " <<
                    inx.getImpl().indexCKlimitType().normalForm() << "\n" ;
            }
        if (ddft) {
            int ddftcl = ddft->codeLevel;
            if (ddftcl == AdmisNormalElement::admisCodeLevel) {
                const AdmisNormalElement& dda = (const AdmisNormalElement&)
                    *ddft ;
                
                if ((compare==0) && (dda.drillDown !=NULL) &&
                    ((!embedIx.isZero()) ||
                    (!dda.embeddings.embedIndex.isZero()))) err|=0x100 ;
                if (compare >= 0) err|=0x40 ;
            }
        }
        }
        */
        if (!err) if (!dd.isZero() && (codeLevel == admisCodeLevel)) {
        const Ordinal& test = admisLevelFunctional(inx,Ordinal::zero,
            NULL,Ordinal::zero,embed);
        //if (embed.isDrillDownEmbed()) {
            if (!test.getImpl().isValidLimitOrdParam(dd.getImpl())) err|=0x40 ;
        //} else {
        //    if (!test.getImpl().isValidLimitOrdParam(dd.getImpl())) err|=0x40 ;
        //}
     }

    }
    if (err) {
        errorBreak(outStream(),sz);
        if (!dd.isZero()) if (embed.isDrillDownEmbed())
            outStream() << "[[" << dd.normalForm() << "]]" ;
        else outStream() << "[" << dd.normalForm() << "]" ;
        outStream() << "':" ;
        bool out = false ;
        for (Errs * er = errors; er->flag;er++) {
            if (er->flag & err) {
                if (out) outStream() << "\nand " ;
                else outStream() << "\n" ;
                outStream() << er->err ;
                out = true ;
            }
        }
         outStream() << ".\n" ;
         outStream().flush();
        return false ;
    }
    return true ;
}

const OrdinalImpl& AdmisNormalElement::typeIndexCKemb(const OrdinalImpl& ixCK)
{
    if (ixCK.isZero()) return nullLimitType ;
    const OrdinalImpl * ret = &ixCK ;
    if (!ret->isFinite() && ret->isSuccessor())
        ret = &(ret->subtract(1));
    return *ret ;
}

const OrdinalImpl& AdmisNormalElement::typeIndexCK(const OrdinalImpl& ixCK)
{
    if (ixCK.isZero()) return nullLimitType ;
    const OrdinalImpl * ret = &ixCK ;
    if (ret->isFinite()) ret = &(ret->addLoc(integerLimitType));
    return *ret ;
}


const OrdinalImpl& AdmisNormalElement::typeIndexCK() const
{
    return typeIndexCK(indexCK) ;
}

static const Ordinal *const * const copyParameters(
    const Ordinal * const * const in)
{
    if (!in) return NULL ;
    int sz = 0 ;
    while(in[sz++]);
    const Ordinal ** out = new const Ordinal *[sz+1] ;
    for (int i = 0 ; i < sz+1;i++) out[i]=in[i] ;
    return out;
}

const AdmisNormalElement& AdmisNormalElement::addEmbeddings(
    const Embeddings& emb, const Ordinal&dd) const 
{
    assert(embeddings.type == Embeddings::none);
    const Ordinal* ddAdd = &dd;
    if (!drillDown.isZero()) ddAdd = &drillDown ;
    return * new AdmisNormalElement(indexCKo,functionLevelO,
        copyParameters(funcParameters),*ddAdd,emb) ;
}



const OrdinalImpl& AdmisNormalElement::boundedLimitType(
    const Ordinal& bound, const OrdinalImpl&type, const Ordinal& dd)
{
    if (bound.isZero()) return type ;
    const OrdinalImpl * ret = &type ;
    const OrdinalImpl * cmpBound = &(bound.getImpl()) ;
    if (bound.isFinite()) cmpBound = &(bound.getImpl().addLoc(1));
    if (!dd.isZero()) {
        assert(!cmpBound->isLimit()) ;
        cmpBound = &(cmpBound->subtract(1)) ;
    }
    if (cmpBound->compare(type)<0) ret = cmpBound ;
    return *ret ;
}


const OrdinalImpl& AdmisNormalElement::maxLimitType() const
{
    if (theMaxLimitType) return *theMaxLimitType ;
    const Ordinal *embedIx = &(Ordinal::zero);
    const Ordinal& delta = embeddings.type==Embeddings::paramRestrict?
        embeddings.embedIndex : Ordinal::zero ;


    const OrdinalImpl * type = NULL ;
    if (size || !functionLevel.isZero()) type =
        &(IterFuncNormalElement::maxLimitType(/* *embedIx*/));

    assert(!indexCK.isZero());
    const OrdinalImpl * ixType = &(typeIndexCK());
    if (!embedIx->isZero())
        if (ixType->compare(*embedIx)>0) ixType = &(embedIx->getImpl()) ;
    bool fromKappa = true ;
    if (!type) type = ixType,fromKappa=true ; else
           if (type->compare(*ixType) < 0) type = ixType,fromKappa=true ;
    /*
    assert(type) ;
    if (!embeddings.embedIndex.isZero()) {
        if (embeddings.embedIndex.isFinite()) {
            if (type->compare(embeddings.embedIndex)<=0) type =
                &(embeddings.embedIndex.getImpl().addLoc(1));
        } else if (type->compare(embeddings.embedIndex)<0)
            type = &(embeddings.embedIndex.getImpl()) ;
    }
    */
        
    if ((!drillDown.isZero()&&fromKappa) || ((embedIx != NULL) &&
        !embedIx->isZero() &&type->isSuccessor())) {
        type = &(type->subtract(1));
    }
    
    // type = &(deltaRestrict(*type,drillDown.isZero()));

    if (embeddings.isParamRestrict() && !embeddings.embedIndex.isZero()) {
		const  OrdinalImpl* embt =
			new const OrdinalImpl( embeddings.baseLimitTypeEquivDD.getImpl());
        // const OrdinalImpl& embLimitType =
        //    embeddings.baseLimitTypeEquivDD.getImpl() ;
		if (!drillDown.isZero() && !embt->isLimit())  embt=&(embt->subtract(1));
        //if (embLimitType.compare(*type)<0) {
        //     type = &embLimitType;
        // }
        if (embt->compare(*type)<0) {
             type = embt;
         }
    }
    // ((AdmisNormalElement *)this)->theMaxLimitType = type ;
    setMaxLimitType(type);
    return *theMaxLimitType ;
}



const OrdinalImpl& AdmisNormalElement::getCompareIndexCK(
    const Embeddings *emb) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    if (dbg) outStream() << normalForm() << " emb.embedIndex = " <<
           embeddings.embedIndex.normalForm() << "\n" ;     


    const OrdinalImpl * embIx = &OrdinalImpl::zero ;
    if (emb) embIx = &(emb->embedIndex.getImpl());
    bool embZero =  embIx->isZero();
    bool embedZero = embeddings.embedIndex.isZero();
    if (!embZero && !embedZero)
        assert(embIx->compare(embeddings.embedIndex)>=0);
    if (embZero) if (embedZero) return indexCK;
                 else if (embeddings.embedIndex.compare(indexCK)<0)
                        return embeddings.embedIndex.getImpl() ;
                      else return indexCK ;
    const OrdinalImpl * min = embIx ;
    if (min->compare(embeddings.embedIndex.getImpl())>0) 
        min = &(embeddings.embedIndex.getImpl());

    if (min->compare(indexCK)>0) min = &indexCK ;
    return * min ;
}
const OrdinalImpl& AdmisNormalElement::indexCKtoLimitType(const OrdinalImpl&ix)
{
    if (ix.isFinite()) return ix.addLoc(1) ;
    return ix ;
}
/*
const OrdinalImpl& AdmisNormalElement::indexCKtoLimitType(const OrdinalImpl&ix,
    const Ordinal&dd)
{
    if (ix.isLimit()) return ix ;
    const OrdinalImpl * ret = &ix ;
    int sub = dd.isZero() ? 0:1 ; 
    if (ix.isFinite()) sub--;
    if (sub>0) ret = &(ix.subtract(sub));
    else if (sub < 0) ret = &(ix.addLoc(-sub));
    return *ret ;
    
}
*/
/*
const OrdinalImpl& AdmisNormalElement::deltaRestrict(
    const OrdinalImpl& type, bool ddz) const
{
    const OrdinalImpl &delta = embeddings.embedIndex.getImpl();
    if (delta.isZero()) return type ;
    const OrdinalImpl* effDelta = &delta ;
    int inc = 0 ;
    if (!delta.isLimit() && !delta.isFinite()) inc -= 1 ;
    if (inc < 0) {
        effDelta = &(effDelta->subtract(1));
    }
    if (effDelta->compare(type)<=0) {
        const OrdinalImpl * ret = effDelta ;
        if (ddz) assert(!ret->isZero());
        return *ret ;
    }
    return type ;

}

 */   

const OrdinalImpl* AdmisNormalElement::limitInfoCommon(
    CantorNormalElement::LimitTypeInfo& typeInfo) const 
{

    bool dbg = false  ;
    assert(!theLimitType) ;
    typeInfo = unknownLimit;
    const OrdinalImpl * type = NULL ;
    if (!drillDown.isZero()) {
        if (drillDown.isLimit()) {
            type = &(drillDown.limitType());
            typeInfo = drillDownLimit;
        } else {
            assert(drillDown.isSuccessor());
            type = &integerLimitType ;
            if (embeddings.isDrillDownEmbed()) {
                if (drillDown.isOne()) typeInfo = drillDownOneEmbed;
                else typeInfo = drillDownSuccEmbed;
            } else if (drillDown.isOne()) {
                if (indexCK.isOne()) typeInfo = drillDownCKOne ;
                else typeInfo = drillDownOne ;
            } else if (indexCK.isOne()) typeInfo = drillDownSuccCKOne ;
            else typeInfo = drillDownSucc ;

        }
    }
    if (type == NULL) type = IterFuncNormalElement::limitInfoCommon(typeInfo);
    if ((type == NULL) && (size==1)) {
            if (indexCK.isSuccessor()) {
                type = &integerLimitType ;
                if (indexCKeq) typeInfo = indexCKsuccParamEq ;
                else typeInfo = indexCKsuccParam;
            } else {
                assert(indexCK.isLimit());
                type = &indexCK.limitType();
                /* if (indexCK.compare(embeddings.embedIndex.getImpl())==0)
                typeInfo = indexCKlimitParamEq ;
                else 
                */
                typeInfo = indexCKlimitParamUn ;
            }
    }  
    if (!type) {
        if (indexCK.isLimit()) {
           type = &( indexCK.limitType());
           if (embeddings.isParamRestrict()) typeInfo = indexCKlimitEmbed ;
            else typeInfo = indexCKlimit ;
       } else {
           assert(!indexCK.isZero());
           const OrdinalImpl * ix = &indexCK ;
          
           type = &(indexCKtoLimitType(*ix));
           if (embeddings.isParamRestrict()) typeInfo = indexCKsuccEmbed;
           else typeInfo = indexCKsuccUn;
       }
    
    }
    return type ;
    
}

const OrdinalImpl& AdmisNormalElement::limitInfo(
    CantorNormalElement::LimitTypeInfo& typeInfo) const 
{
    typeInfo = unknownLimit;
    const OrdinalImpl* type = limitInfoCommon(typeInfo);
    assert(type);
    return AdmisNormalElement::setLimitType(typeInfo,type);
    
}

const OrdinalImpl& AdmisNormalElement::setLimitType(
    CantorNormalElement::LimitTypeInfo& typeInfo,
    const OrdinalImpl *type) const
{
    const OrdinalImpl  * embType = NULL;
    if (embeddings.isParamRestrict() && !embeddings.embedIndex.isZero()) {
        assert(!embeddings.baseLimitTypeEquiv.isLimit());
        const OrdinalImpl& constructLimitType =
            embeddings.baseLimitTypeEquiv.getImpl().subtract(1) ;
        // type =  &constructLimitType;
        int diff = embeddings.baseLimitTypeEquiv.compare(*type) ;
        if (diff <=0) {
            type =  &constructLimitType;
        // if (diff <=0 && type->isSuccessor()) {
            // embType = &(constructLimitType.subtract(1));
            embType = &(embeddings.baseLimitTypeEquiv.getImpl()) ;
       
        }
        
    }


    return CantorNormalElement::setLimitType(typeInfo,type,embType);

}

bool AdmisNormalElement::isValidLimitOrdParam(const OrdinalImpl& dd) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    DBGO normalForm() << ".isValidLimParam(" << dd.normalForm()<<")\n";
    // int cEmbed = limitEmbedCheck(dd);
    // DBGO "cEmbed = " << cEmbed << "\n " ;
    // if (cEmbed) return cEmbed ;

    int diff = 0 ;
    diff = limitType().compare(dd.maxLimitType());
    DBGO "isValidDiff = " << diff << ", lt = " << limitType().normalForm()
        << ",dd.mlt = " << dd.maxLimitType().normalForm()
        << ", dd = " << dd.normalForm() << "\n" ;
   // if ((diff == 0) && limitType().isLimit()) return checkParamSize(dd);
    if ((diff == 0) && theEmbedType) {
        diff = checkParamSize(dd);
        // assert (diff <=0);
    }
    return (diff > 0) ;
}




/*
const OrdinalImpl& AdmisNormalElement::limitType() const
{
    if (theLimitType) return * theLimitType;
    LimitTypeInfo typeInfo;
    const OrdinalImpl& ret = limitInfo(typeInfo) ;
    return ret ;
}
*/

void AdmisNormalElement::normalFormName(string& base) const 
{
    if (codeLevel < admisCodeLevel) return
        IterFuncNormalElement::normalFormName(base);
    bool useFactor = factor > 1 ;
    if (useFactor) base += "(" ;
    base += AdmisLevOrdinalImpl::makeName(indexCKo,functionLevelO,
        funcParameters,drillDown,embeddings);
    if (useFactor) {
        base += "*" ;
        base += OrdinalImpl::itoa(factor) ;
        base += ")" ;
    }


}



void AdmisNormalElement::psiNormalForm(string& str) const
{
    static const Ordinal * kappaLimit = NULL ;
    if (kappaLimit == NULL) kappaLimit = &Ordinal::omega ;
        
    bool useFactor = factor > 1 ;
    if (useFactor) str += "(" ;

    str += "\\Psi(" ;
    if (embeddings.isParamRestrict()) {
        if (!embeddings.embedIndex.isOne()) goto notDecodable ;
        else  {
            int ckCmp = indexCK.compare(*kappaLimit) ;
            if ((ckCmp==0) && (size==0) && functionLevel.isZero()) {
                str += "\\varepsilon_{\\Omega+1})" ;
                return ;
            }
            if (ckCmp>=0) goto notDecodable;
                        bool useKernel = (size > 0) || !functionLevel.isZero();
            Int depth = indexCK.getFirstTerm()->factor ;
            if (depth > 15) goto notDecodable ;
            Int limit = depth + 3 - (useKernel?1:0);
            for (int i = 0 ; i < limit ; i++)
                str += "\\Omega^{" ;
            
            if (useKernel) str += "(\\Omega" ;
            if (useKernel) psiNormalFormKernel(str);
            if (useKernel) str += ")" ;
            for (int i = 0 ; i < limit ; i++) str += "}" ;

        }
    } else if (!drillDown.isZero()) {
        assert(size ==0);
        assert(functionLevel.isZero());
        if (!indexCK.isOne() ||
            (compare(drillDownLimitValue.getImpl())>=0)) goto notDecodable ;
        
        bool mt = drillDown.getImpl().multipleTerms();
        str += "\\Omega^{\\Omega^{\\Omega " ;
        if (mt) str +="(" ;
        if (mt || !drillDown.isOne()) str += drillDown.psiNormalForm();
        if (mt) str +=")" ;
        str += "}}" ;

    } else goto notDecodable ;
    str += ")" ;
    if (useFactor) {
        str += " " ;
        str += OrdinalImpl::itoa(factor) ;
        str += ")" ;
    }
    return ;
notDecodable:
    str = notBasic();
    return ;
}


void AdmisNormalElement::texNormalForm(string& str) const 
{
    if (codeLevel < admisCodeLevel) {
        IterFuncNormalElement::texNormalForm(str);
        return ;
    }
    bool useFactor = factor > 1 ;
    if (useFactor) str += "(" ;
    str += AdmisLevOrdinalImpl::makeTexName(indexCKo,functionLevelO,
        funcParameters,drillDown,embeddings);
    if (useFactor) {
        str += " " ;
        str += OrdinalImpl::itoa(factor) ;
        str += ")" ;
    }

}

string& AdmisNormalElement::cppNormalForm(const string& name,
    string& ret) const
{
    bool useCreaParam = size <= ord::maxCreaParam ;
    ret += cppClassName();
    ret += "(\n\t\t" ;
    indexCKo.cppNormalForm(name,ret) ;
    ret += ",\n\t\t" ;
    functionLevelO.cppNormalForm(name,ret) ;
    ret += ",\n\t\t" ;
    if (size == 0) ret += "NULL" ;
    else if (useCreaParam) {
        ret += "createParameters(\n\t\t\t&(";
        for (int i = 0 ; i < size ; i++) {
            if (i > 0) ret += "),\n\t\t\t&(" ;
            funcParameters[i]->cppNormalForm(name,ret) ;
        } 
        ret += "))" ;
    } else cppParamNormalForm(name,ret);
    bool noEmbed = (embeddings.type == Embeddings::none) ;
    if (!drillDown.isZero() || !noEmbed || (factor > 1)) {
        ret += ",\n\t\t" ;
        drillDown.cppNormalForm(name,ret);
    }
    if (!noEmbed || (factor>1)) {
        ret += ",\n\t\t(" ;
        embeddings.cppNormalForm(name,ret);
        ret += ")" ;
    }
    if (factor > 1) {
        ret += ", " ;
        ret += factor.get_str();
    }
    ret += "\n\t)" ;
    return ret;
}




const AdmisNormalElement& AdmisNormalElement::addParam(const Ordinal& param)
    const
{
    assert(drillDown.isZero());
    AdmisNormalElement& ret =
        * new AdmisNormalElement(indexCKo,functionLevelO,funcParameters,
            param,embeddings);
    return ret ;
}


const CantorNormalElement& AdmisNormalElement::getCopy(const Int fac) const
{
    if (codeLevel < admisCodeLevel)
        return IterFuncNormalElement::getCopy(fac);
    assert(codeLevel == admisCodeLevel);
    return *new AdmisNormalElement(indexCKo,functionLevelO,funcParameters,
        drillDown,embeddings,fac);

}

static int countParams(const Ordinal * const * params)
{
    if (!params) return 0 ;
    int ret = 0 ;
    while (*params != NULL) params++,ret++;
    return ret ;
}

#define INTERACTIVE(ret,indexCKo,lev,dd,embed) if (ord::interactiveMode) {\
        bool valid = AdmisNormalElement::validAdmisNormalElement(indexCKo, \
        lev,params,dd,embed) ;\
        if (!valid) { \
            outStream() << "Value set to 0.\n" ; \
            return ret ; \
        }\
    }


const OrdinalImpl & AdmisNormalElement::createVirtualOrdImpl
    (const Ordinal & lev, const Ordinal * const * const params) const 
{
    INTERACTIVE(OrdinalImpl::zero,indexCKo,lev,drillDown,embeddings) ;
    return admisLevelFunctional(indexCKo,lev,params,
        drillDown,embeddings).getImpl();
}


const Ordinal &AdmisNormalElement::createVirtualOrd(const Ordinal & lev,
            const Ordinal * const * const params) const 
{
    INTERACTIVE(Ordinal::zero,indexCKo,lev,drillDown,embeddings) ;
    return admisLevelFunctional(indexCKo,lev,params,drillDown,embeddings);
}

const OrdinalImpl & AdmisNormalElement::createVirtualOrdImpl(
    const Ordinal & ix, const Ordinal & lev,
    const Ordinal * const * const params,
    const Ordinal& drillDownParams)const 
{
    INTERACTIVE(OrdinalImpl::zero,ix,lev,drillDownParams,embeddings) ;
    return admisLevelFunctional(ix,lev,params,
        drillDownParams,embeddings).getImpl();
}


const Ordinal &AdmisNormalElement::createVirtualOrd(const Ordinal& ix,
    const Ordinal & lev, const Ordinal * const * const params,
    const Ordinal& drillDownParams) const
{
    INTERACTIVE(Ordinal::zero,ix,lev,drillDownParams,embeddings) ;
    return admisLevelFunctional(ix,lev,params,drillDownParams,embeddings);
}

const OrdinalImpl & AdmisNormalElement::createVirtualOrdImpl(
    const Ordinal & ix, const Ordinal & lev,
    const Ordinal * const * const params,
    const Ordinal& drillDownParams, const Embeddings& embed) const 
{
    INTERACTIVE(OrdinalImpl::zero,ix,lev,drillDownParams,embed) ;
    return admisLevelFunctional(ix,lev,params,
        drillDownParams,embed).getImpl();
}


const Ordinal &AdmisNormalElement::createVirtualOrd(const Ordinal& ix,
    const Ordinal & lev, const Ordinal * const * const params,
    const Ordinal& drillDownParams, const Embeddings& embed) const 
{
    INTERACTIVE(Ordinal::zero,ix,lev,drillDownParams,embed) ;
    return admisLevelFunctional(ix,lev,params,drillDownParams,embed);
}


const OrdinalImpl & AdmisNormalElement::createVirtualOrdImpl(
    const Ordinal * const * const params) const 
{
    INTERACTIVE(OrdinalImpl::zero,indexCKo,functionLevelO,
        drillDown,embeddings) ;
    return admisLevelFunctional(indexCKo,functionLevelO,params,
        drillDown,embeddings).getImpl();

}


const Ordinal & AdmisNormalElement::createVirtualOrd(
    const Ordinal * const * const params) const 
{
    INTERACTIVE(Ordinal::zero,indexCKo,functionLevelO,
        drillDown,embeddings);
    return admisLevelFunctional(indexCKo,functionLevelO,params,
        drillDown,embeddings);

}


static const OrdinalImpl& returningOrd(bool dbg, const char *id,
    const OrdinalImpl& r, const OrdinalImpl& ord,
    const AdmisNormalElement& elt, bool saveFlag = false, bool noSaveFlag=false)
{
    if (!noSaveFlag) if (saveFlag) {
        LastReturnCode::lastLimitOrdCode.codeLevel =
            AdmisNormalElement::admisCodeLevel;
        LastReturnCode::lastLimitOrdCode.exitCode = id ;
    } else {
        LastReturnCode::lastLimitOrdCode.setExit2(id,
            AdmisNormalElement::admisCodeLevel);
    }
    if (dbg) outDbgStream() << "Admis limitOrd returning at " << id <<
        ", val = " << r.normalForm() << ", " << ord.normalForm() <<
        " limit of " << elt.normalForm() << "\n" ;
    else if(Validate::validationTest) outDbgStream()
        << "Admis lo ex " << id << "\n";
    return r;
}

const OrdinalImpl& AdmisNormalElement::limitForIndexCKlimitParamUn(
            const OrdinalImpl& indexCKle) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    assert(functionLevel.isZero());
    assert(size==1);


    const Ordinal& leastNzOrd = *(funcParameters[0]) ;
    assert(leastNzOrd.isSuccessor());
    Ordinal& leastNzMo =
        * new Ordinal(leastNzOrd.getImpl().subtract(1));
        
    const Ordinal*const* params = NULL ;
    if (!leastNzMo.isZero()) 
       params = createParameters(&leastNzMo,NULL);

    // const Ordinal *ixckle = indexCKle ;
    // const Ordinal *ixckle = new Ordinal(indexCK.limitElement(n));
    if (dbg) outStream() << "indexCKle = " << indexCKle.normalForm() <<
        ", embIx = " << embeddings.embedIndex.normalForm() << "\n" ;
    
    const Ordinal& use =leUse(indexCKle);
    if (dbg) outStream() << "use = " << use.normalForm()<<"\n";
    const Ordinal &fl = createVirtualOrd(indexCKo,Ordinal::zero,
        params,Ordinal::zero);
    const OrdinalImpl &ret = createVirtualOrdImpl(use,
        fl.limPlus_1(), NULL,Ordinal::zero);
    return ret ;

}

#define RETURNO(id,x) return returningOrd(dbg, id, addFactorPart(x),ord,\
    *this, true)

#define RETURNOX(id,x) return returningOrd(dbg, id, x, ord, *this)


const OrdinalImpl& AdmisNormalElement::limitOrdCom(const OrdinalImpl & ord)
    const 
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;

    if (dbg) outStream() << "Admis entering for " <<
        normalForm() << ".limitOrd(" << ord.normalForm() << ")\n" ;
    assert(ord.compare(omega)>=0) ;
    DBGO "limitOrdCom switch(" << limInfoName(getLimitInfo()) << ")\n" ;
    switch (getLimitInfo()) {
case unknownLimit:
case finiteLimit:
        assert(0);
case drillDownLimit:
        assert(!drillDown.isZero());
        RETURNO("LOA", createVirtualOrdImpl(indexCKo,functionLevelO,
            funcParameters,*new Ordinal(drillDown.limitOrd(ord))));
case paramLimit:
case paramNxtLimit:
case functionLimit:
case functionNxtLimit:
        RETURNOX("LOB",IterFuncNormalElement::limitOrdCom(ord));
case indexCKlimit:
        RETURNO("LOC",createVirtualOrdImpl(* new Ordinal(
            indexCK.limitOrd(ord)), functionLevelO,funcParameters,
            drillDown));
case indexCKlimitEmbed:
        {
        assert(size==0);
        const OrdinalImpl& le = indexCK.limitOrd(ord);
        RETURNO("LOD",createVirtualOrdImpl(leUse(le), functionLevelO,
            funcParameters, drillDown));
        }
case functionSucc:
case functionNxtSucc:
case paramSucc:
case paramSuccZero:          
case paramsSucc:
        assert(0);
case indexCKlimitParamUn: 
        {   const OrdinalImpl&le = indexCK.limitOrd(ord);
            RETURNO("LOE",limitForIndexCKlimitParamUn(le));
        }
case indexCKsuccEmbed:
case indexCKsuccUn:
        {
            assert(functionLevel.isZero() && drillDown.isZero() &&
                (funcParameters == NULL));
            const Embeddings* embed = &embeddings ;

            if (embeddings.isParamRestrict()) embed =
                &(embeddings.createVirtualEmbedding(
                embeddings.embedIndex,Embeddings::paramRestrict,true));

            RETURNO("LOF",createVirtualOrdImpl(indexCKo,
            Ordinal::zero,NULL,* new Ordinal(ord),*embed));
        }
default:
        assert(0);
    }

    assert(0);
}
#define RETURNOOX(id,x) return returningOrd(dbg, id, x, ord, *this,false, \
true)

const OrdinalImpl& AdmisNormalElement::limitOrd(const OrdinalImpl & ord) const 
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    assert(isValidLimitOrdParam(ord));
    
    RETURNOOX("LTO",limitOrdCom(ord));
}



const OrdinalImpl& AdmisNormalElement::dRep1( 
    const Ordinal& nval) const 
{
    return createVirtualOrdImpl(indexCKo,functionLevelO,
        funcParameters,nval);
}



static const OrdinalImpl& returning1(bool dbg, const char *id,
    const OrdinalImpl& r,
    const Int& n, const AdmisNormalElement& elt,bool saveFlag = false)
{
    if (saveFlag) {
        LastReturnCode::lastLimitCode.codeLevel =
            AdmisNormalElement::admisCodeLevel;
        LastReturnCode::lastLimitCode.exitCode = id ;
    } else LastReturnCode::lastLimitCode.setExit2(id,
        AdmisNormalElement::admisCodeLevel);
    if (!dbg) {
        if (Validate::validationTest)
            outDbgStream() << "Admis le ex " << id << "\n";
        
        return r ;
    } 

    outDbgStream() << "Admis -le limit returning at " << id << ", val = "
        << r.normalForm() << ", " << n << " limit of " << elt.normalForm()
            << "\n" ;
    return r;
}





#define RETURN1(id,x) return returning1(dbg, id, addFactorPart(x), n, *this, \
    true)
#define RETURN1X(id,x) return returning1(dbg, id, x, n, *this)


const Ordinal & AdmisNormalElement::leUse(const OrdinalImpl& le) const
{
    return increasingLimit(embeddings.embedIndex,le);
}

const Ordinal & AdmisNormalElement::increasingLimit(
    const Ordinal& effDelta, const OrdinalImpl& limitElt)
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    const OrdinalImpl& embedIx = effDelta.getImpl();
    const OrdinalImpl & leIn = limitElt;


    int cmp = 0 ;
    int ix = 1 ;
    
    const CantorNormalElement * leFirstTerm = leIn.getFirstTerm();
    if (leFirstTerm == NULL) return effDelta ;


    const NormalFormTerm * embedTail = embedIx.terms ;
    const NormalFormTerm * leTailCheck = leIn.terms ;
    while (embedTail && leTailCheck && leTailCheck->next) {
        int cmp = embedTail->term.compare(leTailCheck->term) ;
        if (cmp > 0) break ;
        if (cmp == 0) leTailCheck = leTailCheck->next ;
        if (dbg) outStream() << "skipping embed " <<
            embedTail->term.normalForm() << "\n" ;
        embedTail= embedTail->next ;
    }
    NormalFormTerm * tail = NULL ;
    const NormalFormTerm * leTail = leIn.terms ;
    

    while (true) {
        const CantorNormalElement * newTerm = NULL ;
        if (embedTail && leTail) {
            int cmp = embedTail->term.compare(leTail->term,true);
            if (!cmp) {
                Int useFactor = 0 ;
                if (leTail->next==NULL) useFactor =
                    embedTail->term.factor + leTail->term.factor;
                else useFactor=(embedTail->term.factor > leTail->term.factor) ?
                    (embedTail->term.factor) : (leTail->term.factor) ;
                newTerm = &(embedTail->term.getCopy(useFactor));
                
                embedTail = embedTail->next ;
                leTail = leTail->next ;
            } else if (cmp < 0) {
                newTerm = &(leTail->term);
                leTail = leTail->next ;
            } else { 
                newTerm = &(embedTail->term);
                embedTail = embedTail->next ;
            }
        } else if (embedTail) {
            newTerm =  &(embedTail->term);
            embedTail = embedTail->next ;
        } else if (leTail) {
            newTerm = &(leTail->term);
            leTail = leTail->next ;
        } else break ;
        if (!newTerm) break ;
        if (dbg) outStream() << "Adding cmp = " << cmp << ", added trm = " <<
            newTerm->normalForm() << "\n" ;
        if (!tail) tail = new NormalFormTerm(*newTerm);
        else tail->append(*newTerm);
    } 
    assert(tail);
    const OrdinalImpl *ret = new OrdinalImpl("loUse",*tail);
    if (dbg) outStream() << "loUsele(" << leIn.normalForm() << ") = "
        << ret->normalForm() 
        << ", embedIx = " << embedIx.normalForm() << "\n" ;
    return * new Ordinal(*ret);
}

const OrdinalImpl& AdmisNormalElement::drillDownLimitElement(Int n) const
{
    bool dbg = OrdinalImpl::debugControl.check(
        DebugControlParam::limit,0);

         switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
        assert(0);
case drillDownLimit:     
case drillDownSucc:
case drillDownOne:
case drillDownSuccEmbed:
case drillDownOneEmbed:
        // RETURN1X("DDLC",drillDownLimitElementCom(n));
        RETURN1X("DDAC",drillDownLimitElementCom(n));
case drillDownCKOne:
        {
            const Ordinal & ixMo = *new Ordinal(indexCK.subtract(1));
            const Ordinal * base = &Ordinal::omega ;
            for (int i = 1 ; i < n ; i++)
                base = &(iterativeFunctional(base->limPlus_1(),NULL));
            // RETURN1("DDKO",base->getImpl());
            RETURN1("DDBO",base->getImpl());

        }
case drillDownSuccCKOne:
        {
            const Ordinal& ddMo =
                * new Ordinal((drillDown.getImpl().subtract(1)));
            assert(!ddMo.isZero());
            const Ordinal * base = new Ordinal(dRep1(ddMo));
            for (int i = 1 ; i < n ; i++) base =
                &(iterativeFunctional(base->limPlus_1(),NULL));
            // RETURN1("DDGA",base->getImpl());
            RETURN1("DDCO",base->getImpl());
        }
case paramSucc:          
case paramSuccZero:          
case paramsSucc:          
case paramLimit:         
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
case indexCKlimit:       
case indexCKsuccParam:
case indexCKsuccParamEq:
case indexCKsuccEmbed: 
case indexCKlimitEmbed:
// case indexCKlimitEmbedEq:
default:
        assert(0);
    }
    assert(0);
}

const OrdinalImpl& AdmisNormalElement::drillDownLimitElementCom(Int n) const 
{
    bool dbg = OrdinalImpl::debugControl.check(
        DebugControlParam::limit,0);

    assert(!size && functionLevel.isZero() && !drillDown.isZero());


    switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
        break ;
case drillDownLimit:
        {
            const Ordinal * ddlm = new Ordinal(drillDown.limitElement(n));
            // RETURN1("DDL", createVirtualOrdImpl(indexCKo,Ordinal::zero, NULL,
            //    *ddlm));
            RETURN1("DCAL", createVirtualOrdImpl(indexCKo,Ordinal::zero, NULL,
                *ddlm));

        }
case drillDownOneEmbed:
        {
            assert(embeddings.isDrillDownEmbed());
            const Embeddings&  embed = embeddings.ddEmbFalseCopy();
            const Ordinal * base = &Ordinal::omega ;
            /*
            if (!embed.embedIndex.isOne()) base = &(createVirtualOrd(
                * new Ordinal(embeddings.embedIndex.getImpl().
                   subtract(1)),Ordinal::zero,
                NULL,Ordinal::zero,Embeddings::embedNone));
            */
            for (int i = 1 ; i < n ; i++)
                base = &createVirtualOrd(indexCKo,Ordinal::zero,NULL,
                    *base,embed);
            // RETURN1("DDKC",base->getImpl()) ;
            RETURN1("DCBO",base->getImpl()) ;
        }
case drillDownSuccEmbed:
        {
            assert(embeddings.isDrillDownEmbed());
            const Ordinal& ddMo =
                * new Ordinal((drillDown.getImpl().subtract(1)));
            const Ordinal * base = new Ordinal(dRep1(ddMo));
            const Embeddings& emb = embeddings.ddEmbFalseCopy();
            for (int i = 1 ; i < n ; i++) base = &createVirtualOrd(
                indexCKo,Ordinal::zero,NULL,*base,emb);
            // RETURN1("DDE",base->getImpl());
            RETURN1("DCCS",base->getImpl());
        }
case drillDownOne:
        {
            assert(!embeddings.isDrillDownEmbed());
            const Ordinal & ixMo = *new Ordinal(indexCK.subtract(1));
                assert(!ixMo.isZero()) ;
            const Ordinal* base = &(createVirtualOrd(ixMo,Ordinal::zero,
                NULL,Ordinal::zero));
            for (int i = 1 ; i < n ; i++)base=&(createVirtualOrd(ixMo,
                base->limPlus_1(),NULL,Ordinal::zero));
            // RETURN1("DDO",base->getImpl());
            RETURN1("DCDO",base->getImpl());

        }
case drillDownSucc:
        {
            assert(!embeddings.isDrillDownEmbed());
            const Ordinal& ddMo =
                * new Ordinal((drillDown.getImpl().subtract(1)));
            const Ordinal * base = new Ordinal(dRep1(ddMo));
            const Ordinal & ixMo = *new Ordinal(indexCK.subtract(1));
            for (int i = 1 ; i < n ; i++) base = &(createVirtualOrd(ixMo,
                base->limPlus_1(),NULL,Ordinal::zero)) ;
            // RETURN1("DDGB",base->getImpl());
            RETURN1("DCES",base->getImpl());

        }
case paramSucc:          
case paramSuccZero:          
case paramsSucc:          
case paramLimit:         
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
case indexCKlimit:       
case indexCKsuccParam:
case indexCKsuccParamEq:
case indexCKsuccEmbed: 
case indexCKlimitEmbed:
// case indexCKlimitEmbedEq:
default:
        assert(0);
    }
    assert(0);
    
}

/*
 
     switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
case paramSucc:          
case paramLimit:         
case paramSuccZero:          
case paramsSucc:          
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
case drillDownLimit:     
case drillDownSucc:
case drillDownSuccCKOne:
case drillDownSuccEmbed:
case drillDownOne:
case drillDownCKOne: 
case drillDownOneEmbed:
case indexCKlimit:       
case indexCKsuccParam:
case indexCKsuccParamEq:
case indexCKsuccEmbed:
case indexCKsuccUn:
case indexCKlimitParamUn:
case indexCKlimitEmbed:
default:
        break ; // change to assert 0
    }



 */



const OrdinalImpl& AdmisNormalElement::limitElement(Int n) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;
    if (dbg) outStream() << "Entering Admis " <<
        normalForm() << ".limitElement(" << n << ")\n" ;
    int leastNz = size -1;
    const Ordinal * setLeastNz = &Ordinal::zero ;
    const Ordinal * setLeastNzMo = &Ordinal::zero ;
    if (size > 0) {
        if (funcParameters) while ((leastNz >= 0) &&
                funcParameters[leastNz]->isZero()) leastNz--;
        setLeastNz = funcParameters[leastNz] ;
        if (setLeastNz->isSuccessor()) 
            setLeastNzMo = new Ordinal(setLeastNz->getImpl().subtract(1));
    }
    const Ordinal& leastNzOrd = *(setLeastNz);
    const Ordinal& leastNzMo = *(setLeastNzMo);


    switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
        assert(0);
case drillDownLimit:     
case drillDownOne: 
case drillDownSuccEmbed:
case drillDownOneEmbed:
case drillDownSucc: 
case drillDownSuccCKOne: 
case drillDownCKOne:
        // RETURN1X("DDA",drillDownLimitElement(n));
        RETURN1X("LEAD",drillDownLimitElement(n));
        // start of limitElementCom
case paramSucc:          
case paramSuccZero:          
case paramsSucc:          
case paramLimit:         
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
case indexCKlimit:
case indexCKlimitParamUn:
case indexCKsuccParam:
case indexCKsuccEmbed:        
case indexCKlimitEmbed: 
        RETURN1X("LEBC",limitElementCom(n));
                
case indexCKsuccParamEq:
        {
            assert(indexCK.compare(embeddings.embedIndex)==0);
            Ordinal& ixckMo = * new Ordinal(indexCK.subtract(1));
            const OrdinalImpl * base =
                &(replace1(leastNz,leastNzMo));
            /*
            const AdmisNormalElement *baseElt =
                (const AdmisNormalElement *) base->getFirstTerm();
            
            const Ordinal * const * params = baseElt->funcParameters;
            */
            for (int i = 1 ; i < n ; i++) {
                  base = &(admisLevelFunctional(ixckMo,
                      *new Ordinal(base->limPlus_1()),NULL,
                      Ordinal::zero, Embeddings::embedNone).getImpl());
            }
            // RETURN1("CKSC", *base);
            RETURN1("LECK", *base);

        }
case indexCKsuccUn:
        // RETURN1("KE",createOrdinal(addParam(* new Ordinal(n))));
        RETURN1("LEDC",createOrdinal(addParam(* new Ordinal(n))));
/*
case indexCKsuccEmbed:        
        {
            const Embeddings& embed = embeddings.ddEmbCopy();
            RETURN1("LEDE",createVirtualOrdImpl(indexCKo,zero,NULL,
                *new Ordinal(n),embed));
        }
*//*
case indexCKlimitEmbed: 
        {
            const Ordinal& le = indexCKo.limitElement(n);
            // const Ordinal * newIxCK = &(leUse(n));
            const Ordinal * newIxCK = &(leUse(le.getImpl()));
            RETURN1("LEEE",admisLevelFunctional(newIxCK->limPlus_1(),
                Ordinal::zero,NULL,Ordinal::zero,embeddings).getImpl());

        }
*/
default:
        assert(0);
    }
    assert(0);
}

const OrdinalImpl& AdmisNormalElement::limitElementCom(Int n) const 
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::limit,0) ;

      switch (getLimitInfo()) {
case unknownLimit:
case zeroLimit:
case finiteLimit:
case drillDownLimit:     
case drillDownOne: 
case drillDownSuccEmbed:
case drillDownOneEmbed:
case drillDownSucc: 
            assert(0);
case paramSucc:          
case paramSuccZero:          
case paramsSucc:          
case paramLimit:         
case paramNxtLimit:      
case functionSucc:          
case functionNxtSucc:          
case functionLimit:
case functionNxtLimit:
            // RETURN1X("KA", IterFuncNormalElement::limitElementCom(n));
            RETURN1X("LCAF", IterFuncNormalElement::limitElementCom(n));
case indexCKlimit:
            // RETURN1("LC",createVirtualOrdImpl(
            RETURN1("LCBL",createVirtualOrdImpl(
                indexCKo.limitElement(n).limPlus_1(),Ordinal::zero,NULL,
                Ordinal::zero));
case indexCKsuccParam:   
            {
                assert(size ==1);
                assert(functionLevel.isZero());
                assert(drillDown.isZero());
                const Ordinal & leastNzOrd = *(funcParameters[0]);
                assert(leastNzOrd.isSuccessor());
                const Ordinal * const * params = NULL ;
                if (!leastNzOrd.isOne()) {
                    const Ordinal& leastNzMo = * new Ordinal(leastNzOrd.
                        getImpl().subtract(1));
                    params = createParameters(&leastNzMo,NULL);
                }
                const Ordinal * base = &(createVirtualOrd(indexCKo,
                    Ordinal::zero, params, Ordinal::zero));
                if (indexCK.isOne()) {
                    for (int i = 1 ; i < n ; i++) base =
                        &(iterativeFunctional(base->limPlus_1(),params));
                    // RETURN1("CKSA",base->getImpl()) ;
                    RETURN1("LCCI",base->getImpl()) ;
                }
                const Ordinal& ixckMo = * new Ordinal(indexCK.subtract(1));
                
                for (int i = 1 ; i < n;i++) base = &(createVirtualOrd(
                    ixckMo,base->limPlus_1(),params,Ordinal::zero));
                 // RETURN1("CKSB", base->getImpl());
                 RETURN1("LCDP", base->getImpl());

                /*
                assert(size ==1);
                const Ordinal & leastNzOrd = *(funcParameters[0]);
                assert(leastNzOrd.isSuccessor());
                const Ordinal& leastNzMo = * new Ordinal(leastNzOrd.getImpl().
                    subtract(1));
                const Ordinal& ixckMo = * new Ordinal(indexCK.subtract(1));
                const OrdinalImpl * base =
                    &(replace1(0,leastNzMo).limPlus_1());
                const AdmisNormalElement *baseElt =
                    (const AdmisNormalElement *) base->getFirstTerm();
                const Ordinal * const * params = baseElt->funcParameters;
                for (int i = 0 ; i < n ; i++) {
                    base = &(createVirtualOrdImpl(ixckMo,
                        (* new Ordinal(*base)).limPlus_1(),params,
                        Ordinal::zero));
                }
                RETURN1("CKSB", *base);
                */
            }

case indexCKsuccParamEq:   
        assert(0);
case indexCKsuccEmbed:        
        {
            const Embeddings& embed = embeddings.ddEmbCopy();
            RETURN1("LEDE",createVirtualOrdImpl(indexCKo,Ordinal::zero,NULL,
                *new Ordinal(n),embed));
        }
case indexCKlimitEmbed:
        {
            const Ordinal& le = indexCKo.limitElement(n);
            // const Ordinal * newIxCK = &(leUse(n));
            const Ordinal * newIxCK = &(leUse(le.getImpl()));
            RETURN1("LEEE",createVirtualOrdImpl(newIxCK->limPlus_1(),
                Ordinal::zero,NULL,Ordinal::zero,embeddings));
            /* RETURN1("LEEE",admisLevelFunctional(newIxCK->limPlus_1(),
                Ordinal::zero,NULL,Ordinal::zero,embeddings).getImpl()); */

        }


case indexCKlimitParamUn:
        {
            
            const OrdinalImpl&le = indexCK.limitElement(n);
            RETURN1("LCEL",limitForIndexCKlimitParamUn(le));
            /*
            assert(functionLevel.isZero());
            assert(size==1);


            const Ordinal& leastNzOrd = *(funcParameters[0]) ;
            assert(leastNzOrd.isSuccessor());
            Ordinal& leastNzMo =
                * new Ordinal(leastNzOrd.getImpl().subtract(1));
                
            const Ordinal** params = NULL ;
            if (!leastNzMo.isZero()) {
               int nint ;
               params = createParamArray(1,nint);
            }
            const Ordinal *ixckle = new Ordinal(indexCK.limitElement(n));
            if (dbg) outStream() << "ixckle = " << ixckle->normalForm() <<
                ", embIx = " << embeddings.embedIndex.normalForm() << "\n" ;
            
            ixckle = &(leUse(ixckle->getImpl()));
            if (params) params[0] = &leastNzMo;
            if (dbg) outStream() << "ixckle = " << ixckle->normalForm()<<"\n";
            const Ordinal &fl = createVirtualOrd(indexCKo,Ordinal::zero,
                params,Ordinal::zero,embeddings);
            const OrdinalImpl &ret = createVirtualOrdImpl(*ixckle,
                fl.limPlus_1(), NULL,Ordinal::zero);
            // RETURN1("CKLM",ret);
            RETURN1("LCEL",ret);
            */
        }
// case indexCKlimitEmbedEq:  
// case indexCKlimitEmbed:
default:
        assert(0);
    }
    assert(0) ;
    
}

const CantorNormalElement & AdmisNormalElement::addFactors(
    const CantorNormalElement& toAdd) const 
{
    if (codeLevel < admisCodeLevel) return
        IterFuncNormalElement::addFactors(toAdd);
    return * new AdmisNormalElement(indexCKo,functionLevelO,
        funcParameters,drillDown,embeddings,factor+toAdd.factor);
}

static int returning(bool dbg, const char *id, int r, 
    const AdmisNormalElement& op1, const CantorNormalElement &op2,
    bool ignoreFactor, const Embeddings& embed, const Embeddings& termEmbed) 

{
    op1.entryDec();
    if (dbg) {
        outDbgStream() << "Admis elt compare returning at " << id <<
            ", val = "
            << r << ", cmp(" << op1.normalForm() << " ::\n" << op2.normalForm()
            << "), ignf = " << ignoreFactor << "\nemb = " <<
            embed.normalForm() << ", trm.emb = " << termEmbed.normalForm()
            << "\n" ;
    } else if (Validate::outCmpExit() && (op1.entryCount <2))
        outDbgStream() << "Admis cmp ex " << id << ", " <<op1.entryCount<<"\n";
    assert(op1.entryCount > -1);
    

    return r;
}

#define RETURN2(id,x) return returning(dbg, id, x, *this, trm, ignoreFactor,\
    embed,termEmbed)

const Embeddings& CantorNormalElement::getEmbed() const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    if (codeLevel < AdmisNormalElement::admisCodeLevel)
        return Embeddings::embedNone ;

    const AdmisNormalElement & elt = (const AdmisNormalElement &) * this ;
    DBGO "elt = " << elt.normalForm() << ", elt.emb = " <<
        elt.embeddings.normalForm() << ", this = " << normalForm() <<
        ", elev = " << elt.embeddings.embedLevel << "\n" ;
    return elt.embeddings ;
}
/*
int  CantorNormalElement::limitEmbedCheck(const OrdinalImpl& ord) const
{
    const Embeddings& myEmbed = getEmbed();
    if (!myEmbed.isParamRestrict()) return 0 ;
    const CantorNormalElement * ordLT = ord.getLastTerm();
    if (!ordLT) return 1 ;
    if (ordLT->codeLevel < AdmisNormalElement::admisCodeLevel) return 0;
     const Embeddings& paramEmbed = ((const AdmisNormalElement&) *ordLT).
        getEmbed();
    if (!paramEmbed.isParamRestrict()) return 0 ;
    // int classDiff = myEmbed.embedClass().compare(paramEmbed.embedClass());
    // if (classDiff) return classDiff ;
    return myEmbed.compare(paramEmbed);
}
*/


int AdmisNormalElement::compare(const CantorNormalElement& trm,
    bool ignoreFactor ) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
   if (dbg) {
        outDbgStream() << "Admis elt compare entry(" <<
            normalForm() << " : " << trm.normalForm() << ", " <<
                ignoreFactor << ")\n"  ;
    }
  

    assert(codeLevel>=admisCodeLevel) ;
    const Embeddings&  trmEmbed = trm.getEmbed();
    DBGO "trmEmbed = " << trmEmbed.normalForm() << " for " <<
        trm.normalForm() << "\n" ;
    return compare(embeddings, trmEmbed,trm, ignoreFactor);
}


#define RETURNE(X) {DBGO "errEmb returning " << X.normalForm() << "\n"; \
    return X;}



const Embeddings & AdmisNormalElement::effectiveEmbedding(
    const Embeddings& termEmbed, bool compareFlag) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    DBGO "effectiveEmbedding for " << normalForm() << " (" <<
        termEmbed.normalForm() << "\n" ;

    const Embeddings * useEmbed = &termEmbed ;
    if (!(embeddings.type == Embeddings::paramRestrict))
        if (!(useEmbed->type == Embeddings::paramRestrict))
            RETURNE(Embeddings::embedNone) 
        else RETURNE((*useEmbed))
    else 
        if (!(useEmbed->type == Embeddings::paramRestrict))
            RETURNE(embeddings) 
    int diff = embeddings.embedClass().compare(useEmbed->embedClass());
    if (diff < 0) RETURNE(embeddings) ;
    if (diff > 0) RETURNE((*useEmbed)) ;
    diff = embeddings.compare((*useEmbed)) ;
    DBGO "Checking past embedClass\n";
    if (compareFlag) {
        if (diff < 0) RETURNE(embeddings) ;
        if (diff > 0) RETURNE((*useEmbed)) ;
    } else {
        RETURNE(embeddings);
        if (diff > 0) RETURNE(embeddings) ;
        if (diff < 0) RETURNE((*useEmbed)) ;
    }
    assert(embeddings.type == Embeddings::paramRestrict);
    RETURNE (embeddings);
}

const OrdinalImpl& AdmisNormalElement::effectiveIndexCK(
    const Embeddings& embed) const
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    DBGO "emb.isPaRe = " << embed.isParamRestrict() <<
            ", ddz = " << drillDown.isZero() << "\nixCK = " <<
            indexCK.normalForm() <<
            ", ixCKmo  = " << indexCKmo.normalForm() << ", eIx = " << 
             embed.embedIndexMo.getImpl().normalForm() << "\n" ;
    if (!embed.isParamRestrict()) {
        if (drillDown.isZero()) return indexCK ; else return indexCKmo ;
    }
    if (indexCK.compare(embed.embedIndex)<0) return indexCK ;
    return embed.embedIndexMo.getImpl();
}


const OrdinalImpl&AdmisNormalElement::kappaLim(const OrdinalImpl& effEmbIx)const
{
    if (indexCK.compare(effEmbIx)<0) return indexCK; else return effEmbIx;
}

bool AdmisNormalElement::isEmbDrillDown() const
{
    return embeddings.isDrillDownEmbed();
}

int AdmisNormalElement::compare(const Embeddings& embed,
    const Embeddings& termEmbed, const CantorNormalElement& trm,
    bool ignoreFactor) const 
{
    entryInc();
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;
    if (trm.codeLevel >admisCodeLevel)
        RETURN2("A1", -trm.compare(termEmbed,embed,*this,ignoreFactor));

    if (dbg) if (!embeddings.embedIndex.isZero()) 
        assert(embeddings.embedIndex.compare(embed.embedIndex) >=0);
    
    DBGO "Admis elt compare(embed = " << embed.normalForm() <<
        ",\ntermEmbed = " << termEmbed.normalForm() << ",\ntrm = " <<
         trm.normalForm() << ") for " <<  normalForm() << "\n" ;
    assert(codeLevel >= admisCodeLevel);
    const Embeddings& effEmbed = effectiveEmbedding(embed);
    DBGO "effEmbed = " << effEmbed.normalForm() << "\n" ;
    if (trm.codeLevel < admisCodeLevel) {
        const OrdinalImpl&  trmMaxParam = trm.getMaxParameter();
        DBGO "trmMaxParam = " << trmMaxParam.normalForm() << "\n" ;
        if (trmMaxParam.isZero()) RETURN2("A2",1);
        const CantorNormalElement * maxParamFirstTerm =
            trmMaxParam.getFirstTerm();
        if (maxParamFirstTerm) {
            DBGO "A3 exit compares " << normalForm()
                << " :: " << maxParamFirstTerm->normalForm() << "\n" ;
            if (compare(effEmbed,termEmbed, *maxParamFirstTerm,true) <=0)
                RETURN2("A3", -1) ;
        }
        RETURN2("A4",1); 
    } 

    const AdmisNormalElement& ftrm = (const AdmisNormalElement&) trm;
    const Embeddings& trmEffEmbed= ftrm.effectiveEmbedding(termEmbed);

    int diff = parameterCompare(effEmbed,trmEffEmbed,trm);
    if (diff) DBGO "maxParam = " << getMaxParameter().normalForm() << 
        ",\n term.maxParam = " << trm.getMaxParameter().normalForm() << "\n" ;
    if (diff) RETURN2("A5",diff);

    if (trm.codeLevel > admisCodeLevel)
        RETURN2("A6", -ftrm.compare(trmEffEmbed,effEmbed,*this));

    RETURN2("C1",compareCom(embed,trmEffEmbed,ftrm,ignoreFactor));

}


int AdmisNormalElement::compareCom(const Embeddings& embed,
    const Embeddings& termEmbed, const CantorNormalElement& trm,
    bool ignoreFactor) const 
{
    entryInc();
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::compare,0) ;

    DBGO "Admis elt compareCom(embed = " << embed.normalForm() <<
        ",\ntermEmbed = " << termEmbed.normalForm() << ",\ntrm = " <<
         trm.normalForm() << ", ignf = " << ignoreFactor <<
         ") for " <<  normalForm() << "\n" ;


    int diff = 0  ;
    const Embeddings& effEmbed = effectiveEmbedding(embed);
    assert(trm.codeLevel >= admisCodeLevel);
    const AdmisNormalElement& ftrm = (const AdmisNormalElement&) trm;
    const Embeddings& trmEffEmbed= ftrm.effectiveEmbedding(termEmbed);

    if (effEmbed.isParamRestrict()  && (trmEffEmbed.isParamRestrict())) {
        diff = effEmbed.embedIndex.getImpl().compare(
            trmEffEmbed.embedIndex.getImpl()) ;
        if (diff) RETURN2("B1",diff);
    }

    const OrdinalImpl& effIndexCk = effectiveIndexCK(effEmbed);
    const OrdinalImpl& trmEffIndexCK =
        ftrm.effectiveIndexCK(trmEffEmbed);
    DBGO "effEmbed = " << effEmbed.normalForm() << 
        "\ntrmEffEmbed = " << trmEffEmbed.normalForm() << "\n" ;
    DBGO "effIxCK = " << effIndexCk.normalForm() <<
        "\nterm effIxCK = " << trmEffIndexCK.normalForm() << "\n" ;

    diff = effIndexCk.compare(trmEffIndexCK) ;
    if (diff) RETURN2("B2",diff);
    diff = indexCK.compare(effEmbed,trmEffEmbed,ftrm.indexCK);
    DBGO "ixCk = " << indexCK.normalForm() << ", trmIxCk = "
        << ftrm.indexCK.normalForm() << ", effEmb "
        << effEmbed.normalForm() << ", termeffEmb " <<
        trmEffEmbed.normalForm() << "\n" ;
        
    if (diff) RETURN2("B3",diff);

    if (!drillDown.isZero() && !ftrm.drillDown.isZero()) {
        int emb = isEmbDrillDown()? 1:0 ;
        int ftrmEmb = ftrm.isEmbDrillDown()? 1:0 ;
        int diff = emb-ftrmEmb ;
        if (diff)  RETURN2("B4",diff) ;
        diff = drillDown.getImpl().compare(
             effEmbed.embedClass(),trmEffEmbed.embedClass()
             ,ftrm.drillDown.getImpl()); 
        if (diff) DBGO "drillDown = " << drillDown.normalForm() <<
            "\nftrm.drillDown = " << ftrm.drillDown.normalForm() <<
            "\neffEmbed = " << effEmbed.normalForm() <<
            "\ntrmEffEmbed = " << trmEffEmbed.normalForm() << 
            "\nthis = " << normalForm() <<
            "\nftrm = " << ftrm.normalForm() << "\n" ;
        if (diff) RETURN2("B5", diff) ;
    } 
    diff = (drillDown.isZero()?1:0) - (ftrm.drillDown.isZero()?1:0);
    if (diff) RETURN2("B6",diff);

    diff = functionLevel.compare(embed,termEmbed,
        ftrm.functionLevel) ;
     if (diff) RETURN2("B7",diff);

    diff = compareFiniteParams(embed,termEmbed,ftrm);
    if (diff || ignoreFactor) RETURN2("B8",diff);
    diff = cmp(factor,ftrm.factor) ;
    RETURN2("B9", diff) ;

}

static void fixReturn(const char * id, bool ret)
{
    outStream() << "fpr ret " << ret << " at " << id << "\n" ;
}

#define FRETURN(id,ret) {if (dbg) fixReturn(id,ret); return ret;}

bool AdmisLevOrdinal::fixedPoint(const OrdinalImpl& ixCK, const Ordinal& iter,
    int ix, const Ordinal* const * const params, const Embeddings& emb)
{
    bool dbg = OrdinalImpl::debugControl.check(DebugControlParam::ctrOrd) ;
    if (ixCK.isZero()) FRETURN("FA",
        IterFuncOrdinal::fixedPoint(iter,ix,params,emb));
   if (ix == iterMaxParam)  {
        if (iter.getImpl().psuedoCodeLevel() < 
            AdmisNormalElement::admisCodeLevel) FRETURN("FC",false) ;
        FRETURN("FC", AdmisLevOrdinalImpl (*new Ordinal(ixCK),
            Ordinal::zero).compare(emb,emb,iter.getImpl()) < 0);
    }
    assert(ix>=0);
    if (params[ix]->getImpl().psuedoCodeLevel() <
        AdmisNormalElement::admisCodeLevel) FRETURN("FE", false) ;
    if (ix == 0) FRETURN("FF",
        AdmisLevOrdinalImpl(ixCK,iter,NULL).compare(emb,emb,
        params[0]->getImpl()) < 0);
    int size = 0 ;
    for (;params[size];size++);
    const Ordinal** nParams = new const Ordinal *[size+1] ;
    nParams[size]=0;
    assert(ix<size);
    for (int i = 0 ; i < ix;i++) nParams[i] = params[i] ;
    for (int i = ix ; i < size ; i++) nParams[i] = &(Ordinal::zero) ;
    FRETURN("FG", AdmisLevOrdinalImpl(ixCK,iter,nParams).compare(emb,emb,
        (params[ix]->getImpl())) < 0);
}


const NormalFormTerm& AdmisLevOrdinalImpl::createTerms(
    const Ordinal& indexCK, const Ordinal& iter,
    const Ordinal* const * const params,const Ordinal& dd,
    const Embeddings& embed, Int factor)
{
    const AdmisNormalElement& elt = * new AdmisNormalElement(indexCK, iter,
        params,dd,embed,factor) ;
    return * new NormalFormTerm(elt) ;

}

const OrdinalImpl & AdmisLevOrdinalImpl::addEmbeddings(
    const Embeddings& emb,const Ordinal&dd) const
{
    assert(terms) ;
    const CantorNormalElement& firstTerm = terms->term ;
    assert (firstTerm.codeLevel == AdmisNormalElement::admisCodeLevel); 
    const AdmisNormalElement &adm = (const AdmisNormalElement&) firstTerm ;
    const AdmisNormalElement &admOut = adm.addEmbeddings(emb,dd);
    const NormalFormTerm * out = new NormalFormTerm(admOut);
    const NormalFormTerm * next = terms->next ;
    while (next) {
        out->append((next)->term) ;
        next = next->next ;
    }
    return * new AdmisLevOrdinalImpl(normalForm(),*out);
}



const AdmisLevOrdinal* AdmisLevOrdinalImpl::getAdmissibleBase() const
{
    const CantorNormalElement * frst = getFirstTerm();
    if (!frst) return NULL;
    if (frst->codeLevel < AdmisNormalElement::admisCodeLevel) return NULL ;
    const AdmisNormalElement & elt = (AdmisNormalElement&)*frst ;
    return &(elt.getAdmissibleBase());
}


string AdmisLevOrdinalImpl::makeName(const Ordinal& ixCK,
    const Ordinal& iter, const Ordinal* const * const params,
    const Ordinal &drillDown, const Embeddings& embed)
{
    if (ixCK.isZero()) return IterFuncOrdinalImpl::makeName(iter,params);
    string base = "" ;
    if (embed.type == Embeddings::paramRestrict) {
        base += "[[" ;
        assert(!embed.embedIndex.isZero());
        base += embed.embedIndex.normalForm();
        base += "]]" ;
    }
    return makeNameCom(base,ixCK,iter,params,drillDown,embed);
}


string AdmisLevOrdinalImpl::makeNameCom(string& base, const Ordinal& ixCK,
    const Ordinal& iter, const Ordinal* const * const params,
    const Ordinal &drillDown, const Embeddings& embed)
{
    int count = 0 ;
    if (params) for (;params[count];count++) ;
    base += "omega_{ " ;
    base += ixCK.normalForm();
    if (!iter.isZero()) {
        base += ", " ;
        base += iter.normalForm() ;
    }
    base += "}" ;
    if (count) {
        base += "(" ;
        for (int i = 0 ; i < count; i++) {
            if (i) base += ", " ;
            base += params[i]->normalForm() ;
        }
        base += ")" ;
    }
    if (!drillDown.isZero()) {
        bool doubBracket = embed.isDrillDownEmbed();
        base += doubBracket? "[[ ":"[ " ;
        base += drillDown.normalForm() ;
        base += doubBracket? "]]":"]" ;
    }
    return base ;
}

string AdmisLevOrdinalImpl::makeTexName(const Ordinal& ixCK,
    const Ordinal& iter, const Ordinal* const * const params,
    const Ordinal &drillDown, const Embeddings& embed)
{
    if (ixCK.isZero()) return IterFuncOrdinalImpl::makeTexName(iter,params);
    string base = "" ;
    if (embed.type == Embeddings::paramRestrict) {
        base += "[[" ;
        assert(!embed.embedIndex.isZero());
        base += embed.embedIndex.texNormalForm();
        base += "]]" ;
    }
    return makeTexNameCom(base, ixCK,iter,params,drillDown,embed);
}


string AdmisLevOrdinalImpl::makeTexNameCom(string &base, const Ordinal& ixCK,
    const Ordinal& iter, const Ordinal* const * const params,
    const Ordinal &drillDown, const Embeddings& embed)
{
    int count = 0 ;
    if (params) for (;params[count];count++) ;
    base += "{\\omega_{" ;
    base += ixCK.texNormalForm();
    if (!iter.isZero()) {
        base += ", ";
        base += iter.texNormalForm() ;
    }
    base += "}}" ;
    if (count) {
        base += "(" ;
        for (int i = 0 ; i < count; i++) {
            if (i) base += ", " ;
            base += params[i]->texNormalForm() ;
        }
        base += ")" ;
    }
    if (!drillDown.isZero()) {
        bool doubBracket = embed.isDrillDownEmbed();
        base += doubBracket? "[[":"[" ;
        base += drillDown.texNormalForm() ;
        base += doubBracket? "]]":"]" ;
    }

    return base ;
}

const AdmisNormalElement * AdmisLevOrdinalImpl::getFirstAdmis() const
{
    const CantorNormalElement * frst = getFirstTerm();
    if (frst == NULL) return NULL ;
    if (frst->codeLevel < AdmisNormalElement::admisCodeLevel)
        return NULL ;
    return (AdmisNormalElement*) frst ;

}

const OrdinalImpl& AdmisLevOrdinalImpl::getIndexCK() const
{
    const AdmisNormalElement *elt = getFirstAdmis();
    assert(elt);
    return elt->getIndexCK();
}



void LabeledOrdinal::cppExampNames(list<LabeledOrdinal*>& labOrds)
{

#define NM_EXAMP(name) labOrds.push_back \
(new LabeledOrdinal(#name,name,NULL,Ordinal::zero, \
    (Act) (noCheck|output)))

#define cp createParameters    
#define af admisLevelFunctional
    const Ordinal& zero = Ordinal::zero ;
    const Ordinal& one = Ordinal::one ;
    const Ordinal& omega = Ordinal::omega ;
    // const Ordinal& eps0 = Ordinal::eps0 ;
    // const Ordinal& omega1CK = Ordinal::omega1CK ;

    NM_EXAMP(af(zero,zero,cp(&one)));
    NM_EXAMP(af(zero,one,cp(&one,&zero)));
    NM_EXAMP(af(one,zero,cp(&one,&one,&zero)));
    NM_EXAMP(af(one,zero));
    NM_EXAMP(af(one,zero,NULL,eps0));
    NM_EXAMP(af(one,zero,NULL,Ordinal::five));
    NM_EXAMP(af(one,omega1CK,cp(&one)));
    NM_EXAMP(af(one,one,cp(&one,&omega1CK)));
    NM_EXAMP(af(one,Ordinal::two,
        cp(&one,&omega,&zero)));
    NM_EXAMP(af(omega,omega,cp(&one,&omega1CK,&zero,&zero)));
    NM_EXAMP(af(omega1CK,omega));
    NM_EXAMP(af(one,omega,cp(&iterativeFunctional(omega))));
    NM_EXAMP(af(af(one,zero),zero,NULL,zero));
    //CPP_EXAMP(af(af(one,zero)+1,zero,NULL,omega));
    NM_EXAMP(af(Ordinal::two,zero,NULL,zero,Ordinal::two));
    NM_EXAMP(af(Ordinal::omega,zero,NULL,zero,Ordinal::three));
    NM_EXAMP(af(omega,zero,NULL,zero,omega));
    NM_EXAMP(af(Ordinal::two,omega1CK,cp(&one),zero,Ordinal::two));
    NM_EXAMP(af(omega,omega,cp(&one,&omega1CK,&zero),zero,one));

#undef af
#undef cp
#undef NM_EXAMP
}


static void admisExampCalc()
{
    string tname = "figAdmisCppExampCalc" ;
    string iname = "admisCppExampCalcIns" ;
    string fname = tname;
    {
        fname += ".tex" ;
        ofstream outStream(fname.c_str());
        OutStream::streamManager.push(outStream);

        outStream << "\\begin{figure}\\small\\centering\n" ;
        outStream << "\\input{" << iname << "}\n" ;
    

        outStream << "\\normalsize\n" ; 
        outStream <<
    "\\caption{Defining \\Indextt{AdmisLevOrdinal}s with \\Indextt{cppList}}\n"
        << "\\label{FigAdmisCppList}\n" ;
        outStream << "\\end{figure}\n" ;
        OutStream::streamManager.pop();

    }
    fname = iname ;
    fname += ".sord" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);


    list<LabeledOrdinal*> labOrds;
    int limit = 5 ;
    int count = 0 ;
    outStream << "name\n" ;
    LabeledOrdinal::cppExampNames(labOrds);
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter,count++) {
        if (count >= limit) break ;
        outStream << ((*iter)->ord).normalForm()  << "\n" ;

    }
    outStream << "cppList \"" << iname << ".tex\"\n" << "quit\n" ;
    OutStream::streamManager.pop();



    
}


static void admisExamp()
{
    string tname = "tabAdmisCppExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);

// #define CPP_EXAMP(str) outStream << "{\\tt " << "\\verb#" << #str <<"#" \
//   << "}&$" << (str).texNormalForm()  << "$\\\\  \n"


#define CPPN_EXAMP(str,ord) outStream << "{\\tt " << "\\verb#" << str <<"#" \
    << "}&$" /* << (ord).texNormalForm() */ << "$\\\\  \n"

    outStream << "\\begin{table}\\centering\n" ;
    outStream << "\\begin{tabular}{|l|l|}\\hline\n" ;

    outStream << "\\multicolumn{2}{|c|}{`{\\tt cp}' stands for " <<
        " {\\tt createParameters} and `{\\tt af}' stands for " <<
        "{\\tt admisLevelFunctional}}\\\\ \\hline \\hline \n" ;
    outStream <<
        "{\\bf \\Cpp{} code examples} & {\\bf Ordinal}\\\\ \\hline \\hline\n" ;
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::cppExampNames(labOrds);
    for (list <LabeledOrdinal*>::iterator iter = labOrds.begin();
        iter != labOrds.end();++iter) {
        outStream << "{\\tt " << "\\verb#" << (*iter)->name <<"#"  <<
            "}&$"  << ((*iter)->ord).texNormalForm()  << "$\\\\  \n" ;

        // CPPN_EXAMP((*iter)->name,(*iter)->ord);
    }

    /*
    CPP_EXAMP(af(zero,zero,cp(&one)));
    CPP_EXAMP(af(zero,one,cp(&one,&zero)));
    CPP_EXAMP(af(one,zero,cp(&one,&one,&zero)));
    CPP_EXAMP(af(one,zero));
    CPP_EXAMP(af(one,zero,NULL,eps0));
    CPP_EXAMP(af(one,zero,NULL,Ordinal::five));
    CPP_EXAMP(af(one,omega1CK,cp(&one)));
    CPP_EXAMP(af(one,one,cp(&one,&omega1CK)));
    CPP_EXAMP(af(one,Ordinal::two,
        cp(&one,&omega,&zero)));
    CPP_EXAMP(af(omega,omega,cp(&one,&omega1CK,&zero,&zero)));
    CPP_EXAMP(af(omega1CK,omega));
    CPP_EXAMP(af(one,omega,cp(&iterativeFunctional(omega))));
    CPP_EXAMP(af(af(one,zero)+1,zero,NULL,omega));
    CPP_EXAMP(af(Ordinal::two,zero,NULL,zero,Ordinal::two));
    CPP_EXAMP(af(Ordinal::omega,zero,NULL,zero,Ordinal::three));
    CPP_EXAMP(af(omega,zero,NULL,zero,omega));
    CPP_EXAMP(af(Ordinal::two,omega1CK,cp(&one),zero,Ordinal::two));
    CPP_EXAMP(af(omega,omega,cp(&one,&omega1CK,&zero),zero,one));
    */

    outStream << "\\hline\n" ;
    outStream << "\\end{tabular}\n" ;
    outStream<<"\\caption{{\\tt admisLevelFunctional} \\Cpp{} code examples}\n";
    outStream << "\\mindex{{\\tt admisLevelFunctional} C{\\tt ++} examples}\n" ;
    outStream <<
        "\\mindex{examples {\\tt admisLevelFunctional} C{\\tt ++} code}\n" ;
    outStream << "\\label{TabAdmisLevOrdinalCppExamp}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();
#undef af
#undef cp
#undef CPPN_EXAMP
// #undef CPP_EXAMP
}




void ord::admisLimitEle(bool testFlag )
{
    const Int indicies[] = {1,2,3,-1};
    
    const Ordinal expI=(admisLevelFunctional(one,one)^(admisLevelFunctional(one,one)+1));

    const Ordinal & omega1CKp1 = omega1CK+1 ;
    const Ordinal & o1ckt4 = omega1CK*4 ;
    const Ordinal & o1cksq = omega1CK*omega1CK ;
    const Ordinal & bg1 = admisLevelFunctional(eps0,omega);
    const Ordinal & off1 = omega1CK*omega ;
    const Ordinal & sum1 = bg1 + off1 ;
    const Ordinal & w1xw = omega1CK*omega ;
    const Ordinal & w1x2 = omega1CK*Ordinal::two ;
    const Ordinal & w2dd = admisLevelFunctional(Ordinal::two,zero,NULL,
        omega1CK);
    const Ordinal & wxx = admisLevelFunctional(Ordinal::two,zero,NULL,
        w2dd);
    const Ordinal& five = * new Ordinal(5);
    const Ordinal& twelve = * new Ordinal(12);
    const Ordinal* ordAry [] = {
        
        
        &admisLevelFunctional(omega,zero),
        &omega1CK,
        &finiteFunctional(omega1CK,one,zero,zero),
        &finiteFunctional(createParameters(&omega1CKp1,&one)),
        &admisLevelFunctional(one,zero,NULL,Ordinal::one),
        &admisLevelFunctional(one,zero,NULL,Ordinal::two),
        &admisLevelFunctional(one,zero,NULL,Ordinal::omega),
        &admisLevelFunctional(Ordinal::two,zero,NULL,omega1CK),
        & w2dd,
        & wxx ,
        &o1ckt4,
        &o1cksq,
        &admisLevelFunctional(Ordinal::five,zero,createParameters(&one),
            Ordinal::zero, Ordinal::four),
        &admisLevelFunctional(one,zero,createParameters(&one,&one)),
        &admisLevelFunctional(one,zero,createParameters(&one,&zero,&one)),
        &admisLevelFunctional(one,zero,createParameters(&one,&one,&zero)),
        &admisLevelFunctional(one,zero,createParameters(&eps0, &zero)),
        &admisLevelFunctional(one,zero,createParameters(&eps0, &one, &zero)),
        &admisLevelFunctional(one,zero,createParameters(&eps0, &one)),
        &admisLevelFunctional(twelve,zero,NULL,zero,five),
        &admisLevelFunctional(twelve,zero,NULL,Ordinal::three,Ordinal::five),
        0
    };
    if (!testFlag) {
    Ordinal::limitElementTable(ordAry,indicies,"AdmisLevOrdinal",
        1,"\\small");
    // Ordinal::limitTypeTable(ordAry,"AdmisLevOrdinal", 1,NULL);
    } else Validate::testOrdinalAry(ordAry);
}

void ord::admisLimitEle2(bool testFlag)
{
    const Int indicies[] = {1,2,3,-1};
    
    const Ordinal eps0Pw =
        * new Ordinal(eps0.getImpl().addLoc(OrdinalImpl::omega));

    const Ordinal* ordAry [] = {
        
        &admisLevelFunctional(one,one,createParameters(&one)),
        &admisLevelFunctional(Ordinal::two,one,createParameters(&one)),
        
        &admisLevelFunctional(one,Ordinal::three,createParameters(&one)),
        
        &admisLevelFunctional(one,Ordinal::three,
            createParameters(&Ordinal::five)),
        
        &admisLevelFunctional(one,one,createParameters(&one,&zero)),
        
        &admisLevelFunctional(one,Ordinal::three,createParameters(&one,&zero)),
        
        &admisLevelFunctional(one,Ordinal::three,
            createParameters(&Ordinal::five,&zero)),
        
        &admisLevelFunctional(one,one,createParameters(&one,&zero,&zero)),
        
        &admisLevelFunctional(one,Ordinal::three,
            createParameters(&one,&zero,&zero)),
        
        &admisLevelFunctional(one,Ordinal::three,
            createParameters(&Ordinal::two,&zero,&zero)),
        
        &admisLevelFunctional(one,eps0,createParameters(&one)),
        
        &admisLevelFunctional(one,eps0+one,createParameters(&one)),
        
        &admisLevelFunctional(one,eps0Pw,createParameters(&Ordinal::three)),
        
        &admisLevelFunctional(one,one,createParameters(&one)),
        
        &admisLevelFunctional(one,eps0,createParameters(&one)),
        &admisLevelFunctional(one,eps0Pw,createParameters(&one)),
        
        &admisLevelFunctional(one,eps0,createParameters(&Ordinal::five)),
        
        &admisLevelFunctional(one,eps0+Ordinal::one,
            createParameters(&Ordinal::five)),
        
        &admisLevelFunctional(one,eps0,createParameters(&Ordinal::five)),
        
        &admisLevelFunctional(one,zero,createParameters(&one,&one)),
        
        &admisLevelFunctional(one,zero,createParameters(&Ordinal::two)),
        
        &admisLevelFunctional(one,one),
        &admisLevelFunctional(one,one,createParameters(&one)),
        &admisLevelFunctional(one,Ordinal::three),
        &admisLevelFunctional(one,one,createParameters(&omega,&one)),
        &admisLevelFunctional(one,omega,createParameters(&one)),
        0
    };
    if (!testFlag) 
    Ordinal::limitElementTable(ordAry,indicies,"AdmisLevOrdinal",
        2,"\\footnotesize");
    else Validate::testOrdinalAry(ordAry);
}



void ord::admisLimitEle3(bool testFlag)
{
    const Int indicies[] = {1,2,3,-1};
    /*
        const Ordinal & omega1CKp1 = omega1CK+1 ;
    const Ordinal & o1ckt4 = omega1CK*4 ;
    const Ordinal & o1cksq = omega1CK*omega1CK ;
    const Ordinal & bg1 = admisLevelFunctional(eps0,omega);
    const Ordinal & off1 = omega1CK*omega ;
    const Ordinal & sum1 = bg1 + off1 ;
    const Ordinal & w1xw = omega1CK*omega ;
    const Ordinal & w1x2 = omega1CK*Ordinal::two ;
    const Ordinal & wp1 = * new Ordinal(Ordinal::omega+Ordinal::one);
    const Ordinal* ordAry [] = {
        &w1xw,
        &w1x2,
        &admisLevelFunctional(eps0,zero,createParameters(&one)),
        &admisLevelFunctional(eps0,zero,createParameters(&Ordinal::two)),
        
        &admisLevelFunctional(eps0,zero,createParameters(&Ordinal::omega)),
        &admisLevelFunctional(eps0,zero,NULL,zero,wp1),
        &admisLevelFunctional(eps0+Ordinal::three,zero,NULL,zero,omega+one),
        
        &admisLevelFunctional(eps0+one,zero,createParameters(&one)),
        &admisLevelFunctional(eps0+Ordinal::five,zero,NULL,zero,
            eps0+Ordinal::three),
        &sum1,
        &admisLevelFunctional(one,omega,createParameters(&one)),
        &admisLevelFunctional(one,omega,createParameters(&Ordinal::omega)),
        
        &admisLevelFunctional(one,Ordinal::two,createParameters(&eps0)),
        
        &admisLevelFunctional(one,one,createParameters(&Ordinal::two)),
        &admisLevelFunctional(one,one,createParameters(&eps0)),
        &admisLevelFunctional(one,one,createParameters(&one,&zero,&zero)),
        &admisLevelFunctional(one,Ordinal::three,createParameters(&one,&zero,&zero)),
        &admisLevelFunctional(one,one,createParameters(&omega,&one)),
        &admisLevelFunctional(one,one,createParameters(&omega,&one,&zero)),
        &admisLevelFunctional(one,eps0),
        
        

        &admisLevelFunctional(one,finiteFunctional(one,zero,zero),
            createParameters(&one,&zero)),
        &admisLevelFunctional(one,finiteFunctional(one,zero,zero),
            createParameters(&eps0)),
        &admisLevelFunctional(one,finiteFunctional(one,zero,zero),
            createParameters(&eps0,&zero)),
        &admisLevelFunctional(one,finiteFunctional(one,zero,zero),
            createParameters(&eps0,&one)),
         &admisLevelFunctional(one,finiteFunctional(one,zero,zero),
            createParameters(&eps0,&one,&one)),
        &admisLevelFunctional(one,one),
        
        
        &admisLevelFunctional(one,Ordinal::three),
        
        &admisLevelFunctional(one,Ordinal::four,NULL),
        0
    };
    */

	//a = ( w^( omega_{ 1} + 1 ) )
	const Ordinal& a = expFunctional(( * new Ordinal(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::one))))	;


	//b = (omega_{ 1}*2)
	const Ordinal& b = * new Ordinal (admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl().multLoc(OrdinalImpl::two))	;


	//ba = omega_{ 1, 1}
	const Ordinal& ba = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		NULL
	)	;


	//bb = omega_{ 1, 3}
	const Ordinal& bb = admisLevelFunctional(
		Ordinal::one,
		Ordinal::three,
		NULL
	)	;


	//bc = omega_{ 1, 4}
	const Ordinal& bc = admisLevelFunctional(
		Ordinal::one,
		Ordinal::four,
		NULL
	)	;


	//c = omega_{ epsilon( 0)}(1)
	const Ordinal& c = admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		Ordinal::zero,
		createParameters(
			&(Ordinal::one))
	)	;


	//d = omega_{ epsilon( 0)}(2)
	const Ordinal& d = admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		Ordinal::zero,
		createParameters(
			&(Ordinal::two))
	)	;


	//e = omega_{ epsilon( 0)}(w)
	const Ordinal& e = admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		Ordinal::zero,
		createParameters(
			&(expFunctional(Ordinal::one)))
	)	;


	//f = [[w + 1]]omega_{ epsilon( 0)}
	const Ordinal& f = admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))), Embeddings::paramRestrict))
	)	;


	//g = [[w + 1]]omega_{ epsilon( 0) + 3}
	const Ordinal& g = admisLevelFunctional(
		( * new Ordinal(psi( Ordinal::one, Ordinal::zero).getImpl()
	.addLoc(Ordinal::three))),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	.addLoc(Ordinal::one))), Embeddings::paramRestrict))
	)	;


	//h = omega_{ epsilon( 0) + 1}(1)
	const Ordinal& h = admisLevelFunctional(
		( * new Ordinal(psi( Ordinal::one, Ordinal::zero).getImpl()
	.addLoc(Ordinal::one))),
		Ordinal::zero,
		createParameters(
			&(Ordinal::one))
	)	;


	//i = [[epsilon( 0) + 3]]omega_{ epsilon( 0) + 5}
	const Ordinal& i = admisLevelFunctional(
		( * new Ordinal(psi( Ordinal::one, Ordinal::zero).getImpl()
	.addLoc(Ordinal::five))),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(( * new Ordinal(psi( Ordinal::one, Ordinal::zero).getImpl()
	.addLoc(Ordinal::three))), Embeddings::paramRestrict))
	)	;


	//j = omega_{ epsilon( 0), w} + ( w^( omega_{ 1} + 1 ) )
	const Ordinal& j = ( * new Ordinal(admisLevelFunctional(
		psi( Ordinal::one, Ordinal::zero),
		expFunctional(Ordinal::one),
		NULL
	).getImpl()
	.addLoc(expFunctional(( * new Ordinal(admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL
	).getImpl()
	.addLoc(Ordinal::one)))))))	;


	//k = omega_{ 1, w}(1)
	const Ordinal& k = admisLevelFunctional(
		Ordinal::one,
		expFunctional(Ordinal::one),
		createParameters(
			&(Ordinal::one))
	)	;


	//l = omega_{ 1, w}(w)
	const Ordinal& l = admisLevelFunctional(
		Ordinal::one,
		expFunctional(Ordinal::one),
		createParameters(
			&(expFunctional(Ordinal::one)))
	)	;


	//m = omega_{ 1, 2}(epsilon( 0))
	const Ordinal& m = admisLevelFunctional(
		Ordinal::one,
		Ordinal::two,
		createParameters(
			&(psi( Ordinal::one, Ordinal::zero)))
	)	;


	//n = omega_{ 1, 1}(2)
	const Ordinal& n = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(Ordinal::two))
	)	;


	//o = omega_{ 1, 1}(epsilon( 0))
	const Ordinal& o = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(psi( Ordinal::one, Ordinal::zero)))
	)	;


	//p = omega_{ 1, 1}(1, 0, 0)
	const Ordinal& p = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(Ordinal::one),
			&(Ordinal::zero),
			&(Ordinal::zero))
	)	;


	//q = omega_{ 1, 3}(1, 0, 0)
	const Ordinal& q = admisLevelFunctional(
		Ordinal::one,
		Ordinal::three,
		createParameters(
			&(Ordinal::one),
			&(Ordinal::zero),
			&(Ordinal::zero))
	)	;


	//r = omega_{ 1, 1}(w, 1)
	const Ordinal& r = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(expFunctional(Ordinal::one)),
			&(Ordinal::one))
	)	;


	//s = omega_{ 1, 1}(w, 1, 0)
	const Ordinal& s = admisLevelFunctional(
		Ordinal::one,
		Ordinal::one,
		createParameters(
			&(expFunctional(Ordinal::one)),
			&(Ordinal::one),
			&(Ordinal::zero))
	)	;


	//t = omega_{ 1, epsilon( 0)}
	const Ordinal& t = admisLevelFunctional(
		Ordinal::one,
		psi( Ordinal::one, Ordinal::zero),
		NULL
	)	;


	//u = omega_{ 1, gamma( 0 )}(1, 0)
	const Ordinal& u = admisLevelFunctional(
		Ordinal::one,
		finiteFunctional(
		Ordinal::one,
		Ordinal::zero,
		Ordinal::zero),
		createParameters(
			&(Ordinal::one),
			&(Ordinal::zero))
	)	;


	//v = omega_{ 1, gamma( 0 )}(epsilon( 0))
	const Ordinal& v = admisLevelFunctional(
		Ordinal::one,
		finiteFunctional(
		Ordinal::one,
		Ordinal::zero,
		Ordinal::zero),
		createParameters(
			&(psi( Ordinal::one, Ordinal::zero)))
	)	;


	//x = omega_{ 1, gamma( 0 )}(epsilon( 0), 0)
	const Ordinal& x = admisLevelFunctional(
		Ordinal::one,
		finiteFunctional(
		Ordinal::one,
		Ordinal::zero,
		Ordinal::zero),
		createParameters(
			&(psi( Ordinal::one, Ordinal::zero)),
			&(Ordinal::zero))
	)	;


	//y = omega_{ 1, gamma( 0 )}(epsilon( 0), 1)
	const Ordinal& y = admisLevelFunctional(
		Ordinal::one,
		finiteFunctional(
		Ordinal::one,
		Ordinal::zero,
		Ordinal::zero),
		createParameters(
			&(psi( Ordinal::one, Ordinal::zero)),
			&(Ordinal::one))
	)	;


	//z = omega_{ 1, gamma( 0 )}(epsilon( 0), 1, 1)
	const Ordinal& z = admisLevelFunctional(
		Ordinal::one,
		finiteFunctional(
		Ordinal::one,
		Ordinal::zero,
		Ordinal::zero),
		createParameters(
			&(psi( Ordinal::one, Ordinal::zero)),
			&(Ordinal::one),
			&(Ordinal::one))
	)	;

    const Ordinal * ordAry[]= {&a,&b,&c,&d,&e,&f,&g,&h,&i,&j,&k,&l,&m,&n,&o,&p,
        &q,&r,&s,&t,&u,&v,&x,&y,&z,&ba,&bb,&bc,NULL} ;

    if (!testFlag) {
        Ordinal::limitElementTable(ordAry,indicies,"AdmisLevOrdinal",3,
        "\\small");
        // Ordinal::limitTypeTable(ordAry,"AdmisLevOrdinal",2, NULL);
    } else Validate::testOrdinalAry(ordAry);
    /*
    } else {
        outStream() << "NORMARFORMX\n" ;
        for ( const Ordinal ** ord=ordAry; *ord;ord++) {
            outStream() << (*ord)->normalForm() << "\n" ;
        }
    }
    */
}

static void admisLimitOrd()
{
    const Ordinal * const indicies[] = {
        &omega,&eps0,&omega1CK,
        
        NULL};
    /*
    const Ordinal expI=(admisLevelFunctional(one,one)^(admisLevelFunctional(one,one)+1));

    const Ordinal & bga = admisLevelFunctional(omega1CK+Ordinal::one,zero) ;
    const Ordinal & bge = admisLevelFunctional(omega^omega,bga) ;
    const Ordinal & bgw = admisLevelFunctional(100,zero);
    const Ordinal & o1ckt4 = omega1CK*4 ;
    const Ordinal & o1cksq = omega1CK*omega1CK ;
    const Ordinal & bg1 = admisLevelFunctional(eps0,omega);
    const Ordinal & off1 = omega1CK*omega ;
    const Ordinal & sum1 = bg1 + off1 ;
    const Ordinal & omega4 = omega*4 ;
    const Ordinal* ordAry [] = {
        &omega1CK,
        &admisLevelFunctional(Ordinal::two,zero),
        &o1ckt4,
        &o1cksq,
        &admisLevelFunctional(bge,zero,createParameters(&bge)),
        &admisLevelFunctional(omega1CK,zero,createParameters(&Ordinal::two,
            &bga)),
        &admisLevelFunctional(one,omega1CK),
        &admisLevelFunctional(one,bgw),
        &admisLevelFunctional(one,one,createParameters(&omega1CK)),
        &admisLevelFunctional(one,Ordinal::three,createParameters(&omega1CK)),
        &admisLevelFunctional(eps0,zero,createParameters(&omega1CK)),
        &admisLevelFunctional(eps0+one,zero,createParameters(&one)),
        &sum1,
        
        0
    };
    */
    /*
    ofstream out("temp.sord");
    for (const Ordinal ** ords= ordAry; * ords; ords++)
        out << (*ords)->normalForm() << "\n" ;
    */
    // Ordinal::limitOrdTable(ordAry,indicies,"AdmisLevOrdinal");
    LabeledOrdinal::limitOrdTable(LabeledOrdinal::admisLimitOrdExampleNames,
        indicies,"AdmisLevOrdinal");

}



static void admisArithExamp()
{
    const Ordinal&a1 = admisLevelFunctional(one,zero);
    const Ordinal&a3 = a1 + admisLevelFunctional(Ordinal::three,one,
        createParameters(&one,&zero,&one),zero,one);
    const char * cName = "AdmisLevOrdinal" ;
    const Ordinal * const am[] = {
        &a1,
        &admisLevelFunctional(zero,Ordinal::three),
        &a3,
        &admisLevelFunctional(one,omega,createParameters(&omega,&one)),
        &admisLevelFunctional(one,eps0,createParameters(&omega,&one,&zero)),
        &admisLevelFunctional(eps0,zero),


        NULL
    };

    Ordinal::arithExamp(am,cName,Ordinal::multType);

    const Ordinal * const * bm = am ;

    Ordinal::arithExamp(bm,cName,Ordinal::powerType);

}

const static int ddCol = 2 ;
const static int ddOff = 2 ;

static void admisDrillDownLine(const Ordinal& ord, ostream&out)
{
    out << "$" << ord.texNormalForm() << "$\n" ;
    for (int i = 0; i < ddCol ; i++) out << "&$" <<
        ord.limitElement(i+ddOff).texNormalForm() << "$\n" ;
    out << "\\\\ \\hline\n" ;

}
/*
static void admisNestedCollapsingExamp()
{
    string tname = "tabAdmisNestedCollapsingDef" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);


    outStream << "\\begin{table}\\centering\\small\n" ;
    outStream << "\\begin{tabular}{|c|";
    for (int i = 0; i < ddCol ; i++) outStream << "c|" ;
    outStream << "}\\hline\n" ;

    outStream << "{\\bf Ordinal }&\\multicolumn{" << ddCol <<
        "}{|c|}{\\bf Limit elements}\\\\ \\hline\n" ;
    for (int i = 0; i < ddCol ; i++) outStream << "& " << (i+ddOff) ;
    outStream << "\\\\ \\hline\n" ;

    const Ordinal& w2CK = admisLevelFunctional(Ordinal::two,zero);
    const Ordinal & tst2 = admisLevelFunctional(Ordinal::two,zero) ;
    const Ordinal& n2 = admisLevelFunctional(Ordinal::three,zero,NULL,w2CK);
    admisDrillDownLine( n2,outStream);
    const Ordinal& n1_n2 = admisLevelFunctional(Ordinal::three,zero,NULL,n2);
    admisDrillDownLine(n1_n2,outStream);
    const Ordinal& n1_n2_l3=n1_n2.limitElement(3);
    admisDrillDownLine(n1_n2_l3,outStream);
    admisDrillDownLine(n1_n2_l3.limitElement(2),outStream);

    const Ordinal * plist[] = {
        &eps0,
        
        &Ordinal::two,
        NULL
    };

    const Ordinal & cxl2 = admisLevelFunctional(Ordinal::two,eps0,plist);
    const Ordinal & l2cxl2 = admisLevelFunctional(Ordinal::three,zero,NULL,cxl2);

    admisDrillDownLine(l2cxl2,outStream);

    const Ordinal & l1xx = admisLevelFunctional(Ordinal::three,zero,NULL,
        l2cxl2);

    admisDrillDownLine(l1xx,outStream);

    Ordinal twelve(12);

    const Ordinal& w5CK = admisLevelFunctional(Ordinal::four,zero);
    const Ordinal& w5CKc =admisLevelFunctional(Ordinal::five,zero,NULL,w5CK);
    const Ordinal& w4CKc =admisLevelFunctional(Ordinal::six,zero,NULL,w5CKc);
    const Ordinal& w3CKc =admisLevelFunctional(Ordinal::six,zero,NULL,w4CKc);
    const Ordinal& w2CKc =admisLevelFunctional(Ordinal::six,zero,NULL,w3CKc);
    const Ordinal& w1CKc =admisLevelFunctional(twelve,zero,NULL,w2CKc);

    const Ordinal & bga = admisLevelFunctional(omega1CK,zero);
    const Ordinal &btrm = w2CK+psi(one,omega)+Ordinal::four;
    const Ordinal & bgb = admisLevelFunctional(btrm,zero)+Ordinal::five;

    admisDrillDownLine(w4CKc,outStream);
    admisDrillDownLine(w1CKc,outStream);
    admisDrillDownLine(w1CKc.limitElement(2),outStream);
    admisDrillDownLine(w3CKc.limitOrd(omega),outStream);
   admisDrillDownLine(admisLevelFunctional(bgb,zero,NULL,btrm),outStream);

    const Ordinal & op1 = omega+one ;
    const Ordinal & ep1 = eps0+one ;
    const Ordinal * bases[] = {
        &(admisLevelFunctional(Ordinal::two,zero,NULL,omega1CK)),
        &(admisLevelFunctional(Ordinal::three,zero,NULL,w2CK)),
        &(admisLevelFunctional(omega1CK+one,zero,NULL,op1)),
        &(admisLevelFunctional(omega1CK+one,zero,NULL,ep1)),
        
        
        NULL
    };

    const Ordinal * ordc = NULL ;
    for (const Ordinal * const * b = bases; *b ; b++) {
        const Ordinal & ba = ** b ;
        admisDrillDownLine(ba,outStream);
        admisDrillDownLine(*(ordc=new Ordinal(ba.limitElement(3))),outStream);
        admisDrillDownLine(*new Ordinal(ordc->limitElement(2)),outStream);

    }
    
    outStream << "\\end{tabular}\n" ;
    outStream<<"\\caption{{\\tt AdmisLevOrdinal} nested collapsing examples }\n";
    outStream<<"\\mindex{{\\tt AdmisLevOrdinal} nested collapsing examples }\n";
    outStream<<"\\mindex{nested collapsing examples}\n";
    outStream<<"\\mindex{collapsing examples, nested}\n";
    outStream<<"\\mindex{examples {\\tt AdmisLevOrdinal} nested collapsing}\n";
    outStream << "\\label{TabAdmisLevNestedCollapsingDef}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();



}
*/

static void admisDrillDownDefExamp()
{
    string tname = "tabAdmisDrillDownDef" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);


    outStream << "\\begin{table}\\centering\\small\n" ;
    outStream << "\\begin{tabular}{|c|";
    for (int i = 0; i < ddCol ; i++) outStream << "c|" ;
    outStream << "}\\hline\n" ;

    outStream << "{\\bf Ordinal }&\\multicolumn{" << ddCol <<
        "}{|c|}{\\bf Limit elements}\\\\ \\hline\n" ;
    for (int i = 0; i < ddCol ; i++) outStream << "& " << (i+ddOff) ;
    outStream << "\\\\ \\hline\n" ;

    const Ordinal &a1 = omega1CK.limitElement(1);
    const Ordinal &a2 = omega1CK.limitElement(2);
    admisDrillDownLine( a1,outStream);
    admisDrillDownLine( a2,outStream);
    const Ordinal & tst2 = admisLevelFunctional(Ordinal::two,zero) ;
    admisDrillDownLine( tst2.limitElement(2),outStream);
    admisDrillDownLine( tst2.limitElement(3),outStream);
    const Ordinal & bga = admisLevelFunctional(omega1CK,zero);
    const Ordinal& w2CK = admisLevelFunctional(Ordinal::two,zero);
    
    const Ordinal &btrm = w2CK+psi(one,omega);
    const Ordinal & bgb = admisLevelFunctional(btrm,zero);
    const Ordinal * bases[] = {
        &(admisLevelFunctional(Ordinal::two,zero,NULL,omega1CK)),
        &(admisLevelFunctional(Ordinal::three,zero,NULL,w2CK)),
        &bgb,
        &btrm,
        
        NULL
    };

    for (const Ordinal * const * b = bases; *b ; b++) {
        const Ordinal & ba = ** b ;
        admisDrillDownLine(ba,outStream);
        admisDrillDownLine(ba.limitElement(2),outStream);
        if (b != bases+2) admisDrillDownLine(ba.limitElement(3),outStream);

    }
    outStream << "\\end{tabular}\n" ;
    outStream<<"\\caption{{\\tt AdmisLevOrdinal} collapsing examples }\n";
    outStream<<"\\mindex{{\\tt AdmisLevOrdinal} collapsing examples }\n";
    outStream<<"\\mindex{examples {\\tt AdmisLevOrdinal} collapsing}\n";
    outStream << "\\label{TabAdmisLevDrillDownDef}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();
}

static void limitExampLine(const Ordinal &ord, int rule, ostream &out)
{
    out << "$" << ord.texNormalForm() << "$&$"
        << ord.limitType().texNormalForm() << "$&" << rule << "\\\\ \\hline\n" ;
}

/*
static void admisLimitTypeExamp()
{
    const Ordinal & w4 = * new AdmisLevOrdinal(Ordinal::four,zero);
    string tname = "tabAdmisLimitType" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);

    outStream << "\\begin{tabular}{|l|r|r|}\\hline\n" ;
    outStream << "\\multicolumn{3}{|c|}{\\bf Examples} \\\\ \\hline\\hline\n";
    outStream <<
    "$\\alpha$ & $\\alpha{\\tt .limitType()}$& Rule \\\\ \\hline\\hline\n";

    const Ordinal& e1 = ord::omega1CK ;
    limitExampLine(e1,1,outStream);

    const Ordinal& e2 = * new AdmisLevOrdinal(Ordinal::two,zero,NULL);
    limitExampLine(e2,1,outStream);

    const Ordinal& e2a = * new AdmisLevOrdinal(Ordinal::two,omega^omega,NULL);
    limitExampLine(e2a,2,outStream);

    const Ordinal& e2b = * new AdmisLevOrdinal(Ordinal::omega,zero,NULL);
    limitExampLine(e2b,2,outStream);

    const Ordinal& tx = * new AdmisLevOrdinal(omega^omega,Ordinal::four,NULL);
    const Ordinal& e2ba = * new AdmisLevOrdinal(tx,zero,NULL);
    limitExampLine(e2ba,2,outStream);

    const Ordinal &r4 = admisLevelFunctional(omega,Ordinal::five,
        createParameters(&Ordinal::three));
    limitExampLine(r4,4,outStream);

    const Ordinal& r5 = admisLevelFunctional(omega,omega1CK,createParameters(
        &Ordinal::four));
    limitExampLine(r5,5,outStream);


    const Ordinal& tx2 = * new AdmisLevOrdinal((omega^omega)+1,Ordinal::five);
    const Ordinal& e2ba2 = * new AdmisLevOrdinal(tx2,Ordinal::five,NULL);
    limitExampLine(e2ba2,3,outStream);

    const Ordinal& e2ba3 = * new AdmisLevOrdinal(w4,zero,createParameters(
        &Ordinal::three));
    limitExampLine(e2ba3,5,outStream);



    const Ordinal &s = omega+Ordinal::five ;
    const Ordinal& e2c = * new AdmisLevOrdinal(s,zero,NULL);
    limitExampLine(e2c,1,outStream);

    const Ordinal& e2d = * new AdmisLevOrdinal(omega,e2c,NULL);
    limitExampLine(e2d,2,outStream);

    const Ordinal &t = * new AdmisLevOrdinal((e1^e1)+Ordinal::six,zero,NULL) ;
    const Ordinal &e3 = * new AdmisLevOrdinal(t,zero,createParameters(
        &Ordinal::three, &Ordinal::five, &t));
    limitExampLine(e3,2,outStream);

    const Ordinal& ckIx = admisLevelFunctional(Ordinal::five,zero);
    const Ordinal& rule3 = admisLevelFunctional(ckIx,Ordinal::three);
    limitExampLine(rule3,3,outStream);

    const Ordinal &e4 = * new AdmisLevOrdinal(t,zero,NULL);
    limitExampLine(e4,2,outStream);

    const Ordinal &e5 = * new AdmisLevOrdinal(omega,e4,NULL);
    limitExampLine(e5,2,outStream);

    const Ordinal &t1 = e1+Ordinal::six ;
    const Ordinal &e6 = * new AdmisLevOrdinal(omega,t1,NULL);
    limitExampLine(e6,5,outStream);


    outStream << "\\end{tabular}\n" ;
    
    outStream<<"\\caption{{\\tt AdmisNormalElement::limitType}s}\n";
    outStream<<"\\index{{\\tt AdmisNormalElement::limitType}s}\n";
    outStream << "\\label{TabAdmisLimitType}\n" ;

    OutStream::streamManager.pop();
}
*/
static int lineNo = 1 ;

static void admisNeExLine(const Ordinal&ord , int n, ostream& str)
{
    static const Ordinal * prev = NULL ;
    if (n < 1 ) {
        prev= NULL;
        lineNo = 1 ;
        return ;
    }
    if (prev) assert (prev->compare(ord) < 0);
    prev = &ord ;
    str << lineNo++ <<  "& $" << ord.texNormalForm() ;
    for (int i = 0 ; i < n ; i++) str << " $&$ " <<
        ord.limitElement(i+1).texNormalForm()  ;
    str << "$\\\\\\hline\n" ;
}

static void writeLineRef(const char * label,const string& table)
{
    string labelStr =     "TabAdmisNestedEtaExamp" ;
    
    assert(texDefs) ;
    *texDefs << "\\newcommand{\\" << label << "}{" << lineNo  ;
    if (labelStr != table) *texDefs << "X" ;
    *texDefs << "}\n" ;
       //  << "-" << "\\ref{" << table << "}}\n" ;
}

static void admisNestedEtaExamp()
{
    const Ordinal& zero = Ordinal::zero ;
    string labelStr =     "TabAdmisNestedEtaExamp" ;
    string tname =       "tabAdmisNestedEtaExamp" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);

    int n = 3 ;
    int an = n+2 ;

    admisNeExLine(Ordinal::zero,0,outStream); // reset line count
    // outStream << "\\begin{table}\\centering\n" ;
    outStream << "\\begin{tabular}{|r|l|" ;
    for (int i = 0 ; i < n ; i++) outStream << "c|" ;
    outStream << "}\\hline\n" ;
    outStream << "{\\bf Rf} & {\\bf Ordinal} & \\multicolumn{" << n <<
        "}{|c|}{{\\tt limitElement}s}\\\\\\hline\\hline\n&" ;
    for (int i = 0 ; i < n ; i++) outStream << "&" <<  (i+1)  ;
    outStream << "\\\\\\hline\\hline\n" ;

    const Ordinal & aa = admisLevelFunctional(Ordinal::one,zero,NULL,
        Ordinal::one);
    writeLineRef("lnzoo",labelStr);
    admisNeExLine(aa,n,outStream);


    

          

	//e2 = [[1]]omega_{ 1}[[ 1]]
	const Ordinal& e2 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict, true))
	)	;

    admisNeExLine(e2,n,outStream);  

     
    const Ordinal& cdx1_3 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::three,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict,true))
	) ;
    writeLineRef("lnoot",labelStr);
    admisNeExLine(cdx1_3,n,outStream);

    //e1 = [[1]]omega_{ 1}
	const Ordinal& e1 = admisLevelFunctional(
		Ordinal::one,
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict))
	)	;

    admisNeExLine(e1,n,outStream);




    
    
    const Ordinal& cd2 = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::five,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict))
	) ;
    writeLineRef("lnotfv",labelStr);
    admisNeExLine(cd2,n,outStream);





    const Ordinal& cdt = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict,true))
	) ;
    writeLineRef("lnoto",labelStr);
    admisNeExLine(cdt,n,outStream);


    



    

        //
    //
    const Ordinal& cd2t = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::four,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict,true))
	) ;
    writeLineRef("lnotf",labelStr);
    admisNeExLine(cd2t,n,outStream);


     const Ordinal& cd2f = admisLevelFunctional(
		Ordinal::five,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::one, Embeddings::paramRestrict))
	) ;
    writeLineRef("lnofo",labelStr);

    admisNeExLine(cd2f,n,outStream);




    const Ordinal & bba = admisLevelFunctional(Ordinal::two,zero,NULL,
        Ordinal::one);
    admisNeExLine(bba,n,outStream);   

   



    const Ordinal & bb = admisLevelFunctional(Ordinal::two,zero,NULL,
        Ordinal::two);
    writeLineRef("lnztt",labelStr);
    admisNeExLine(bb,n,outStream);     


   

         
    
     const Ordinal& cdx = admisLevelFunctional(
		Ordinal::two,
		Ordinal::zero,
		NULL,
		Ordinal::one,
		(* new Embeddings(Ordinal::two, Embeddings::paramRestrict,true))
	) ;
    writeLineRef("lntto",labelStr);
    admisNeExLine(cdx,n,outStream);


    const Ordinal & bbc = admisLevelFunctional(Ordinal::three,zero,NULL,
        Ordinal::one);
    admisNeExLine(bbc,n,outStream); 







    const Ordinal & bbb = admisLevelFunctional(Ordinal::three,zero,NULL,
        Ordinal::two);
    admisNeExLine(bbb,n,outStream);  

    
    const Ordinal & cc = admisLevelFunctional(Ordinal::omega+Ordinal::one,zero,
        NULL, Ordinal::omega);
    admisNeExLine(cc,n,outStream);
    outStream << "\\end{tabular}\n" ;
    outStream<<"\\caption{\\Index{[[$\\delta$]]}, \\Index{[[$\\eta$]]}" <<
       " and \\Index{[[$\\eta$]]} parameter examples in increasing order}\n";
    outStream << "\\label{" << labelStr << "}\n" ;
    // outStream << "\\end{table}\n" ;

    OutStream::streamManager.pop();
}




static void admisDescribeNestedCollapse()
{
    string tname = "descrNestedCollapse" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);

    const Ordinal& d1Base = admisLevelFunctional(Ordinal::one,zero,NULL,zero,
        Ordinal::one);
   static const int lim = 5 ;
   const Ordinal * ords[lim-1] ;
   static const int innerLim = 5 ;
   static const Ordinal * ords2[innerLim-1][lim-1];
    
    outStream << "\\begin{table}\n\\centering\n\\begin{tabular}{|l|" ;
    for (int i = 1 ; i < lim ; i++) outStream << "l|" ;
    outStream << "}\\hline\\hline\n" ;
    outStream <<"$\\alpha$ & \\multicolumn{" << (lim-1) <<
        "}{|c|}{$\\alpha{\\tt .limitElement(}n{\\tt )}$}\\\\\\hline\n" ;
    outStream << "$n$ " ;
    for (int i = 1 ; i < lim ; i++) outStream << "& {\\bf " << i
        << "}" ;
    outStream << "\\\\\\hline\\hline\n";

    outStream << "$" << d1Base.texNormalForm() << "$\n"  ;
    for (int i = 1 ; i < lim; i++) outStream << "&$" <<
       (ords[i-1] = &(d1Base.limitElement(i)))->texNormalForm() << "$\n" ;
    outStream << "\\\\\\hline\n" ;

    for ( int i = 1 ; i < innerLim;i++)  {
        outStream << "$" << ords[i-1]->texNormalForm() << "$&" ;
        for (int j = 1 ; j < lim ; j++) {
            if ( j > 1) outStream << "&" ;
            outStream << "$" <<
                (ords2[i-1][j-1] = &(ords[i-1]->limitElement(j)))
                ->texNormalForm() << "$" ;
        }
        outStream << "\\\\\\hline\n" ;
    }
    for ( int i = 1 ; i < innerLim;i++)  {
        for (int j = 1 ; j < lim ; j++) {
            const Ordinal &ord = *(ords2[i-1][j-1]) ;
            outStream << "$" << ord.texNormalForm() << "$&" ;
            for (int j = 1 ; j < lim ; j++) {
                if ( j > 1) outStream << "&" ;
                outStream << "$" << ord.limitElement(j).texNormalForm()
                    << "$" ;
            }
            outStream << "\\\\\\hline\n" ;
        }
    }


    outStream << "\\end{tabular}\n" ;
    outStream <<"\\caption{Structure of $[[1]]\\omega_{1}$ }\n";
    outStream <<"\\index{nested examples}\n";
    outStream << "\\label{TabAdmisNestedDef}\n" ;
    outStream << "\\end{table}\n" ;



    OutStream::streamManager.pop();
}

static const int numLimElts = 3 ;
static void outCollLine(ostream& outStream, const Ordinal &ord, int num = numLimElts)
{
    static const int numLim=10 ;
    assert(numLim>= num);
    const Ordinal * ordAry [numLim] ;
    if (!ord.isZero()) {
        outStream  << "$" << ord.texNormalForm() << "$" ;
        for (int i = 1 ; i < num +1 ; i++) outStream << "&$" <<
            (ordAry[i] = &ord.limitElement(i))->texNormalForm() << "$" ;
    } else {
        const Ordinal * base = &one ;
        for (int i = 1 ; i < num + 1 ; i++) {
            base = &(admisLevelFunctional(*base,zero));
            const Ordinal & disp =
                admisLevelFunctional(*base,zero,NULL,zero, one);
            outStream  << "&$" << disp.texNormalForm() << "$";
        }
    }
    outStream << "\\\\\\hline\n" ;
    

}

static const int psiNumLimElts = 2;
static void outPsiLine(ostream& outStream, const Ordinal &ord,
    int psiNum=psiNumLimElts)
{
    static const int psiNumLim = 10 ;
    assert(psiNum <= psiNumLim);
    const Ordinal * ordAry [psiNumLim] ;
    outStream  << "$" << ord.texNormalForm() << "$&\n$" <<
        ord.psiNormalForm() << "\n" ;
    for (int i = 1 ; i < psiNum +1 ; i++) outStream << "$&\n$" <<
        (ordAry[i] = &ord.limitElement(i))->texNormalForm() ;
    outStream << "$\n\\\\\\hline\n" ;
}

static void outPsiRvLine(ostream& outStream, const Ordinal &ord,
    int psiNum=psiNumLimElts)
{
    static const int psiNumLim = 10 ;
    assert(psiNum <= psiNumLim);
    const Ordinal * ordAry [psiNumLim] ;
    outStream  << "$" << ord.psiNormalForm() << "$&\n$" <<
        ord.texNormalForm() << "\n" ;
    for (int i = 1 ; i < psiNum +1 ; i++) outStream << "$&\n$" <<
        (ordAry[i] = &ord.limitElement(i))->texNormalForm() ;
    outStream << "$\n\\\\\\hline\n" ;
}





static void admisCollapseConnect()
{
    string tname = "collapseConnect" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{table}\\centering\n\\begin{tabular}{|l|l|" ;
    for (int i = 1 ; i < numLimElts + 1 ; i++) outStream << "l|" ;
    outStream << "}\\hline\n" ;
    outStream << "\\multicolumn{2}{|c|}{\\bf Notation}&\n\\multicolumn{"
        << numLimElts << "}{|c|}{\\tt limitElement}\\\\\\hline\n" ;
    outStream << "{\\bf $\\Psi$ } & {$\\varphi\\ \\ \\omega$}" ;
    for (int i = 1 ; i < numLimElts + 1 ; i++) outStream << "&{\\bf "
        << i << "}" ;
    outStream << "\\\\\\hline\\hline\n" ;

    bool skipDup = true ;

    const Ordinal& psi1a = finiteFunctional(Ordinal::one,zero,zero);
    if (!skipDup) {
        outStream << "$\\Psi(\\Omega^{\\Omega})$&" ;
        outCollLine(outStream,psi1a);
    }
    outPsiRvLine(outStream,psi1a,numLimElts);

    const Ordinal& psi1b = finiteFunctional(Ordinal::one,zero,zero,zero);
    
    
    outPsiRvLine(outStream,psi1b,numLimElts);


    const Ordinal& psi1 = iterativeFunctional(Ordinal::one);
    
    
    outPsiRvLine(outStream,psi1,numLimElts);

    outStream << "$\\Psi(\\Omega^{\\Omega^{\\omega 2}})$&" ;
    const Ordinal& psi1_2 = iterativeFunctional(Ordinal::two);
    outCollLine(outStream,psi1_2);
    outPsiRvLine(outStream,psi1_2,numLimElts);

    const Ordinal& psi1_2w = iterativeFunctional(Ordinal::two,omega,12);
    
    
    outPsiRvLine(outStream,psi1_2w,numLimElts);

    const Ordinal& psi1_2w8 = iterativeFunctional(Ordinal::two,omega,12,8);
    outPsiRvLine(outStream,psi1_2w8,numLimElts);

    

    const Ordinal& psi1_w = iterativeFunctional(omega);
    
    
    outPsiRvLine(outStream,psi1_w,numLimElts);

    const Ordinal& psi1w = iterativeFunctional(omega^omega);
    
    
    outPsiRvLine(outStream,psi1w,numLimElts);

    const Ordinal& o11 = admisLevelFunctional(Ordinal::one,Ordinal::zero,
		NULL,Ordinal::one,Ordinal::zero);
    
    
    outPsiRvLine(outStream,o11,numLimElts);

    const Ordinal& o11_2=admisLevelFunctional(one,zero,NULL,Ordinal::two,zero);
    
    
    outPsiRvLine(outStream,o11_2,numLimElts);

    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega \\omega}})$&" ;
    const Ordinal& o11_w=admisLevelFunctional(one,zero,NULL,omega,zero);
    outCollLine(outStream,o11_w);
    outPsiRvLine(outStream,o11_w,numLimElts);

    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega^\\omega}})$&" ;
    const Ordinal& o11w=admisLevelFunctional(one,zero,NULL,zero,one);
    outCollLine(outStream,o11w);
    outPsiRvLine(outStream,o11w,numLimElts);

    const Ordinal& o113a=admisLevelFunctional(one,zero,
        createParameters(&Ordinal::three),zero,one);
    outPsiRvLine(outStream,o113a,numLimElts);

    const Ordinal& o113b=admisLevelFunctional(one,zero,
        createParameters(&Ordinal::five,&Ordinal::three),zero,one);
    outPsiRvLine(outStream,o113b,numLimElts);

    const Ordinal& o113c=admisLevelFunctional(one,zero,
        createParameters(&Ordinal::two,&Ordinal::zero,&Ordinal::zero),zero,one);
    outPsiRvLine(outStream,o113c,numLimElts);

    const Ordinal& o113=admisLevelFunctional(one,Ordinal::three,NULL,zero,one);
    outPsiRvLine(outStream,o113,numLimElts);

    const Ordinal& o11wwa=admisLevelFunctional(one,omega^omega,NULL,zero,one);
    outPsiRvLine(outStream,o11wwa,numLimElts);

    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega^{\\omega 2}}})$&" ;
    const Ordinal& o11w3=admisLevelFunctional(Ordinal::two,zero,NULL,one,one);
    outCollLine(outStream,o11w3);
    outPsiRvLine(outStream,o11w3,numLimElts);

    const Ordinal& o11w2=admisLevelFunctional(Ordinal::two,zero,NULL,zero,one);
    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega^{\\omega 2}}})$&" ;
    outCollLine(outStream,o11w2);
    outPsiRvLine(outStream,o11w2,numLimElts);

    const Ordinal& o11w2x=admisLevelFunctional(Ordinal::two,psi(omega^omega,zero)+one,
        NULL,zero,one);
    
    
    outPsiRvLine(outStream,o11w2x,numLimElts);

    const Ordinal& o11ww=admisLevelFunctional(omega,zero,NULL,zero,one);
    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega^{\\omega \\omega}}})$&" ;
    outCollLine(outStream,o11ww);
    outPsiRvLine(outStream,o11ww,numLimElts);

    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega^{\\Omega}}})$&" ;
    const Ordinal& ox1 = admisLevelFunctional(omega1CK,zero,NULL,zero,one);
    outCollLine(outStream,ox1);
    outPsiRvLine(outStream,ox1,numLimElts);

    const Ordinal& w2 = admisLevelFunctional(Ordinal::two,zero);
    outStream << "$\\Psi(\\Omega^{\\Omega^{\\Omega^{\\Omega^\\Omega}}})$&" ;
    const Ordinal& ox2 = admisLevelFunctional(w2,zero,NULL,zero,one);
    outCollLine(outStream,ox2);
    outPsiRvLine(outStream,ox2,numLimElts);

    const Ordinal & ww = admisLevelFunctional(omega,zero);
    outStream << "\\MIndex{$\\Psi(\\varepsilon_{\\Omega+1})$}&" ;
    const Ordinal& oxw = admisLevelFunctional(ww,zero,NULL,zero,one);
    outCollLine(outStream,oxw);

    outStream << "&" ;
    outCollLine(outStream,zero);
    

    outStream << "\\end{tabular}\n" ;
    outStream <<"\\caption{$\\Psi$ collapsing function with {\\tt limitElement}s}\n";
    outStream <<"\\index{$\\Psi$}\n";
    outStream << "\\label{TabAdmisConnPsi}\n" ;
    outStream << "\\end{table}\n" ;

    OutStream::streamManager.pop();
}





static void admisPsiTab()
{
    string tname = "admisPsi" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{table}\\centering\n\\begin{tabular}{|l|l|" ;
    for (int i = 1 ; i < psiNumLimElts + 1 ; i++) outStream << "l|" ;
    outStream << "}\\hline\n" ;
    outStream << "\\multicolumn{2}{|c|}{\\bf Notation}&\n\\multicolumn{" << psiNumLimElts <<
        "}{|c|}{\\tt limitElement}\\\\\\hline\n" ;
    outStream << "$\\varphi\\ \\ \\omega $&$ \\Psi$" ;
    for (int i = 1 ; i < psiNumLimElts + 1 ; i++)
        outStream << "&{\\bf " << i << "}" ;
    outStream << "\\\\\\hline\\hline\n" ;

    const Ordinal& o1 = psi(1,0);
    outPsiLine(outStream,o1);

    const Ordinal& o2 = psi(1,1);
    outPsiLine(outStream,o2);

    const Ordinal& o3 = psi(1,omega);
    outPsiLine(outStream,o3);

    const Ordinal& o2z = psi(2,0);
    outPsiLine(outStream,o2z);

    const Ordinal& o21 = psi(2,1);
    outPsiLine(outStream,o21);

    const Ordinal& o2w = psi(2,omega);
    outPsiLine(outStream,o2w);

    const Ordinal& o3z = psi(3,0);
    outPsiLine(outStream,o3z);

    const Ordinal& o9a = psi(3,5);
    outPsiLine(outStream,o9a);

    const Ordinal& o9 = psi(3,omega+5);
    outPsiLine(outStream,o9);

    const Ordinal& ox = psi(omega^omega,omega+5);
    outPsiLine(outStream,ox);

    const Ordinal& o4 = finiteFunctional(1,0,0);
    outPsiLine(outStream,o4);

    const Ordinal& o5 = finiteFunctional(1,omega,12);
    outPsiLine(outStream,o5);

    const Ordinal& o6 = finiteFunctional(omega*omega,omega,12);
    outPsiLine(outStream,o6);

    const Ordinal& o7 = finiteFunctional(1,0,0,0);
    outPsiLine(outStream,o7);

    

    const Ordinal * o = &Ordinal::one ;
    const Ordinal * z = &Ordinal::zero ;
    const Ordinal& o8 = finiteFunctional(createParameters(o,z,z,z,z));
    outPsiLine(outStream,o8);

    

    const Ordinal& p1 = iterativeFunctional(one);
    outPsiLine(outStream,p1);

    const Ordinal& p2 = iterativeFunctional(one,one);
    outPsiLine(outStream,p2);

    const Ordinal& ptwo = iterativeFunctional(Ordinal::two);
    outPsiLine(outStream,ptwo);

    const Ordinal& p4 = iterativeFunctional(Ordinal::four);
    outPsiLine(outStream,p4);

    const Ordinal& pwp1 = iterativeFunctional(omega+one);
    outPsiLine(outStream,pwp1);

    const Ordinal& p3 = iterativeFunctional(omega^omega,Ordinal::four,
        Ordinal::two,Ordinal::five);
    outPsiLine(outStream,p3);

    const Ordinal & pdd = admisLevelFunctional(one,zero,NULL,one,zero);
    outPsiLine(outStream,pdd);

    const Ordinal & pdd3 = admisLevelFunctional(one,zero,NULL,
        omega+Ordinal::three,zero);
    outPsiLine(outStream,pdd3);

    const Ordinal & pgww = admisLevelFunctional(one,zero,NULL,
        finiteFunctional(omega^omega,zero,zero),zero);
    outPsiLine(outStream,pgww);

    const Ordinal& xy = admisLevelFunctional(admisLevelFunctional(Ordinal::two,zero),
        zero,NULL,zero,one);
    outPsiLine(outStream,xy);

    const Ordinal &admadm = admisLevelFunctional(admisLevelFunctional(
        Ordinal::three,zero),zero,NULL,zero,one);
    outPsiLine(outStream,admadm);

    const Ordinal &admadm3 = admisLevelFunctional(admisLevelFunctional(
        Ordinal::three,Ordinal::four),zero,NULL,zero,one);
    outPsiLine(outStream,admadm3);

    const Ordinal &admadm3a = admisLevelFunctional(admisLevelFunctional(
        Ordinal::three,Ordinal::four,createParameters(&Ordinal::five)),
        zero,NULL,zero,one);
    outPsiLine(outStream,admadm3a);

    
    const Ordinal&ten = * new Ordinal(10);
    const Ordinal &ord10 = admisLevelFunctional(admisLevelFunctional(
        ten,zero),zero,NULL,zero,one);
    outPsiLine(outStream,ord10);

    

    outStream << "\\end{tabular}\n" ;
    outStream <<
        "\\caption{$\\Psi$ collapsing function with {\\tt limitElement}s 2}\n";
    outStream <<"\\index{$\\Psi$}\n";
    outStream << "\\label{TabAdmisPsi}\n" ;
    outStream << "\\end{table}\n" ;

    OutStream::streamManager.pop();
}


static void outPsiLimLine(ostream& outStream, const Ordinal &ord,
    int psiNum=psiNumLimElts)
{
    static int lineCount=0;
    static const int psiNumLim = 10 ;
    assert(psiNum <= psiNumLim);
    const Ordinal * ordAry [psiNumLim] ;
    outStream  << "&$" << ord.psiNormalForm() << "\n" ;
    for (int i = 1 ; i < psiNum +1 ; i++) outStream << "$&\n$" <<
        (ordAry[i] = &ord.limitElement(i))->psiNormalForm() ;
    
    outStream << "$\n\\\\\n" << ++lineCount << "&$" <<
        ord.texNormalForm() ;
    for (int i = 1 ; i < psiNum +1 ; i++) outStream << "$&\n$" <<
        ordAry[i]->texNormalForm() ;
    outStream << "$\n\\\\\\hline\\hline\n" ;
}




static void admisPsiLimTab()
{
    static const int numElts = 4 ;
    string tname = "admisLimPsi" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{table}\\centering{\\footnotesize\n" <<
        "\\begin{tabular}{|r|l|" ;
    for (int i = 1 ; i < numElts + 1 ; i++) outStream << "l|" ;
    outStream << "}\\hline\n" ;
    outStream << "&\\multicolumn{1}{|c|}{\\bf Notation}&\n" <<
        "\\multicolumn{" << numElts <<
        "}{|c|}{\\tt limitElement}\\\\\\hline\n" ;
    outStream << "{\\bf \\#}&$ \\Psi\\ /\\ \\varphi\\ \\ \\omega $" ;
    for (int i = 1 ; i < numElts + 1 ; i++)
        outStream << "&{\\bf " << i << "}" ;
    outStream << "\\\\\\hline\\hline\n" ;

    const Ordinal* ordAry[] = {
        
        &psi(Ordinal::two,zero),
        &psi(Ordinal::three,zero),
        &psi(omega,zero),
        &finiteFunctional(one,zero,zero),
        &finiteFunctional(one,zero,zero,zero),
        &iterativeFunctional(one),
        &iterativeFunctional(Ordinal::two),
        &iterativeFunctional(omega),
        &admisLevelFunctional(one,zero,NULL,one),
        &admisLevelFunctional(one,zero,NULL,omega),
        &admisLevelFunctional(one,zero,NULL,zero,one),
        &admisLevelFunctional(Ordinal::two,zero,NULL,zero,one),
        
        &admisLevelFunctional(omega,zero,NULL,zero,one),

        &zero
    };

    int i = 0 ;
    while (true) {
        const Ordinal * ptr = ordAry[i++] ;
        if (ptr->isZero()) break ;
        outPsiLimLine(outStream,*ptr,numElts);

    }



     outStream << "\\end{tabular}}\n" ;
    outStream <<
        "\\caption{$\\Psi$ collapsing function at critical limits}\n";
    
    outStream << "\\label{TabAdmisLimPsi}\n" ;
    outStream << "\\end{table}\n" ;

    OutStream::streamManager.pop();
}

static void writeText (ostream& out,const char ** lines)
{
    for (const char ** line = lines; *line ; line++)
        out << *line << "\n" ;
}

static void psiBaseLine(ostream&out,const Ordinal&ord, int& lc)
{
    out << lc++ << "&$" << ord.psiNormalForm() << "$&$" << ord.texNormalForm()
        << "$&\\\\\\hline\n" ;

}

static void admisPsiBaseTab()
{
    static const int numElts = 4 ;
    string tname = "admisBasePsi" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);

    outStream << "\\begin{table}\n\\centering\n" ;
    outStream << "\\begin{tabular}{|r|l|l|l|}\\hline\n" ;
    outStream << "&\\multicolumn{2}{|c|}{\\bf Notation}&\\\\\\hline\n" ;

    const char * text[] = {
        "{\\bf \\#}&{\\bf $\\Psi$ }&{\\bf $\\varphi\\ \\ \\omega$} &\n",
        "{\\bf Bound} \\\\\\hline\\hline",
        "1&$\\Psi(\\alpha)$ & $\\varepsilon_{\\alpha}$ &\n",
        "$\\alpha < \\varphi(2,0)$\\\\\\hline\n",
        NULL
    };
    int lineCount = 2 ;
    writeText(outStream,text);

    const Ordinal& twelve = * new Ordinal(12) ;
    const Ordinal &ord12 =  psi(Ordinal::two,twelve);
    psiBaseLine(outStream,ord12,lineCount) ;
    outStream << lineCount++ << "&$\\Psi(\\Omega (\\opa))$&" <<
        "$\\varphi(2,\\alpha)$&\n" <<
        "$\\alpha < \\varphi(3,0)$\\\\\\hline\n" ;

    const Ordinal &ord13_5 =  psi(Ordinal::three,Ordinal::five);
    psiBaseLine(outStream,ord13_5,lineCount) ;
    outStream << lineCount++ <<
        "&$\\Psi(\\Omega^2(\\opa))$&$\\varphi(3,\\alpha)$&\n" <<
        "$\\alpha < \\varphi(4,0)$\\\\\\hline\n" ;

    const Ordinal &ord12_x =  psi(twelve,Ordinal::five);
    psiBaseLine(outStream,ord12_x,lineCount) ;
    outStream << lineCount++ << 
        "&$\\Psi(\\Omega^\\beta(\\opa))$ &$\\varphi(1+\\beta,\\alpha)$&\n" <<
        "$\\alpha < \\varphi(1+\\beta,0) \\wedge \\beta <\\varphi(1,0,0)$\n" <<
        "\\\\\\hline\n" ;

    const Ordinal & ord1 = finiteFunctional(one,zero,zero);
    outStream << lineCount++ << "&$" << ord1.psiNormalForm() <<
        "$&$\\varphi(1,0,0) = "
        << ord1.texNormalForm() << "$&\\\\\\hline\n" ;
    

    const Ordinal &ord2 =  finiteFunctional(Ordinal::two,zero,zero);
    psiBaseLine(outStream,ord2,lineCount) ;
    

    const Ordinal &ord3 = finiteFunctional(Ordinal::two,Ordinal::three,
        Ordinal::five);
    psiBaseLine(outStream,ord3,lineCount);

    

    const Ordinal &ord4 = finiteFunctional(Ordinal::one,zero,zero,zero);
    psiBaseLine(outStream,ord4,lineCount);
    

    outStream << lineCount++ << "&$\\Psi(\\Omega^{\\Omega^n })$ &\n" <<
        "$\\varphi(1_1,0_2,...,0_{n+2})$&\\\\\\hline" ;
    outStream << lineCount++ << "&$\\Psi(\\Omega^{\\Omega^n \\alpha_1})$&\n" <<
        "$\\varphi(\\alpha_1,0_2,...,0_{n+2})  $ " <<
        "&$\\alpha_1 < \\varphi(1_1,0_2,...,0_{n+3}) $ \\\\\\hline" ;

    const Ordinal& ord5 = iterativeFunctional(one);
    psiBaseLine(outStream,ord5,lineCount);

    const Ordinal& ord6 = iterativeFunctional(Ordinal::one,Ordinal::five);
    psiBaseLine(outStream,ord6,lineCount);

    outStream << lineCount++ << 
        "&$\\Psi(\\Omega^{\\Omega^\\omega (\\opa)})$ &$\\varphi_1(\\alpha)$\n" ;
    outStream <<
        "&$\\alpha < \\varphi_1(1,0) $ \\\\\\hline\n" ;

    const Ordinal * ords[] = {
        &iterativeFunctional(Ordinal::one,Ordinal::four,Ordinal::two),
        &iterativeFunctional(Ordinal::two),
        &iterativeFunctional(Ordinal::omega),
        NULL
    };

    for (const Ordinal ** ord = ords; *ord; ord++) 
        psiBaseLine(outStream,**ord,lineCount);

    outStream << lineCount++ << 
        "&$\\Psi(\\Omega^{\\Omega^{\\omega^\\alpha}})$&\n" <<
        "$\\varphi_\\alpha $\n" <<
        "&$\\alpha < \\omega_1[1]$ \\\\\\hline\n" ;

    const Ordinal * ords2[] = {
        &admisLevelFunctional(one,zero,NULL,one),
        &admisLevelFunctional(Ordinal::one,zero,NULL,zero,one),
        &admisLevelFunctional(Ordinal::two,zero,NULL,zero,one),
        &admisLevelFunctional(Ordinal::omega,zero,NULL,zero,one),

        NULL
    };

    for (const Ordinal ** ord = ords2; *ord; ord++) 
        psiBaseLine(outStream,**ord,lineCount);
    
    const char * text3[] = {
        "\\end{tabular}\n",
        "\\caption{$\\Psi$ collapsing function with bounds}\n",
        
        "\\index{ordinal collapsing function}\n",
        "\\index{collapsing function, ordinal}\n",
        "\\label{TabOrdColFuncVal}\n",
        "\\end{table}\n", 
        NULL
    };
    writeText(outStream,text3);
    OutStream::streamManager.pop();
}

static void limitTypeDescTab()
{
    string tname = "tabLimitTypeDesc" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);

    outStream << "\\begin{table}\n\\centering\n" ;
    outStream << "\\begin{tabular}{|r|l|l|l|}\\hline\n" ;

    const char * text3[] = {
        "\\end{tabular}\n",
        "\\caption{$\\Psi$ collapsing function with bounds}\n",
        
        "\\index{ordinal collapsing function}\n",
        "\\index{collapsing function, ordinal}\n",
        "\\label{TabOrdColFuncVal}\n",
        "\\end{table}\n", 
        NULL
    };
    writeText(outStream,text3);
    OutStream::streamManager.pop();
}
/*
static void admisLimitEleTab()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisLimitEltExitCodeTestNames(labOrds);

    string tname = "tabAdmisLimitExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 3 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol);

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\Index{{\\tt AdmisNormalElement} " <<
        "example exit codes}}\n";
    outStream <<
    "\\mindex{exit codes examples {\\tt AdmisNormalElement}}\n" ;
    outStream << "\\label{TabAdmisLimtEleExitCodes}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}
*/

static void admisLimitEleExitTab()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisLimitElementExitCodeTestNames(labOrds);

    string tname = "tabAdmisLimitELementExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 3 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,"TabAdmisLimEltCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\Index{{\\tt AdmisNormalElement::limitElement} exit codes}}\n";
    outStream <<
    "\\mindex{exit codes {\\tt AdmisNormalElement::LimitElement}}\n" ;
    outStream << "\\label{TabAdmisLimtElementExitCodes}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}




static void admisLimitEleComExitTab()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisLimitEltComExitCodeTestNames(labOrds);

    string tname = "tabAdmisLimitELementComExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 3 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,"TabAdmisLimEltComCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol,true);
     outStream<<
     "\\caption{\\Index{{\\tt AdmisNormalElement::limitElementCom}" <<
        " exit codes}}\n";
    outStream <<
    "\\mindex{exit codes {\\tt AdmisNormalElement::limitElementCom}}\n" ;
    outStream << "\\label{TabAdmisLimtElementComExitCodes}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}





static void admisLimitOrdComExitCodeTab()
{
    const Ordinal& b = ( * new Ordinal(expFunctional(Ordinal::one).getImpl()
	    .addLoc(Ordinal::five)));

    //c = gamma( 3 ) + 12
	const Ordinal& c = ( * new Ordinal(finiteFunctional(
		Ordinal::four,
		Ordinal::zero,
		Ordinal::zero).getImpl()
	.addLoc((*new Ordinal(12)))))	;

    //d = [[3]]omega_{ 30}
	const Ordinal& d = admisLevelFunctional(
		(*new Ordinal(30)),
		Ordinal::zero,
		NULL,
		Ordinal::zero,
		(* new Embeddings(Ordinal::three, Embeddings::paramRestrict))
	)	;


    const Ordinal * params[] = {&b,&c,&d,NULL};
        
        
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisLimitOrdExitCodeTestNames(labOrds);

    string tname = "tabAdmisLimitOrdComExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    outStream << "\\begin{table}\n\\centering\\scriptsize\n" ;
    Ordinal::beginLimitOrdSubTable(outStream,params,
        "TabAdmisLimitOrdCases");

    Ordinal::tabSubNestedLimOrdOut(labOrds,outStream,params);
     outStream<<
     "\\caption{\\Index{{\\tt AdmisNormalElement::limitOrdCom}" <<
        " exit codes}}\n";
    outStream <<
    "\\mindex{exit codes {\\tt AdmisNormalElement::limitOrdCom}}\n" ;
    outStream << "\\label{TabAdmisLimtOrdComExitCodes}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}


static void admisDrillDownLimitExitTab()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisdrillDownLimitExitCodeTestNames(labOrds);

    string tname = "tabAdmisDrillDownLimitExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 3 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,"TabAdmisDdLimEltCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol,true);
     outStream<<
     "\\caption{\\Index{{\\tt AdmisNormalElement::drillDownLimitElement}" <<
        " exit codes}}\n";
    outStream <<
    "\\mindex{exit codes {\\tt AdmisNormalElement::drillDownLimitElement}}\n" ;
    outStream << "\\label{TabAdmisDrillDownLimtExitCodes}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}

static void admisDrillDownLimitComExitTab()
{
    list<LabeledOrdinal*> labOrds;
    LabeledOrdinal::admisdrillDownLimitComExitCodeTestNames(labOrds);

    string tname = "tabAdmisDrillDownLimitComExitCode" ;
    string fname = tname;
    fname += ".tex" ;
    ofstream outStream(fname.c_str());
    OutStream::streamManager.push(outStream);
    
    int nCol = 3 ;
    Ordinal::beginLimitEltSubTable(outStream,nCol,
        "TabAdmisDdLimEltComCases");

    Ordinal::tabSubNestedLimEleOut(labOrds,outStream,nCol);
     outStream<<
     "\\caption{\\Index{{\\tt AdmisNormalElement::drillDownLimitElementCom}" <<
        " exit codes}}\n";
    outStream <<
    "\\mindex{exit codes {\\tt AdmisNormalElement::drillDownLimitElementCom}}\n" ;
    outStream << "\\label{TabAdmisDrillDownLimtComExitCodes}\n" ;
    outStream << "\\end{table}\n\n" ;

    OutStream::streamManager.pop();

}







void AdmisLevOrdinal::texDocument()
{
    admisExamp();
    admisExampCalc();
    admisLimitEle();
    admisLimitEle2();
    admisLimitEle3();

    // admisLimitEleTab();
    admisLimitEleExitTab();
    admisLimitEleComExitTab();
    admisDrillDownLimitExitTab();
    admisDrillDownLimitComExitTab();

    
    admisLimitOrd();
    admisArithExamp();
    // admisLimitTypeExamp();
    admisNestedEtaExamp();
    // admisNestedDeltaExamp(); // combining int admisNestedEtaExamp
    // admisNestedEta2Examp(); // no longer used
    admisDrillDownDefExamp();
    // admisNestedCollapsingExamp() ;
    admisDescribeNestedCollapse();
    admisCollapseConnect() ;
    admisPsiTab();
    admisPsiLimTab();
    admisPsiBaseTab();
    admisLimitOrdComExitCodeTab();

    CantorNormalElement::createInfoTableType(
        AdmisNormalElement::admisCodeLevel,"");
    CantorNormalElement::createInfoTableExamp(
        AdmisNormalElement::admisCodeLevel,"\\footnotesize");
    CantorNormalElement::createInfoTableOrdExamp(
        AdmisNormalElement::admisCodeLevel,"\\footnotesize");

}


