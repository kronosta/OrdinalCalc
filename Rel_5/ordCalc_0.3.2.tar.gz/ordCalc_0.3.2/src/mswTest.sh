if make msfCnv.exe ;then bash srkTest.sh ;else echo 'make msfCnv failed.' ;fi
