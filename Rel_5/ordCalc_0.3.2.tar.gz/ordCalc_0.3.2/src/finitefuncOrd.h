#include "ordBase.h"
	
using namespace std ;
	
namespace ord {
	
	
	
	class FiniteFuncNormalElement : public CantorNormalElement {

	protected:
		const OrdinalImpl& replace3(int index, const Ordinal& nval,
			int index2, const Ordinal& nval2, int index3,
			const Ordinal& nval3) const ;
		const OrdinalImpl& replace2(int index, const Ordinal& nval,
			int index2, const Ordinal& nval2) const ;
		const OrdinalImpl& replace1(int index, const Ordinal& nval) const;
		class FiniteFuncParameters : public Parameters {
		public:
			const Ordinal* const * const parameters;
            const Embeddings& embeddings ;
			int size ;
			const Ordinal * maxParameter ;
            const Ordinal * maxEmbedIndex ;
			FiniteFuncParameters(
				const Ordinal * const * const params,
                const  Embeddings& embed= Embeddings::embedNone,
                int level=-1
            );
			
			virtual ~FiniteFuncParameters(){}

		};

		static const CantorNormalElement& doMultiply(
			const CantorNormalElement& op1, const CantorNormalElement& op2);


		static const OrdinalImpl& doToPower( const CantorNormalElement& base,
			const CantorNormalElement&  expon);

        static const char * notBasicString;
	public:
        virtual const char * className() const {return "FiniteFuncNormalElement";}
		const int size ;
		const Ordinal* const * const funcParameters ;
		const OrdinalImpl& maxParameter ;
        const Ordinal& maxEmbedIndex ;
		virtual const OrdinalImpl & getMaxParameter() const 
			{return maxParameter;}

        virtual const Ordinal& getMaxEmbedIndex() const {return maxEmbedIndex;}
		void commonInit() ;
		FiniteFuncNormalElement(const Ordinal* const * const params, Int fac=1);
		FiniteFuncNormalElement(const FiniteFuncParameters* prma, Int fac=1);

		static const int finiteFuncCodeLevel = cantorCodeLevel + 1 ;

		virtual const CantorNormalElement& getCopy(const Int fac=1) const;

		virtual int leastNzIndex() const ;
		const OrdinalImpl& limitOrdCom(const OrdinalImpl & ord) const;
		virtual const OrdinalImpl& limitOrd(const OrdinalImpl & ord) const;
		virtual const OrdinalImpl& limitElement(Int n) const;
		virtual const OrdinalImpl& limitElementCom(Int n)
			const ;
		virtual const CantorNormalElement & addFactors(
			const CantorNormalElement& toAdd) const ;

		virtual int compare(const Embeddings& context,
            const Embeddings& paramContext, const CantorNormalElement& trm,
			bool ignoreFactor = false) const ;

		virtual int compare(const CantorNormalElement& trm,
			bool ignoreFactor = false) const ;

		


		int compareFiniteParams(const Embeddings& context,
            const Embeddings& paramContext,
            const FiniteFuncNormalElement& elt) const ;

		virtual void normalFormName(string& base) const ;
		virtual void texNormalForm(string& str) const ;
		virtual void psiNormalForm(string& str) const ;
        virtual string& cppNormalForm(const string& nameBase, string& ret)const;
        virtual string& cppParamNormalForm(const string& nameBase,
            string& ret)const;

        static bool isNotBasic(string& str);
        static string notBasic();
		const CantorNormalElement& multiply(
			const CantorNormalElement& op) const ;
		const CantorNormalElement& multiplyBy(
			const CantorNormalElement& op) const ;
		const OrdinalImpl& toPower(const CantorNormalElement& elt) const;
		const OrdinalImpl& powerOf(const CantorNormalElement& elt) const ;

		virtual const OrdinalImpl& maxLimitType() const ;
        // virtual const OrdinalImpl& maxLimitType(const Ordinal& context)const;
		virtual const OrdinalImpl& limitType() const;

        

		const OrdinalImpl* limitInfoCommon(
            CantorNormalElement::LimitTypeInfo& info) const ;
		virtual const OrdinalImpl& limitInfo(
            CantorNormalElement::LimitTypeInfo& info)
			const ;

		virtual bool isOne() const {
			if (codeLevel > cantorCodeLevel) return false;
			return CantorNormalElement::isOne();}
protected:
        

		virtual const OrdinalImpl & createVirtualOrdImpl(
			const Ordinal * const * const params) const ;
		virtual const Ordinal & createVirtualOrd(
			const Ordinal * const * const params) const ;

	};


	class FiniteFuncOrdinalImpl: public OrdinalImpl {
		friend class FiniteFuncNormalElement ;
		friend class FiniteFuncOrdinal ;
		static const NormalFormTerm& createTerms(
			const Ordinal* const * const params, Int factor=1)  ;
	protected:
		static string makeName(const Ordinal* const * const params)  ;
		static string makeTexName(const Ordinal* const * const params)  ;
	public:
		FiniteFuncOrdinalImpl(const Ordinal* const * const params,
            Int factor=1):
			OrdinalImpl(makeName(params), createTerms(params,factor)){}
		FiniteFuncOrdinalImpl(const FiniteFuncNormalElement& elt):
			OrdinalImpl(elt){}
		FiniteFuncOrdinalImpl(const string& name,const NormalFormTerm&  trms):
			OrdinalImpl(name,trms){}
			
		virtual ~FiniteFuncOrdinalImpl(){}

	};

	class FiniteFuncOrdinal : public Ordinal {
	public:
		
		FiniteFuncOrdinal (const Ordinal& ord1, const Ordinal&ord2):
			Ordinal(* new FiniteFuncOrdinalImpl(
			createParameters(&ord1,&ord2))){}
		FiniteFuncOrdinal (const Ordinal& ord1, const Ordinal&ord2,
			const Ordinal& ord3):
			Ordinal(* new FiniteFuncOrdinalImpl(createParameters(
			&ord1,&ord2,&ord3))) {}
		FiniteFuncOrdinal (const Ordinal& ord1, const Ordinal&ord2,
			const Ordinal& ord3, const Ordinal&ord4):Ordinal(
				* new FiniteFuncOrdinalImpl(createParameters(&ord1,&ord2,&ord3,
				&ord4))) {}

		FiniteFuncOrdinal(const Ordinal* const * const params, Int factor=1):
			Ordinal(* new FiniteFuncOrdinalImpl(params,factor)) {}
		FiniteFuncOrdinal(const FiniteFuncOrdinalImpl& o):Ordinal(o){}
		virtual ~FiniteFuncOrdinal(){}

		static bool fixedPoint(int ix, const Ordinal* const * const params,
            const Embeddings& embedIn=Embeddings::embedNone);
		enum {maxIndexPosUndefined = - 10000};

		
		static void texDocument() ;

	};

	
	
	
}
