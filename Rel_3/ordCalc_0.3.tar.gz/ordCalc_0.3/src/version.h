const char * version = "ordCalc 0.3";
