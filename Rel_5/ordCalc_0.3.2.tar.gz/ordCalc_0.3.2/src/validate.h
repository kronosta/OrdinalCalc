#include <stdlib.h>
#include <iostream>
// #include <gmpxx.h>
#include <mpirxx.h>
using namespace std ;

    namespace ord {
    class Ordinal ;
    
    class Validate {
public:
        Validate(){}

        static int simpRand();
        static void baseTest();
        static void psiTest();
        static void iterTest();
        static void tryExamp();
        static const Ordinal ** gammaArray();
        static void gamma();
        static void admisTest();
        static void admisTest2();
        static void descendTest();
        static void playTest();
        static void collapseTest();
        static void nestedCollapseTest();
        static void nestedCollapseTest2();
        static void nestedCollapseTest3();
        static void exitCodeTest();
        static void exitCodeTest2();
        static void limitEltExitCodeTest();
        static void limitEltExitCodeTest1();
        static void limitEltExitCodeTest2();
        static void limitEltExitCodeTest3();
        static void limitOrdExitCodeTest();
        static void limitOrdExitCodeTest1();
        static void limitOrdExitCodeTest2();
        static void limitOrdExitCodeTest3();
        static void admisLimitElementExitCodeTest();
        static void admisLimitElementComExitCodeTest();
        static void admisDrillDownLimitExitCodeTest(); 
        static void admisDrillDownLimitComExitCodeTest(); 

        static void admisExampTests();

        static void nestedLimitEltExitCodeTest();
        static void nestedLimitEltExitCodeTest2();
        static void nestedLimitOrdExitCodeTest();
        static void nestedBaseClassLimitEltExitCodeTest();
        static void nestedCmpExitCodeTest();
        static void nestedEmbedNextLeastTest();

        static void transitionTest();
        static void cmpExitCodeTest();
        static void drillDownExitCodeTest();
        static void embedExitCodeTest();
        static void fixedPointTest();
        static void nestedEmbedTest();
        static void infoLimitTypeExampTest();

        static void cppTest();
        static void cppTestTeX();

        static void finiteFuncLimitElementComExitCodeTest();

        static void listElts(const Ordinal& ord,bool doTest=true, int line=0);
        static void expTest(const Ordinal& ord, ostream& stream);
        static void checkCompare(int toCompare=100, int terms = 10);
        static bool checkThree(const Ordinal&a, const Ordinal&b,
            const Ordinal&c) ;
        static bool useDeleteUnref ;

        static bool validationTest ;
        static bool validationCmpTest ;
        static bool outCompareExit ;
        static bool outCmpExit() {return validationTest && outCompareExit;}
        static void admisFollow(const Ordinal & ord, int n,
            int limit=100);
        static void testOrdinalAry(const Ordinal * ords[],
			int count = 10);

        static void testStub();


    
    };
    extern ofstream * texDefs ;
}
